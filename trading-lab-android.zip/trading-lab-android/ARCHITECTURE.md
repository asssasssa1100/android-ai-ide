# Trading Lab — Architecture

## نظرة عامة

تطبيق Android لاختبار استراتيجيات التداول بأثر رجعي (Backtesting).
يعمل على بنية هجينة: Python (منطق الأعمال) + WebView (واجهة المستخدم).

---

## مكدس التقنيات

| الطبقة | التقنية |
|--------|---------|
| Android Shell | Java (WebViewActivity) |
| Python Runtime | Chaquopy 15 + Python 3.11 |
| Web Server | Flask 3.0.3 (localhost) |
| واجهة المستخدم | HTML/CSS/JS (WebView → http://localhost:5000) |
| قاعدة البيانات | SQLite (Drizzle-style schema، Drizzle غير مستخدمة) |
| مسار البيانات | /data/data/com.tradinglab/files/trading_lab/ |

---

## البنية الداخلية (Python)

```
app/src/main/python/
├── main.py                   ← نقطة الدخول: يبدأ Flask + يفتح WebView
├── server_config.py          ← HOST=127.0.0.1, PORT=5000
├── config.py                 ← مسارات الملفات (DATA_DIR, INDICATORS_DIR...)
├── db.py                     ← init_db() + ترحيل الأعمدة (_add_columns)
├── storage.py                ← TF_ALL, TF_NORM, csv_path, currency_dir...
├── routes/
│   ├── data_routes.py        ← /api/data — جلب العملات والشموع والفلاتر
│   ├── analysis_routes.py    ← /api/analysis — Top-10 + Trend + Regular
│   ├── indicators_routes.py  ← /api/indicators — رفع/حذف المؤشرات
│   ├── audit_routes.py       ← /api/audit — تدقيق الاستراتيجية
│   └── test_routes.py        ← /api/tests — اختبار الإشارة على عملة
├── services/
│   ├── binance_service.py    ← جلب البيانات من Binance API
│   ├── filter_service.py     ← حساب نتائج الفلاتر على الشموع
│   ├── backtest_service.py   ← محاكاة الصفقات (SL/TP)
│   ├── analysis_service.py   ← Hybrid Top-10 Algorithm
│   └── trend_service.py      ← Hybrid Trend Analysis Algorithm
└── indicators/
    ├── builtin/              ← مؤشرات مدمجة (stoch.py, breakout.py...)
    └── templates/            ← قوالب للمطورين (_FILTER_TEMPLATE.py, _SIGNAL_TEMPLATE.py)
```

---

## قاعدة البيانات (SQLite)

| الجدول | الوصف |
|--------|-------|
| `currencies` | العملات المجلوبة (BTCUSDT, ETHUSDT...) |
| `currency_tfs` | معلومات كل إطار زمني لكل عملة |
| `indicators` | المؤشرات المرفوعة |
| `filter_results` | نتائج الفلاتر المحسوبة لكل (symbol, tf, indicator_id) |
| `tests` | نتائج الاختبارات (backtest) |
| `analyses` | تحليلات يدوية بفلاتر محددة |
| `top10` | نتائج خوارزمية Top-10 الهجينة |
| `trend_results` | نتائج تحليل الاتجاهات |
| `audits` | سجلات التدقيق متعدد العملات |

### الحذف المتتالي (Cascade)
- حذف عملة → يُحذف: currencies + currency_tfs + filter_results (بالرمز)
- حذف إطار زمني → يُحذف: currency_tfs + filter_results (بالرمز والإطار)
- حذف مؤشر → يُحذف: indicators + ملف .py + filter_results (بالـ indicator_id)

---

## خوارزمية Hybrid Top-10

الهدف: إيجاد أفضل 10 تركيبات فلاتر تُحسّن نسبة الربح (Win Rate).

```
المرحلة 1 — Exhaustive size-1  : تجرب كل فلتر منفرداً          O(N)
المرحلة 2 — Exhaustive size-2  : تجرب كل أزواج الفلاتر         O(N²/2)
المرحلة 3 — Greedy             : تبني تركيبات أكبر خطوة بخطوة   O(N × عمق)
```

**معامل الكفاءة الرئيسي**: `_build_trade_mask_np` تستخدم `np.searchsorted` → O(N log M) بدلاً من O(N×M).

**ميزات**: إيقاف مؤقت + استئناف + حفظ نقطة التقدم (checkpoint_json).

---

## خوارزمية Hybrid Trend

نفس المراحل الثلاث لكن الهدف: إيجاد تركيبات فلاتر تُعطي أعلى نسبة شموع صاعدة.

يعمل الآن في خيط خلفية — يُظهر بطاقة تقدم متحركة مع زر إيقاف.

---

## تدفق البيانات

```
Binance API
    ↓ fetch_klines_batch()
CSV (5m candles)
    ↓ resample / direct fetch
CSV (15m, 1h, 4h, 1d)
    ↓ compute_filters()
filter_results (DB) ← candles_json (النوافذ النشطة)
    ↓ run_top10_from_saved()
top10 (DB) ← result_json (أفضل 10 تركيبات)
    ↓ WebView
عرض البطاقات للمستخدم
```

---

## نظام المؤشرات

كل مؤشر ملف `.py` يُرفع من الهاتف ويُخزّن في `INDICATORS_DIR`.

### نوعان:
| النوع | الدالة المطلوبة | الإرجاع |
|-------|----------------|---------|
| `filter` | `generate_mask(df, params)` | `list[dict\|None]` — كل عنصر: `{"active": bool, ...}` أو `None` للإحماء |
| `signal` | `generate_signals(df, params)` | `list[dict]` — كل عنصر: `{"timestamp": int, "price": float, "reason": str}` |

### قوالب جاهزة:
- `indicators/templates/_FILTER_TEMPLATE.py`
- `indicators/templates/_SIGNAL_TEMPLATE.py`

---

## API Endpoints

### /api/data
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | /currencies | قائمة العملات |
| DELETE | /currencies/{sym} | حذف عملة (مع filter_results) |
| POST | /fetch | جلب شموع 5m من Binance |
| POST | /currencies/{sym}/tf/{tf}/compute | جلب إطار زمني أعلى |
| DELETE | /currencies/{sym}/tf/{tf} | حذف إطار زمني (مع filter_results) |
| POST | /currencies/{sym}/filters/{tf}/compute | حساب الفلاتر في الخلفية |
| GET | /currencies/{sym}/filters/{tf}/status | حالة حساب الفلاتر |

### /api/indicators
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | / | قائمة المؤشرات |
| POST | /upload | رفع مؤشر .py |
| DELETE | /{id} | حذف مؤشر (مع filter_results) |
| POST | /{id}/verify | اختبار المؤشر على بيانات حقيقية |

### /api/analysis
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| GET | / | قائمة التحليلات |
| POST | /top10 | بدء Top-10 (خيط خلفية) |
| POST | /top10/{id}/pause | إيقاف مؤقت |
| POST | /top10/{id}/resume | استئناف |
| DELETE | /top10/{id} | حذف |
| GET | /trend | قائمة تحليلات الاتجاه |
| POST | /trend | بدء تحليل اتجاه (خيط خلفية) |
| POST | /trend/{id}/stop | إيقاف |
| DELETE | /trend/{id} | حذف |

### /api/tests
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| POST | / | بدء اختبار إشارة |
| GET | / | قائمة الاختبارات |

### /api/audit
| الطريقة | المسار | الوصف |
|---------|--------|-------|
| POST | / | بدء تدقيق (multi-symbol) |
| GET | / | قائمة التدقيقات |

---

## بناء APK

يتم عبر GitHub Actions → `.github/workflows/build.yml`.
المتطلبات: Android SDK + Chaquopy license key في الـ secrets.

---

## ملاحظات تقنية مهمة

1. **لا تستخدم `pd.rolling().mean()` للـ SMA** — استخدم `_sma_scalar()` في القوالب للمطابقة الدقيقة مع TradingView.
2. **SQLite thread safety** — كل خيط يفتح `get_conn()` خاصاً به (لا مشاركة connections).
3. **Chaquopy limitations** — بعض مكتبات Python لا تعمل على Android (مثل `multiprocessing`). استخدم `threading` دائماً.
4. **filter_results** — تُخزّن `candles_json` (النوافذ النشطة) كـ JSON نصي. مع مليون شمعة يكون الحجم كبيراً — الخوارزمية الجديدة تتعامل معه بكفاءة.
5. **Cascading deletes** — يجب دائماً حذف `filter_results` عند حذف عملة أو إطار زمني أو مؤشر.

---

*آخر تحديث: Session 2 — May 2026*
