# مرجع فلاتر متعدّدة الإطارات (MTF) — مطابقة لـ TradingView

هذا المرجع يحتوي على أمثلة جاهزة للنسخ لأشهر المؤشرات، مصنّفة حسب نوعها.
كل مثال:
- يعتمد التوقيع الموحَّد `generate_mask(df, df_5m, params)`.
- يستخدم الدوال المساعدة في `engine.filter_helpers` (كلّها مطابقة لـ Pine Script).
- يُسقط القيم على شموع 5m عبر `map_higher_to_5m` بدون lookahead.
- يحترم بذرة SMA في كل المؤشرات الانعكاسية (EMA / RMA).

> القاعدة: **اختر إطار الفلتر من واجهة التطبيق عند الرفع** (5m / 15m / 1h).
> الفلتر نفسه لا يحتاج معرفة الإطار — `df` هو إطارك المختار، `df_5m` ثابت دائماً.

---

## فهرس الفئات

1. [مؤشرات الاتجاه (Trend)](#1-مؤشرات-الاتجاه-trend)
   - SMA, EMA, WMA
2. [مؤشرات الزخم (Momentum)](#2-مؤشرات-الزخم-momentum)
   - RSI, MACD, ROC
3. [مؤشرات التذبذب / النطاقات (Volatility)](#3-مؤشرات-التذبذب--النطاقات-volatility)
   - Bollinger Bands, ATR, Keltner
4. [مؤشرات الحجم (Volume)](#4-مؤشرات-الحجم-volume)
   - VWAP, OBV, MFI
5. [مذبذبات (Oscillators)](#5-مذبذبات-oscillators)
   - Stochastic, CCI

---

## الدوال المساعدة المتاحة (engine/filter_helpers.py)

| الدالة | الاستخدام |
|---|---|
| `map_higher_to_5m(vals, df_h, df_5m)` | إسقاط قيم إطار عالي على 5m بدون lookahead |
| `broadcast_state_to_5m(states, df_h, df_5m)` | نفسها لقيم True/False |
| `sma_pine(values, period)` | SMA مطابق لـ ta.sma |
| `ema_pine(values, period)` | EMA ببذرة SMA — مطابق لـ ta.ema |
| `rma_pine(values, period)` | RMA / Wilder ببذرة SMA — لـ ta.rma و ta.rsi و ta.atr |
| `wma_pine(values, period)` | WMA مطابق لـ ta.wma |
| `stdev_pine(values, period)` | الانحراف المعياري السكاني (population) — لـ Bollinger |
| `true_range(df)` | TR لكل شمعة — مطابق لـ ta.tr |
| `session_index(df, session_ms)` | رقم الجلسة لكل شمعة (لتصفير VWAP) |

---

## 1) مؤشرات الاتجاه (Trend)

### 1.1 SMA — Simple Moving Average
**الفكرة:** متوسط حسابي بسيط لآخر N شمعة.
**شرط القبول:** سعر الإغلاق أعلى من SMA.

```python
from engine.filter_helpers import map_higher_to_5m, sma_pine

INDICATOR_NAME    = "SMA Trend"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 50}

def generate_mask(df, df_5m, params=None):
    period = int((params or PARAMETERS).get("period", 50))
    sma = sma_pine([r["close"] for r in df], period)
    sma_5m = map_higher_to_5m(sma, df, df_5m)
    return [bool(s is not None and r["close"] > s)
            for r, s in zip(df_5m, sma_5m)]
```

### 1.2 EMA — Exponential Moving Average
**الفكرة:** متوسط أُسي يُعطي وزناً أكبر للشمعات الأحدث.
**النقطة الحرجة:** البذرة = SMA لأول N شمعة (وليس أول close).
**شرط القبول:** السعر أعلى من EMA.

```python
from engine.filter_helpers import map_higher_to_5m, ema_pine

INDICATOR_NAME    = "EMA Trend"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 20}

def generate_mask(df, df_5m, params=None):
    period = int((params or PARAMETERS).get("period", 20))
    ema = ema_pine([r["close"] for r in df], period)
    ema_5m = map_higher_to_5m(ema, df, df_5m)
    return [bool(e is not None and r["close"] > e)
            for r, e in zip(df_5m, ema_5m)]
```

### 1.3 WMA — Weighted Moving Average
**الفكرة:** أوزان خطّية تنازلية (الأحدث له N، ثم N-1، ...).
**شرط القبول:** السعر أعلى من WMA.

```python
from engine.filter_helpers import map_higher_to_5m, wma_pine

INDICATOR_NAME    = "WMA Trend"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 20}

def generate_mask(df, df_5m, params=None):
    period = int((params or PARAMETERS).get("period", 20))
    wma = wma_pine([r["close"] for r in df], period)
    wma_5m = map_higher_to_5m(wma, df, df_5m)
    return [bool(w is not None and r["close"] > w)
            for r, w in zip(df_5m, wma_5m)]
```

---

## 2) مؤشرات الزخم (Momentum)

### 2.1 RSI — Relative Strength Index
**الفكرة:** قياس قوة الصعود مقابل الهبوط على آخر N شمعة.
**النقطة الحرجة:** يستعمل **RMA (Wilder)** ألفا = 1/N — وليس EMA.
**شرط القبول:** RSI أعلى من العتبة (افتراضياً 50 للترند الصاعد).

```python
from engine.filter_helpers import map_higher_to_5m, rma_pine

INDICATOR_NAME    = "RSI Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 14, "threshold": 50}

def generate_mask(df, df_5m, params=None):
    p = params or PARAMETERS
    period    = int(p.get("period", 14))
    threshold = float(p.get("threshold", 50))
    closes = [r["close"] for r in df]
    n = len(closes)
    gains  = [0.0] * n
    losses = [0.0] * n
    for i in range(1, n):
        ch = closes[i] - closes[i - 1]
        gains[i]  = ch if ch > 0 else 0.0
        losses[i] = -ch if ch < 0 else 0.0
    avg_g = rma_pine(gains,  period)
    avg_l = rma_pine(losses, period)
    rsi = []
    for g, l in zip(avg_g, avg_l):
        if g is None or l is None:
            rsi.append(None)
        elif l == 0:
            rsi.append(100.0)
        else:
            rsi.append(100.0 - 100.0 / (1.0 + g / l))
    rsi_5m = map_higher_to_5m(rsi, df, df_5m)
    return [bool(v is not None and v > threshold) for v in rsi_5m]
```

### 2.2 MACD — Moving Average Convergence Divergence
**الفكرة:** فرق بين EMA سريع و EMA بطيء، مع خط إشارة = EMA على هذا الفرق.
**النقطة الحرجة:** ثلاث EMAs، كلٌّ ببذرة SMA. خط الإشارة يبدأ بعد توفّر slow قيم.
**شرط القبول:** MACD > Signal (تقاطع صاعد).

```python
from engine.filter_helpers import map_higher_to_5m, ema_pine

INDICATOR_NAME    = "MACD Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"fast": 12, "slow": 26, "signal": 9}

def generate_mask(df, df_5m, params=None):
    p = params or PARAMETERS
    fast   = int(p.get("fast", 12))
    slow   = int(p.get("slow", 26))
    signal = int(p.get("signal", 9))
    closes = [r["close"] for r in df]
    ema_f = ema_pine(closes, fast)
    ema_s = ema_pine(closes, slow)
    macd  = [None if (a is None or b is None) else a - b
             for a, b in zip(ema_f, ema_s)]
    # خط الإشارة يُحسب فقط على القيم غير None
    valid = [v for v in macd if v is not None]
    sig_valid = ema_pine(valid, signal)
    pad = len(macd) - len(sig_valid)
    sig = [None] * pad + sig_valid
    macd_5m = map_higher_to_5m(macd, df, df_5m)
    sig_5m  = map_higher_to_5m(sig,  df, df_5m)
    return [bool(m is not None and s is not None and m > s)
            for m, s in zip(macd_5m, sig_5m)]
```

### 2.3 ROC — Rate of Change
**الفكرة:** نسبة تغيّر السعر مقابل قيمته قبل N شمعة.
**شرط القبول:** ROC > 0 (السعر أعلى من قبل period شمعة).

```python
from engine.filter_helpers import map_higher_to_5m

INDICATOR_NAME    = "ROC Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 9, "threshold": 0.0}

def generate_mask(df, df_5m, params=None):
    p = params or PARAMETERS
    period    = int(p.get("period", 9))
    threshold = float(p.get("threshold", 0.0))
    closes = [r["close"] for r in df]
    n = len(closes)
    roc = [None] * n
    for i in range(period, n):
        prev = closes[i - period]
        if prev != 0:
            roc[i] = (closes[i] - prev) / prev * 100.0
    roc_5m = map_higher_to_5m(roc, df, df_5m)
    return [bool(v is not None and v > threshold) for v in roc_5m]
```

---

## 3) مؤشرات التذبذب / النطاقات (Volatility)

### 3.1 Bollinger Bands
**الفكرة:** SMA ± (mult × stdev).
**النقطة الحرجة:** الانحراف المعياري **سكاني** (مقام = N) كما في `ta.stdev` — وليس عيّنة (N-1).
**شرط القبول:** السعر داخل النطاقات (تُعدَّل حسب استراتيجيتك: قرب الحد الأعلى / كسر الحد، إلخ).

```python
from engine.filter_helpers import map_higher_to_5m, sma_pine, stdev_pine

INDICATOR_NAME    = "Bollinger Bands Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 20, "mult": 2.0}

def generate_mask(df, df_5m, params=None):
    p = params or PARAMETERS
    period = int(p.get("period", 20))
    mult   = float(p.get("mult", 2.0))
    closes = [r["close"] for r in df]
    basis = sma_pine(closes, period)
    sd    = stdev_pine(closes, period)
    upper = [None if (b is None or s is None) else b + mult * s
             for b, s in zip(basis, sd)]
    lower = [None if (b is None or s is None) else b - mult * s
             for b, s in zip(basis, sd)]
    upper_5m = map_higher_to_5m(upper, df, df_5m)
    lower_5m = map_higher_to_5m(lower, df, df_5m)
    # مثال شرط: السعر داخل النطاقات
    return [bool(u is not None and l is not None and l <= r["close"] <= u)
            for r, u, l in zip(df_5m, upper_5m, lower_5m)]
```

### 3.2 ATR — Average True Range
**الفكرة:** متوسط Wilder للمدى الحقيقي TR.
**النقطة الحرجة:** يستعمل **RMA** على TR (وليس SMA ولا EMA).
**شرط القبول:** ATR أعلى من حد أدنى (ترشيح الضجيج / فترات السكون).

```python
from engine.filter_helpers import map_higher_to_5m, rma_pine, true_range

INDICATOR_NAME    = "ATR Min Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 14, "min_atr": 0.0}

def generate_mask(df, df_5m, params=None):
    p = params or PARAMETERS
    period  = int(p.get("period", 14))
    min_atr = float(p.get("min_atr", 0.0))
    tr  = true_range(df)
    atr = rma_pine(tr, period)
    atr_5m = map_higher_to_5m(atr, df, df_5m)
    return [bool(v is not None and v >= min_atr) for v in atr_5m]
```

### 3.3 Keltner Channels
**الفكرة:** EMA ± (mult × ATR).
**شرط القبول:** السعر داخل القناة.

```python
from engine.filter_helpers import map_higher_to_5m, ema_pine, rma_pine, true_range

INDICATOR_NAME    = "Keltner Channels Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 20, "atr_period": 10, "mult": 2.0}

def generate_mask(df, df_5m, params=None):
    p = params or PARAMETERS
    period     = int(p.get("period", 20))
    atr_period = int(p.get("atr_period", 10))
    mult       = float(p.get("mult", 2.0))
    closes = [r["close"] for r in df]
    basis = ema_pine(closes, period)
    atr   = rma_pine(true_range(df), atr_period)
    upper = [None if (b is None or a is None) else b + mult * a
             for b, a in zip(basis, atr)]
    lower = [None if (b is None or a is None) else b - mult * a
             for b, a in zip(basis, atr)]
    upper_5m = map_higher_to_5m(upper, df, df_5m)
    lower_5m = map_higher_to_5m(lower, df, df_5m)
    return [bool(u is not None and l is not None and l <= r["close"] <= u)
            for r, u, l in zip(df_5m, upper_5m, lower_5m)]
```

---

## 4) مؤشرات الحجم (Volume)

### 4.1 VWAP — Volume Weighted Average Price
**الفكرة:** متوسط مرجّح بالحجم لـ typical price = (h+l+c)/3.
**النقطة الحرجة:** **يُصفَّر مع كل جلسة جديدة** (افتراضياً يومية UTC). ليس متوسطاً متحرّكاً.
**شرط القبول:** السعر فوق VWAP.

```python
from engine.filter_helpers import map_higher_to_5m, session_index

INDICATOR_NAME    = "VWAP Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {}   # لا معاملات — يُصفَّر يومياً

def generate_mask(df, df_5m, params=None):
    sess = session_index(df)         # يوم UTC
    cum_pv = 0.0
    cum_v  = 0.0
    last   = None
    vwap = []
    for r, s in zip(df, sess):
        if s != last:
            cum_pv = 0.0; cum_v = 0.0; last = s
        tp = (r["high"] + r["low"] + r["close"]) / 3.0
        cum_pv += tp * r["volume"]
        cum_v  += r["volume"]
        vwap.append(cum_pv / cum_v if cum_v > 0 else None)
    vwap_5m = map_higher_to_5m(vwap, df, df_5m)
    return [bool(v is not None and r["close"] > v)
            for r, v in zip(df_5m, vwap_5m)]
```

### 4.2 OBV — On Balance Volume
**الفكرة:** تراكم الحجم: يضيفه إذا close أعلى من السابق، يطرحه إذا أقل.
**شرط القبول:** OBV أعلى من EMA(OBV) (تأكيد ترند الحجم).

```python
from engine.filter_helpers import map_higher_to_5m, ema_pine

INDICATOR_NAME    = "OBV Trend Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"signal": 21}

def generate_mask(df, df_5m, params=None):
    signal = int((params or PARAMETERS).get("signal", 21))
    n = len(df)
    obv = [0.0] * n
    for i in range(1, n):
        c, cp = df[i]["close"], df[i - 1]["close"]
        v = df[i]["volume"]
        if   c > cp: obv[i] = obv[i - 1] + v
        elif c < cp: obv[i] = obv[i - 1] - v
        else:        obv[i] = obv[i - 1]
    sig = ema_pine(obv, signal)
    obv_5m = map_higher_to_5m(obv, df, df_5m)
    sig_5m = map_higher_to_5m(sig, df, df_5m)
    return [bool(o is not None and s is not None and o > s)
            for o, s in zip(obv_5m, sig_5m)]
```

### 4.3 MFI — Money Flow Index
**الفكرة:** "RSI الحجمي" — يُحسب بنفس منطق RSI لكن باستخدام (typical × volume).
**النقطة الحرجة:** TradingView **لا يستخدم RMA** هنا، بل **مجموع نافذة** بسيطة من period شمعة (انتبه — هذه نقطة يُخطئ فيها كثيرون).
**شرط القبول:** MFI داخل نطاق منطقي (مثلاً 20–80).

```python
from engine.filter_helpers import map_higher_to_5m

INDICATOR_NAME    = "MFI Range Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 14, "lower": 20, "upper": 80}

def generate_mask(df, df_5m, params=None):
    p = params or PARAMETERS
    period = int(p.get("period", 14))
    lo     = float(p.get("lower", 20))
    up     = float(p.get("upper", 80))
    n = len(df)
    tp = [(r["high"] + r["low"] + r["close"]) / 3.0 for r in df]
    raw_mf = [tp[i] * df[i]["volume"] for i in range(n)]
    pos = [0.0] * n
    neg = [0.0] * n
    for i in range(1, n):
        if   tp[i] > tp[i - 1]: pos[i] = raw_mf[i]
        elif tp[i] < tp[i - 1]: neg[i] = raw_mf[i]
    mfi = [None] * n
    for i in range(period, n):
        sp = sum(pos[i - period + 1:i + 1])
        sn = sum(neg[i - period + 1:i + 1])
        if sn == 0:
            mfi[i] = 100.0
        else:
            mfi[i] = 100.0 - 100.0 / (1.0 + sp / sn)
    mfi_5m = map_higher_to_5m(mfi, df, df_5m)
    return [bool(v is not None and lo <= v <= up) for v in mfi_5m]
```

---

## 5) مذبذبات (Oscillators)

### 5.1 Stochastic
**الفكرة:** موقع الإغلاق ضمن نطاق آخر k_period شمعة (high-low)، ثم تنعيم K و D بـ SMA.
**النقطة الحرجة:** التنعيم بـ `sma_pine` (وليس EMA). إذا أردت مطابقة TV الافتراضية كمؤشر فلتر فقط على K، استعمل smooth_k=1.
**شرط القبول:** %K أعلى من %D (تقاطع صاعد).

```python
from engine.filter_helpers import map_higher_to_5m, sma_pine

INDICATOR_NAME    = "Stochastic Cross Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"k_period": 14, "smooth_k": 1, "d_period": 3}

def generate_mask(df, df_5m, params=None):
    p = params or PARAMETERS
    kp = int(p.get("k_period", 14))
    sk = int(p.get("smooth_k", 1))
    dp = int(p.get("d_period", 3))
    n = len(df)
    raw_k = [None] * n
    for i in range(kp - 1, n):
        window = df[i - kp + 1:i + 1]
        hh = max(r["high"] for r in window)
        ll = min(r["low"]  for r in window)
        c  = df[i]["close"]
        raw_k[i] = 100.0 if hh == ll else (c - ll) / (hh - ll) * 100.0
    # نعيد تجميع التنعيم على القيم غير None
    valid_k = [v for v in raw_k if v is not None]
    smooth = sma_pine(valid_k, sk) if sk > 1 else valid_k[:]
    pad = n - len(smooth)
    k_line = [None] * pad + smooth
    valid_d = [v for v in k_line if v is not None]
    d_smooth = sma_pine(valid_d, dp)
    pad2 = n - len(d_smooth)
    d_line = [None] * pad2 + d_smooth
    k_5m = map_higher_to_5m(k_line, df, df_5m)
    d_5m = map_higher_to_5m(d_line, df, df_5m)
    return [bool(k is not None and d is not None and k > d)
            for k, d in zip(k_5m, d_5m)]
```

### 5.2 CCI — Commodity Channel Index
**الفكرة:** مدى انحراف typical price عن متوسطه السبسط، مقسوماً على متوسط الانحراف المطلق × 0.015.
**شرط القبول:** CCI داخل نطاق (مثلاً |CCI| < 100 = حالة هدوء، أو > 0 = ترند صاعد).

```python
from engine.filter_helpers import map_higher_to_5m, sma_pine

INDICATOR_NAME    = "CCI Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 20, "threshold": 0.0}

def generate_mask(df, df_5m, params=None):
    p = params or PARAMETERS
    period    = int(p.get("period", 20))
    threshold = float(p.get("threshold", 0.0))
    tp = [(r["high"] + r["low"] + r["close"]) / 3.0 for r in df]
    ma = sma_pine(tp, period)
    n = len(tp)
    cci = [None] * n
    for i in range(period - 1, n):
        m = ma[i]
        if m is None:
            continue
        mad = sum(abs(tp[j] - m) for j in range(i - period + 1, i + 1)) / period
        if mad == 0:
            cci[i] = 0.0
        else:
            cci[i] = (tp[i] - m) / (0.015 * mad)
    cci_5m = map_higher_to_5m(cci, df, df_5m)
    return [bool(v is not None and v > threshold) for v in cci_5m]
```

---

## نقاط حرجة لمطابقة TradingView بدقّة عالية

| المؤشر | استعمل | الخطأ الشائع |
|---|---|---|
| EMA | `ema_pine` (بذرة SMA) | البدء بأول close |
| RSI | `rma_pine` | استعمال EMA |
| ATR | `rma_pine` على `true_range` | EMA أو SMA على TR |
| MACD | ثلاث `ema_pine` | نسيان البذرة في خط الإشارة |
| Bollinger | `sma_pine` + `stdev_pine` (مقام = N) | std بمقام N-1 |
| VWAP | تراكمي بإعادة تصفير يومية | استعماله كـ MA |
| MFI | مجموع نافذة (sum) | استعمال RMA كـ RSI |
| Stoch | `sma_pine` للتنعيم | EMA بدل SMA، أو تجاهل smooth_k |
| WMA | أوزان `period, period-1, ..., 1` | أوزان متساوية أو معكوسة |

---

## ملاحظة عامة عن التحقّق

عند تجربة فلتر جديد:
1. ارفعه واختر إطار الفلتر (5m / 15m / 1h) من واجهة التطبيق.
2. ابدأ بفترة بيانات متطابقة بين التطبيق و TradingView.
3. توقّع فرقاً صغيراً جداً في أوّل صفقتين أو ثلاث بسبب الإحماء (Pine يحسب من بداية البيانات الكاملة المتاحة على TradingView).
4. إذا ظهر فرق في **منتصف** البيانات، فالخطأ غالباً في الصيغة (نوع المتوسط أو البذرة)، وليس في الإحماء.
