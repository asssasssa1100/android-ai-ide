# Trading Lab Android — سجل التقدم

## المشروع
تطبيق Android تحليل تداول يعمل بـ Chaquopy 15 + Python 3.11 + Flask 3.0.3.  
ثلاث صفحات رئيسية: **البيانات** — **المؤشرات** — **الاختبار** (+تحليل).

---

## v5 — 2026-05 (الإصدار الحالي)

### إصلاحات جذرية

| # | المشكلة | السبب | الحل |
|---|---------|-------|------|
| 1 | "ملف المؤشر مفقود" عند التحقق | Chaquopy لا يكتب ملفات APK لنظام ملفات عادي | نسخ `indicators/builtin/*.py` إلى `INDICATORS_DIR/builtin/` في `main.py` عند بدء التشغيل |
| 2 | `KeyError: 'timestamp'` في stoch/breakout | `_df_to_list()` يُنتج مفتاح `"time"` لكن المؤشرات تستخدم `"timestamp"` | إضافة `_get_ts()` في المؤشرات للتعامل مع كلا المفتاحين |
| 3 | `NOT NULL constraint failed: tests.signal_id` | الـ INSERT لم يوفر `signal_id` و `symbol` | تحديث الـ INSERT في `test_routes.py` |

### ميزات جديدة

| # | الميزة | الوصف |
|---|--------|-------|
| 4 | جدول `filter_results` | تخزين الشموع النشطة لكل (مؤشر فلتر × عملة × إطار زمني) |
| 5 | نقطة نهاية الحساب الحقيقي | `POST /api/data/currencies/<sym>/filters/<tf>/compute` |
| 6 | `filter_service.py` | خدمة تشغيل جميع مؤشرات الفلتر وحفظ النتائج |
| 7 | `csCompute()` حقيقي | استبدال `setTimeout` المزيف بطلب API فعلي |
| 8 | حالة `error` في الشريط | إضافة لون أحمر + `✗` عند فشل حساب فريم |

---

## v4 — 2026-04 (الإصدار السابق)

- إضافة مؤشرات مدمجة: Stochastic Crossover و Pivot High Breakout  
- إصلاح عداد التحقق 0/N
- إصلاح بطاقة التحليل (UI)
- إعادة كتابة `test_routes.py`

---

## v3 — 2026-04

- دمج مشروع Android القديم (Flask+Chaquopy) مع الواجهة الويب الجديدة  
- بنية قواعد البيانات: indicators, tests, test_trades, currencies, filter_results  
- نظام الطرق: data / indicators / test / analysis / audit

---

## البنية التقنية الحالية

```
app/src/main/python/
├── main.py                      ← نقطة دخول + نسخ builtins
├── config.py                    ← المسارات والثوابت
├── db.py                        ← تهيئة SQLite + جميع الجداول
├── indicators/
│   └── builtin/
│       ├── stoch.py             ← Stochastic Crossover (يدعم كلا المفتاحين)
│       └── breakout.py          ← Pivot High Breakout (يدعم كلا المفتاحين)
├── routes/
│   ├── data_routes.py           ← بيانات OHLCV + حساب الفلاتر
│   ├── indicators_routes.py     ← CRUD المؤشرات + verify
│   ├── test_routes.py           ← إنشاء/تشغيل/متابعة الاختبارات
│   ├── analysis_routes.py       ← إحصاءات التحليل
│   └── audit_routes.py          ← سجل العمليات
├── services/
│   ├── backtest_service.py      ← تشغيل اختبار إشارة على رمز
│   └── filter_service.py        ← تشغيل فلاتر على (رمز × إطار)
└── www/
    ├── index.html
    └── js/app.js
```

---

## قواعد البيانات

| الجدول | الغرض |
|--------|-------|
| `currencies` | قائمة العملات مع معلومات البيانات |
| `indicators` | المؤشرات المرفوعة (signal / filter) |
| `tests` | الاختبارات الكاملة |
| `test_trades` | الصفقات الفردية لكل اختبار |
| `filter_results` | الشموع النشطة لكل (مؤشر × عملة × فريم) |

---

## المشاكل المعروفة المتبقية

- [ ] صفحة التحليل: الرسم البياني للأداء التراكمي لم يُنفَّذ بعد
- [ ] إشعارات التقدم أثناء تشغيل الاختبار (WebSocket أو SSE)
- [ ] دعم مؤشرات الفلتر المدمجة (حالياً لا يوجد builtin من نوع filter)
- [ ] صفحة الاختبار: عرض تفاصيل الصفقات الفردية (win/loss/open)

---

## تعليمات البناء

```bash
# GitHub Actions → يُبنى تلقائياً عبر .github/workflows/build.yml
# Chaquopy 15 / AGP 8.x / Kotlin 1.9
./gradlew assembleDebug
```
