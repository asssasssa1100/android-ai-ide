# مرجع مؤشرات الإشارة (SIGNAL) — مطابقة لـ TradingView

هذا الملف يحتوي على وصفات جاهزة للنسخ لأشهر مؤشرات الإشارة (نقاط الدخول).
كل مثال:
- يعتمد التوقيع الموحَّد `generate_signals(df, params)` على شموع **5m**.
- يستعمل الدوال المساعدة في `engine.filter_helpers` (مطابقة لـ Pine Script).
- يفحص التقاطع على شمعتين متتاليتين (يتجنّب الإشارات المتكرّرة).
- يحترم بذرة SMA في كل المؤشرات الأُسّية.

> فرق مهم بين الإشارة والفلتر:
> - **الإشارة (signal):** تُعطي **لحظة دخول واحدة** (timestamp واحد لكل صفقة).
> - **الفلتر (filter):** يُعطي **حالة boolean** عند كل شمعة (نشط/مغلق).
> الإشارة تنشئ صفقة جديدة، الفلتر يقبل/يرفض صفقة قائمة.

---

## فهرس الفئات

1. [تقاطعات المتوسطات](#1-تقاطعات-المتوسطات)
   - EMA Cross, SMA Cross, MACD Cross
2. [مذبذبات](#2-مذبذبات)
   - RSI Reversal, Stochastic Cross, CCI Zero-Cross
3. [اختراقات (Breakouts)](#3-اختراقات-breakouts)
   - Donchian Breakout, Bollinger Breakout, Pivot Breakout
4. [اتجاه + زخم مركّب](#4-اتجاه--زخم-مركّب)
   - Triple EMA + RSI, Bollinger Squeeze Release

---

## القاعدة الذهبية للتقاطع (Crossover)

دائماً افحص **شمعتين**:

```python
if prev_a <= prev_b and curr_a > curr_b:
    # هذه لحظة تقاطع صاعد حقيقية
    ...
```

❌ الخطأ الشائع: فحص شمعة واحدة فقط:
```python
if curr_a > curr_b:    # ← هذا يولّد إشارة عند *كل* شمعة فوق المؤشر
    ...
```

---

## 1) تقاطعات المتوسطات

### 1.1 EMA Cross — تقاطع متوسطين أُسّيين
**الفكرة:** EMA سريع يتقاطع فوق EMA بطيء.
**الإحماء:** أكبر قيمة من `fast / slow` (يُلتقط تلقائياً).

```python
from engine.filter_helpers import ema_pine

INDICATOR_NAME    = "EMA Cross"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"fast": 9, "slow": 21}

def generate_signals(df, params=None):
    p = params or PARAMETERS
    fast = int(p.get("fast", 9))
    slow = int(p.get("slow", 21))
    closes = [r["close"] for r in df]
    ef = ema_pine(closes, fast)
    es = ema_pine(closes, slow)
    out = []
    for i in range(1, len(df)):
        if None in (ef[i], es[i], ef[i-1], es[i-1]):
            continue
        if ef[i-1] <= es[i-1] and ef[i] > es[i]:
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"EMA{fast}↑EMA{slow}",
            })
    return out
```

### 1.2 SMA Cross — تقاطع متوسطين بسيطين

```python
from engine.filter_helpers import sma_pine

INDICATOR_NAME    = "SMA Cross"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"fast": 20, "slow": 50}

def generate_signals(df, params=None):
    p = params or PARAMETERS
    fast = int(p.get("fast", 20))
    slow = int(p.get("slow", 50))
    closes = [r["close"] for r in df]
    sf = sma_pine(closes, fast)
    ss = sma_pine(closes, slow)
    out = []
    for i in range(1, len(df)):
        if None in (sf[i], ss[i], sf[i-1], ss[i-1]):
            continue
        if sf[i-1] <= ss[i-1] and sf[i] > ss[i]:
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"SMA{fast}↑SMA{slow}",
            })
    return out
```

### 1.3 MACD Cross — تقاطع MACD فوق خط الإشارة
**الفكرة:** الفرق بين EMA(fast) و EMA(slow) يتقاطع فوق EMA(signal) على هذا الفرق.

```python
from engine.filter_helpers import ema_pine

INDICATOR_NAME    = "MACD Cross"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"fast": 12, "slow": 26, "signal": 9}

def generate_signals(df, params=None):
    p = params or PARAMETERS
    fast   = int(p.get("fast", 12))
    slow   = int(p.get("slow", 26))
    signal = int(p.get("signal", 9))
    closes = [r["close"] for r in df]
    ef = ema_pine(closes, fast)
    es = ema_pine(closes, slow)
    macd = [None if (a is None or b is None) else a - b for a, b in zip(ef, es)]
    valid = [v for v in macd if v is not None]
    sig_valid = ema_pine(valid, signal)
    pad = len(macd) - len(sig_valid)
    sig = [None] * pad + sig_valid
    out = []
    for i in range(1, len(df)):
        if None in (macd[i], sig[i], macd[i-1], sig[i-1]):
            continue
        if macd[i-1] <= sig[i-1] and macd[i] > sig[i]:
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"MACD↑Signal",
            })
    return out
```

---

## 2) مذبذبات

### 2.1 RSI Reversal — خروج من التشبّع البيعي
**الفكرة:** RSI يتجاوز من تحت 30 إلى فوقها (اتفاقي على ارتداد).
**النقطة الحرجة:** RSI = `rma_pine` (وليس EMA).

```python
from engine.filter_helpers import rma_pine

INDICATOR_NAME    = "RSI Oversold Reversal"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"period": 14, "oversold": 30}

def generate_signals(df, params=None):
    p = params or PARAMETERS
    period   = int(p.get("period", 14))
    oversold = float(p.get("oversold", 30))
    closes = [r["close"] for r in df]
    n = len(closes)
    gains  = [0.0] * n
    losses = [0.0] * n
    for i in range(1, n):
        ch = closes[i] - closes[i-1]
        gains[i]  =  ch if ch > 0 else 0.0
        losses[i] = -ch if ch < 0 else 0.0
    avg_g = rma_pine(gains, period)
    avg_l = rma_pine(losses, period)
    rsi = []
    for g, l in zip(avg_g, avg_l):
        if g is None or l is None: rsi.append(None)
        elif l == 0:               rsi.append(100.0)
        else:                      rsi.append(100.0 - 100.0 / (1.0 + g / l))
    out = []
    for i in range(1, n):
        if rsi[i] is None or rsi[i-1] is None: continue
        if rsi[i-1] <= oversold and rsi[i] > oversold:
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"RSI({round(rsi[i],1)})↑{int(oversold)}",
            })
    return out
```

### 2.2 Stochastic Cross — تقاطع %K فوق %D
**النقطة الحرجة:** التنعيم بـ `sma_pine` (مطابق Pine). افتراضي smooth_k=1 (بدون تنعيم) كما في TradingView.

```python
from engine.filter_helpers import sma_pine

INDICATOR_NAME    = "Stoch Cross"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"k_period": 14, "smooth_k": 1, "d_period": 3}

def generate_signals(df, params=None):
    p  = params or PARAMETERS
    kp = int(p.get("k_period", 14))
    sk = int(p.get("smooth_k", 1))
    dp = int(p.get("d_period", 3))
    n = len(df)
    raw_k = [None] * n
    for i in range(kp - 1, n):
        window = df[i - kp + 1:i + 1]
        hh = max(r["high"] for r in window)
        ll = min(r["low"]  for r in window)
        c  = df[i]["close"]
        raw_k[i] = 100.0 if hh == ll else (c - ll) / (hh - ll) * 100.0
    valid_k = [v for v in raw_k if v is not None]
    smooth = sma_pine(valid_k, sk) if sk > 1 else valid_k[:]
    pad = n - len(smooth)
    k_line = [None] * pad + smooth
    valid_d = [v for v in k_line if v is not None]
    d_smooth = sma_pine(valid_d, dp)
    pad2 = n - len(d_smooth)
    d_line = [None] * pad2 + d_smooth
    out = []
    for i in range(1, n):
        if None in (k_line[i], d_line[i], k_line[i-1], d_line[i-1]):
            continue
        if k_line[i-1] <= d_line[i-1] and k_line[i] > d_line[i]:
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"K({round(k_line[i],1)})↑D({round(d_line[i],1)})",
            })
    return out
```

### 2.3 CCI Zero-Cross — تجاوز الصفر
**الفكرة:** CCI ينتقل من سالب إلى موجب (دخول قوة شرائية).

```python
from engine.filter_helpers import sma_pine

INDICATOR_NAME    = "CCI Zero Cross"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"period": 20}

def generate_signals(df, params=None):
    p = params or PARAMETERS
    period = int(p.get("period", 20))
    tp = [(r["high"] + r["low"] + r["close"]) / 3.0 for r in df]
    ma = sma_pine(tp, period)
    n = len(tp)
    cci = [None] * n
    for i in range(period - 1, n):
        m = ma[i]
        if m is None: continue
        mad = sum(abs(tp[j] - m) for j in range(i - period + 1, i + 1)) / period
        cci[i] = 0.0 if mad == 0 else (tp[i] - m) / (0.015 * mad)
    out = []
    for i in range(1, n):
        if cci[i] is None or cci[i-1] is None: continue
        if cci[i-1] <= 0 and cci[i] > 0:
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"CCI ↑0",
            })
    return out
```

---

## 3) اختراقات (Breakouts)

### 3.1 Donchian Breakout — كسر أعلى قمة آخر N شمعة
**الفكرة:** الإغلاق الحالي يتجاوز أعلى high في النافذة (لا يشمل الشمعة الحالية).

```python
INDICATOR_NAME    = "Donchian Breakout"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"period": 20}

def generate_signals(df, params=None):
    p = params or PARAMETERS
    period = int(p.get("period", 20))
    out = []
    for i in range(period, len(df)):
        hh = max(r["high"] for r in df[i-period:i])
        if df[i]["close"] > hh and df[i-1]["close"] <= hh:
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"كسر قمة {round(hh,4)}",
            })
    return out
```

### 3.2 Bollinger Breakout — اختراق الحد العلوي
**الفكرة:** الإغلاق يتجاوز SMA + mult × stdev (وليس داخل النطاق).

```python
from engine.filter_helpers import sma_pine, stdev_pine

INDICATOR_NAME    = "BB Upper Breakout"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"period": 20, "mult": 2.0}

def generate_signals(df, params=None):
    p = params or PARAMETERS
    period = int(p.get("period", 20))
    mult   = float(p.get("mult", 2.0))
    closes = [r["close"] for r in df]
    basis = sma_pine(closes, period)
    sd    = stdev_pine(closes, period)
    upper = [None if (b is None or s is None) else b + mult * s
             for b, s in zip(basis, sd)]
    out = []
    for i in range(1, len(df)):
        if upper[i] is None or upper[i-1] is None: continue
        if df[i]["close"] > upper[i] and df[i-1]["close"] <= upper[i-1]:
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"كسر BB-Upper",
            })
    return out
```

### 3.3 Pivot Breakout — كسر آخر قمة محلية
هذه الإشارة موجودة كـ built-in (`breakout`) — انظر `engine/builtin_signals.py`. هذا التكرار للوصول من ملف خارجي إن أردت تعديل المنطق.

```python
INDICATOR_NAME    = "Pivot Breakout"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"pivot_bars": 2}

def generate_signals(df, params=None):
    p = params or PARAMETERS
    pb = int(p.get("pivot_bars", 2))
    n = len(df)
    highs = [r["high"] for r in df]
    pivots = [None] * n
    for i in range(pb, n - pb):
        if (all(highs[i] > highs[i-j] for j in range(1, pb+1)) and
            all(highs[i] > highs[i+j] for j in range(1, pb+1))):
            pivots[i] = highs[i]
    out = []
    last = None
    for i in range(pb, n):
        ci = i - pb
        if ci >= 0 and pivots[ci] is not None:
            last = pivots[ci]
        if last is None: continue
        if i > 0 and df[i]["close"] > last and df[i-1]["close"] <= last:
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"كسر قمة {round(last,4)}",
            })
            last = None
    return out
```

---

## 4) اتجاه + زخم مركّب

### 4.1 Triple EMA + RSI Filter
**الفكرة:** تقاطع EMA(fast) فوق EMA(slow) + شرط RSI > 50 + اتجاه EMA(trend) صاعد.
**فائدة:** يقلّل الإشارات الكاذبة في الترند الهابط.

```python
from engine.filter_helpers import ema_pine, rma_pine

INDICATOR_NAME    = "Triple EMA + RSI"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"fast": 9, "slow": 21, "trend": 50, "rsi_period": 14, "rsi_min": 50}

def generate_signals(df, params=None):
    p = params or PARAMETERS
    fast   = int(p.get("fast", 9))
    slow   = int(p.get("slow", 21))
    trend  = int(p.get("trend", 50))
    rp     = int(p.get("rsi_period", 14))
    rmin   = float(p.get("rsi_min", 50))
    closes = [r["close"] for r in df]
    n = len(closes)
    ef = ema_pine(closes, fast)
    es = ema_pine(closes, slow)
    et = ema_pine(closes, trend)
    # RSI
    g = [0.0] * n; l = [0.0] * n
    for i in range(1, n):
        ch = closes[i] - closes[i-1]
        g[i] =  ch if ch > 0 else 0.0
        l[i] = -ch if ch < 0 else 0.0
    ag = rma_pine(g, rp); al = rma_pine(l, rp)
    rsi = []
    for x, y in zip(ag, al):
        if x is None or y is None: rsi.append(None)
        elif y == 0:               rsi.append(100.0)
        else:                      rsi.append(100.0 - 100.0 / (1.0 + x / y))
    out = []
    for i in range(1, n):
        if None in (ef[i], es[i], et[i], rsi[i], ef[i-1], es[i-1]):
            continue
        # تقاطع EMA + ترند صاعد + RSI صحي
        if (ef[i-1] <= es[i-1] and ef[i] > es[i]
                and closes[i] > et[i]
                and rsi[i] > rmin):
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"EMA↑ + RSI({round(rsi[i],1)})>{int(rmin)}",
            })
    return out
```

### 4.2 Bollinger Squeeze Release
**الفكرة:** بعد فترة ضيق نطاق (عرض BB < عتبة)، أوّل إغلاق فوق الـ basis = إشارة دخول.

```python
from engine.filter_helpers import sma_pine, stdev_pine

INDICATOR_NAME    = "BB Squeeze Release"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"period": 20, "mult": 2.0, "squeeze_max_pct": 4.0}

def generate_signals(df, params=None):
    p = params or PARAMETERS
    period          = int(p.get("period", 20))
    mult            = float(p.get("mult", 2.0))
    squeeze_max_pct = float(p.get("squeeze_max_pct", 4.0))
    closes = [r["close"] for r in df]
    basis = sma_pine(closes, period)
    sd    = stdev_pine(closes, period)
    out = []
    in_squeeze = False
    for i in range(1, len(df)):
        if basis[i] is None or sd[i] is None: continue
        upper = basis[i] + mult * sd[i]
        lower = basis[i] - mult * sd[i]
        width_pct = (upper - lower) / basis[i] * 100 if basis[i] else 0
        if width_pct <= squeeze_max_pct:
            in_squeeze = True
            continue
        if in_squeeze and closes[i] > basis[i] and closes[i-1] <= basis[i-1]:
            out.append({
                "timestamp": df[i]["timestamp"],
                "price":     df[i]["close"],
                "reason":    f"BB Squeeze release",
            })
            in_squeeze = False
    return out
```

---

## ملاحظات مهمّة

| النقطة | التفصيل |
|---|---|
| **التوقيت** | الإشارة تنشئ صفقة تدخل عند `close` للشمعة، و SL/TP يُحسبان لاحقاً في trade_sim. |
| **التكرار** | استعمل دائماً فحص شمعتين (prev/curr) لتجنّب إشارات مكرّرة في كل شمعة. |
| **الإحماء** | المحرّك يحذف تلقائياً أي إشارة قبل أكبر فترة إحماء في PARAMETERS. لا تحتاج فعل شيء يدوياً. |
| **الاختبار** | بعد كتابة المؤشر: ارفعه من صفحة "المؤشرات" → جرّبه في "الاختبار" على عملة → راجع winrate في "التحليل". |
| **التحقّق من المطابقة** | إن لم تتطابق نتائجك مع TradingView، تحقّق أوّلاً من نوع المتوسط (SMA/EMA/RMA) وعدد الشموع المستعملة في كل حساب. |
