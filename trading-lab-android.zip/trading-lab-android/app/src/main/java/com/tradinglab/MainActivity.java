package com.tradinglab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.JsPromptResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.LinearLayout;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {

    private WebView      webView;
    private LinearLayout loadingLayout;
    private TextView     loadingText;
    private ValueCallback<Uri[]> mFileCallback;

    private static final int PORT            = 5000;
    private static final int MAX_RETRIES     = 40;
    private static final int FILE_CHOOSER_RC = 101;
    private static final int NOTIF_PERM_RC   = 102;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView       = findViewById(R.id.webview);
        loadingLayout = findViewById(R.id.loading_layout);
        loadingText   = findViewById(R.id.loading_text);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(
                new String[]{"android.permission.POST_NOTIFICATIONS"},
                NOTIF_PERM_RC);
        }

        setupWebView();
        startFlaskAndService();
    }

    /** جسر JS ⇄ Java لتحديث إشعار التقدّم من واجهة الويب */
    private class TLBridge {
        @JavascriptInterface
        public void notify(String title, String text, int progress) {
            try {
                TradingLabService.update(MainActivity.this,
                    title != null ? title : "⚡ Trading Lab",
                    text  != null ? text  : "",
                    progress);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void clearNotify() {
            try { TradingLabService.clear(MainActivity.this); }
            catch (Exception ignored) {}
        }
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new TLBridge(), "TLNotif");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv,
                    ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (mFileCallback != null) mFileCallback.onReceiveValue(null);
                mFileCallback = cb;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                startActivityForResult(
                    Intent.createChooser(intent, "اختر ملف"), FILE_CHOOSER_RC);
                return true;
            }

            // ── دعم confirm()/alert()/prompt() داخل WebView ──
            @Override
            public boolean onJsAlert(WebView view, String url, String message,
                                     final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("حسناً",
                        (d, w) -> result.confirm())
                    .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message,
                                       final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton("نعم",
                        (d, w) -> result.confirm())
                    .setNegativeButton("لا",
                        (d, w) -> result.cancel())
                    .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message,
                                      String defaultValue,
                                      final JsPromptResult result) {
                final EditText input = new EditText(MainActivity.this);
                if (defaultValue != null) input.setText(defaultValue);
                new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setView(input)
                    .setCancelable(false)
                    .setPositiveButton("حسناً",
                        (d, w) -> result.confirm(input.getText().toString()))
                    .setNegativeButton("إلغاء",
                        (d, w) -> result.cancel())
                    .show();
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                loadingLayout.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == FILE_CHOOSER_RC) {
            Uri[] results = null;
            if (res == RESULT_OK && data != null) {
                String ds = data.getDataString();
                if (ds != null) results = new Uri[]{ Uri.parse(ds) };
            }
            if (mFileCallback != null) {
                mFileCallback.onReceiveValue(results);
                mFileCallback = null;
            }
        }
    }

    private void startFlaskAndService() {
        loadingText.setText("جاري تشغيل Trading Lab...");

        new Thread(() -> {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(this));
            }
            Python py = Python.getInstance();
            String dataDir = getFilesDir().getAbsolutePath();
            py.getModule("server_config").callAttr("set_data_dir", dataDir);

            new Thread(() -> {
                try {
                    py.getModule("main").callAttr("start_server", PORT);
                } catch (Exception e) { e.printStackTrace(); }
            }).start();

            try {
                Intent svc = new Intent(this, TradingLabService.class);
                startForegroundService(svc);
            } catch (Exception e) {
                e.printStackTrace();
            }

            waitForServer();
        }).start();
    }

    private void waitForServer() {
        new Handler(Looper.getMainLooper()).post(() ->
            loadingText.setText("جاري التحضير..."));

        for (int i = 0; i < MAX_RETRIES; i++) {
            try {
                Thread.sleep(500);
                java.net.Socket s = new java.net.Socket("127.0.0.1", PORT);
                s.close();
                new Handler(Looper.getMainLooper()).post(this::loadWebView);
                return;
            } catch (Exception ignored) {}
        }

        new Handler(Looper.getMainLooper()).post(() ->
            loadingText.setText("⚠️ تعذر تشغيل السيرفر — أعد تشغيل التطبيق"));
    }

    private void loadWebView() {
        webView.loadUrl("http://127.0.0.1:" + PORT);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
