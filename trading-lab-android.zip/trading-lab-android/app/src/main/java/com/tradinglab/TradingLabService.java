package com.tradinglab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.os.IBinder;

public class TradingLabService extends Service {

    static final String CHANNEL_ID      = "TradingLabChannel";
    static final int    NOTIFICATION_ID = 101;

    static final String ACTION_UPDATE   = "UPDATE_PROGRESS";
    static final String ACTION_CLEAR    = "CLEAR_PROGRESS";
    static final String ACTION_STOP     = "STOP_SERVICE";
    static final String ACTION_QUIT     = "QUIT_APP";

    static final String EXTRA_TITLE     = "title";
    static final String EXTRA_TEXT      = "text";
    static final String EXTRA_PROGRESS  = "progress";  // -1 = no bar, -2 = indeterminate, 0..100

    static final int    SERVER_PORT     = 5000;
    static final int    BRAND_COLOR     = 0xFF10B981;  // emerald

    private NotificationManager nm;
    private String  curText     = "يعمل في الخلفية";
    private int     curProgress = -1;

    @Override
    public void onCreate() {
        super.onCreate();
        nm = getSystemService(NotificationManager.class);
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotif());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_UPDATE.equals(action)) {
                String x = intent.getStringExtra(EXTRA_TEXT);
                int    p = intent.getIntExtra(EXTRA_PROGRESS, -1);
                // العنوان دائماً ثابت؛ نتجاهل أي عنوان مُمرَّر لمنع الفوضى
                if (x != null && x.length() > 0) curText = x;
                curProgress = p;
                nm.notify(NOTIFICATION_ID, buildNotif());
            } else if (ACTION_CLEAR.equals(action)) {
                curText     = "يعمل في الخلفية";
                curProgress = -1;
                nm.notify(NOTIFICATION_ID, buildNotif());
            } else if (ACTION_STOP.equals(action)) {
                stopForeground(true);
                stopSelf();
            } else if (ACTION_QUIT.equals(action)) {
                handleQuit();
            }
        }
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent i) { return null; }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(
            CHANNEL_ID, "Trading Lab", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("تقدّم عمليات Trading Lab");
        ch.setShowBadge(false);
        ch.enableVibration(false);
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
    }

    private Notification buildNotif() {
        // ── النقر على الإشعار يفتح التطبيق ──
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPI = PendingIntent.getActivity(
            this, 0, open, PendingIntent.FLAG_IMMUTABLE);

        // ── زر "إيقاف وإغلاق" ──
        Intent quit = new Intent(this, TradingLabService.class)
            .setAction(ACTION_QUIT);
        PendingIntent quitPI = PendingIntent.getService(
            this, 1, quit,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Action quitAction = new Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "إيقاف وإغلاق",
            quitPI
        ).build();

        // ── النص الفرعي = نسبة التقدّم (إن وُجدت) ──
        String subText = null;
        if (curProgress >= 0 && curProgress <= 100) subText = curProgress + "%";
        else if (curProgress == -2)                  subText = "...";

        Notification.Builder b = new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("⚡ Trading Lab")
            .setContentText(curText)
            .setSubText(subText)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setColor(BRAND_COLOR)
            .setColorized(false)
            .setContentIntent(openPI)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(quitAction);

        if (curProgress >= 0 && curProgress <= 100) {
            b.setProgress(100, curProgress, false);
        } else if (curProgress == -2) {
            b.setProgress(0, 0, true);
        }
        // -1 = بلا شريط (حالة خامول)
        return b.build();
    }

    /**
     * إيقاف وإغلاق كامل:
     *  1. عرض حالة "جاري الإيقاف..." في الإشعار
     *  2. إخبار سيرفر Flask بإيقاف كل العمليات (pause-all → تُحفظ تلقائياً)
     *  3. إيقاف الخدمة وإزالة الإشعار
     *  4. قتل العملية → يُغلق Activity + Python + Flask
     */
    private void handleQuit() {
        curText = "جاري إيقاف العمليات...";
        curProgress = -2;
        try { nm.notify(NOTIFICATION_ID, buildNotif()); } catch (Exception ignored) {}

        new Thread(() -> {
            // اطلب من السيرفر حفظ كل المهام النشطة
            try {
                java.net.URL url = new java.net.URL(
                    "http://127.0.0.1:" + SERVER_PORT + "/api/quit");
                java.net.HttpURLConnection conn =
                    (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(800);
                conn.setReadTimeout(2500);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                try (java.io.OutputStream os = conn.getOutputStream()) {
                    os.write("{}".getBytes("UTF-8"));
                }
                conn.getInputStream().close();
            } catch (Exception ignored) {}

            // أزل الإشعار وأوقف الخدمة
            try { stopForeground(true); } catch (Exception ignored) {}
            try { nm.cancel(NOTIFICATION_ID); } catch (Exception ignored) {}
            try { stopSelf(); } catch (Exception ignored) {}

            // قتل العملية كاملة (Activity + Flask + Python)
            try { Thread.sleep(150); } catch (Exception ignored) {}
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(0);
        }).start();
    }

    // ── واجهات استدعاء سهلة ──
    public static void update(Context ctx, String title, String text, int progress) {
        Intent i = new Intent(ctx, TradingLabService.class);
        i.setAction(ACTION_UPDATE);
        i.putExtra(EXTRA_TITLE, title);
        i.putExtra(EXTRA_TEXT, text);
        i.putExtra(EXTRA_PROGRESS, progress);
        ctx.startService(i);
    }

    public static void clear(Context ctx) {
        Intent i = new Intent(ctx, TradingLabService.class);
        i.setAction(ACTION_CLEAR);
        ctx.startService(i);
    }
}
