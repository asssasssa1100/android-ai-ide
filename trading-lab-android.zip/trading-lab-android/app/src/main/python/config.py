"""config.py — إعدادات التطبيق (Android + Web)"""
import os

# ─── مسارات البيانات ───────────────────────────────────────────
_BASE = os.environ.get("TRADING_LAB_DATA", "/tmp/trading_lab")

DATA_DIR       = os.environ.get("TL_DATA_DIR",  os.path.join(_BASE, "data"))
INDICATORS_DIR = os.environ.get("TL_IND_DIR",   os.path.join(_BASE, "indicators"))
DB_PATH        = os.path.join(_BASE, "trading_lab.db")

os.makedirs(DATA_DIR,       exist_ok=True)
os.makedirs(INDICATORS_DIR, exist_ok=True)

# ─── Binance ───────────────────────────────────────────────────
BINANCE_BASE_URL     = "https://data-api.binance.vision/api/v3"
BINANCE_KLINES_LIMIT = 1000
FETCH_START_MS       = 1483228800000  # 2017-01-01 UTC

# ─── الإشارات المدمجة ─────────────────────────────────────────
BUILTIN_SIGNALS = {
    "stoch": {
        "name":        "Stochastic Crossover",
        "description": "تقاطع %K و %D لمؤشر Stochastic",
        "parameters":  {"k_period": 14, "smooth_k": 1, "d_period": 3},
    },
    "breakout": {
        "name":        "Pivot High Breakout",
        "description": "كسر أعلى نقطة محورية سابقة",
        "parameters":  {"pivot_bars": 2},
    },
}
