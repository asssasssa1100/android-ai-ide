import sqlite3
import json
from config import DB_PATH


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()

    # Currencies
    c.execute("""
        CREATE TABLE IF NOT EXISTS currencies (
            symbol      TEXT PRIMARY KEY,
            currency_id TEXT NOT NULL DEFAULT '',
            candles     INTEGER DEFAULT 0,
            first_ts    INTEGER,
            last_ts     INTEGER,
            fetching    INTEGER DEFAULT 0,
            fetch_pct   REAL    DEFAULT 0
        )
    """)

    # Per-timeframe resampled data
    c.execute("""
        CREATE TABLE IF NOT EXISTS currency_tfs (
            symbol      TEXT NOT NULL,
            tf          TEXT NOT NULL,
            candles     INTEGER DEFAULT 0,
            first_ts    INTEGER,
            last_ts     INTEGER,
            PRIMARY KEY (symbol, tf)
        )
    """)

    # Uploaded indicators (.py files)
    c.execute("""
        CREATE TABLE IF NOT EXISTS indicators (
            id          TEXT PRIMARY KEY,
            name        TEXT NOT NULL,
            version     TEXT,
            type        TEXT NOT NULL,
            filename    TEXT NOT NULL,
            params_json TEXT DEFAULT '{}'
        )
    """)

    # Backtest jobs + results
    c.execute("""
        CREATE TABLE IF NOT EXISTS tests (
            id          TEXT PRIMARY KEY,
            symbol      TEXT NOT NULL,
            signal_id   TEXT NOT NULL,
            params_json TEXT DEFAULT '{}',
            rr          REAL DEFAULT 2.0,
            status      TEXT DEFAULT 'pending',
            progress    REAL DEFAULT 0,
            trades      INTEGER DEFAULT 0,
            wins        INTEGER DEFAULT 0,
            losses      INTEGER DEFAULT 0,
            opens       INTEGER DEFAULT 0,
            wr          REAL DEFAULT 0,
            created_at  INTEGER,
            finished_at INTEGER,
            result_json TEXT DEFAULT '[]'
        )
    """)

    # Analysis jobs + results
    c.execute("""
        CREATE TABLE IF NOT EXISTS analyses (
            id              TEXT PRIMARY KEY,
            test_id         TEXT NOT NULL,
            filters_json    TEXT DEFAULT '[]',
            status          TEXT DEFAULT 'pending',
            progress        REAL DEFAULT 0,
            trades_before   INTEGER DEFAULT 0,
            trades_after    INTEGER DEFAULT 0,
            wr_before       REAL DEFAULT 0,
            wr_after        REAL DEFAULT 0,
            created_at      INTEGER,
            finished_at     INTEGER,
            result_json     TEXT DEFAULT '[]'
        )
    """)

    # Top10 results
    c.execute("""
        CREATE TABLE IF NOT EXISTS top10 (
            id              TEXT PRIMARY KEY,
            test_id         TEXT NOT NULL,
            status          TEXT DEFAULT 'pending',
            progress        REAL DEFAULT 0,
            combos_tested   INTEGER DEFAULT 0,
            created_at      INTEGER,
            finished_at     INTEGER,
            result_json     TEXT DEFAULT '[]'
        )
    """)

    # Audit jobs + results
    c.execute("""
        CREATE TABLE IF NOT EXISTS audits (
            id              TEXT PRIMARY KEY,
            signal_id       TEXT NOT NULL,
            signal_params   TEXT DEFAULT '{}',
            filters_json    TEXT DEFAULT '[]',
            rr              REAL DEFAULT 2.0,
            currencies_json TEXT DEFAULT '[]',
            status          TEXT DEFAULT 'pending',
            progress        REAL DEFAULT 0,
            total_trades    INTEGER DEFAULT 0,
            total_wr        REAL DEFAULT 0,
            created_at      INTEGER,
            finished_at     INTEGER,
            result_json     TEXT DEFAULT '[]'
        )
    """)

    # Filter results
    c.execute("""
        CREATE TABLE IF NOT EXISTS filter_results (
            indicator_id  TEXT NOT NULL,
            symbol        TEXT NOT NULL,
            tf            TEXT NOT NULL,
            computed_at   INTEGER,
            candle_count  INTEGER DEFAULT 0,
            candles_json  TEXT    DEFAULT '[]',
            PRIMARY KEY (indicator_id, symbol, tf)
        )
    """)

    # Migrate tests table
    _add_columns(conn, "tests", [
        ("signal_name",  "TEXT    DEFAULT ''"),
        ("symbols_json", "TEXT    DEFAULT '[]'"),
        ("tf",           "TEXT    DEFAULT '5m'"),
        ("net_pnl",      "REAL    DEFAULT 0"),
        ("win_rate",     "REAL    DEFAULT 0"),
    ])

    # Migrate analyses table
    _add_columns(conn, "analyses", [
        ("signal_name",  "TEXT    DEFAULT ''"),
        ("symbol",       "TEXT    DEFAULT ''"),
        ("wins",         "INTEGER DEFAULT 0"),
        ("losses",       "INTEGER DEFAULT 0"),
        ("win_rate",     "REAL    DEFAULT 0"),
    ])

    # Migrate top10 table — new columns for hybrid search + pause/resume
    _add_columns(conn, "top10", [
        ("signal_name",      "TEXT    DEFAULT ''"),
        ("symbol",           "TEXT    DEFAULT ''"),
        ("min_coverage_pct", "REAL    DEFAULT 20"),
        ("min_trades",       "INTEGER DEFAULT 5"),
        ("checkpoint_json",  "TEXT    DEFAULT '{}'"),
        ("total_pairs",      "INTEGER DEFAULT 0"),
        ("allowed_tfs_json", "TEXT    DEFAULT '[]'"),
    ])

    # Migrate currencies table
    _add_columns(conn, "currencies", [
        ("currency_id", "TEXT DEFAULT ''"),
    ])

    # Migrate trend_results — add status/progress for async computation
    _add_columns(conn, "trend_results", [
        ("status",   "TEXT DEFAULT 'done'"),
        ("progress", "REAL DEFAULT 0"),
    ])

    # Trend analysis results
    c.execute("""
        CREATE TABLE IF NOT EXISTS trend_results (
            id              TEXT PRIMARY KEY,
            symbol          TEXT NOT NULL,
            allowed_tfs     TEXT DEFAULT '[]',
            min_candles     INTEGER DEFAULT 500,
            min_bullish_pct REAL DEFAULT 50.0,
            max_combo_size  INTEGER DEFAULT 3,
            sort_by         TEXT DEFAULT 'bullish_pct',
            result_json     TEXT DEFAULT '[]',
            result_count    INTEGER DEFAULT 0,
            elapsed_ms      INTEGER DEFAULT 0,
            created_at      INTEGER
        )
    """)

    # Reset any currencies stuck in fetching=1
    c.execute("UPDATE currencies SET fetching=0 WHERE fetching=1")

    conn.commit()
    conn.close()

    _ensure_currency_ids()


def _add_columns(conn, table: str, cols: list):
    for col_name, col_def in cols:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_def}")
            conn.commit()
        except Exception:
            pass


def _ensure_currency_ids():
    from storage import get_or_create_currency
    conn = get_conn()
    rows = conn.execute(
        "SELECT symbol, currency_id FROM currencies WHERE currency_id='' OR currency_id IS NULL"
    ).fetchall()
    for row in rows:
        sym  = row["symbol"]
        info = get_or_create_currency(sym)
        conn.execute(
            "UPDATE currencies SET currency_id=? WHERE symbol=?",
            (info["currency_id"], sym)
        )
    conn.commit()
    conn.close()


def row_to_dict(row):
    if row is None:
        return None
    d = dict(row)
    for k, v in d.items():
        if isinstance(v, str) and (v.startswith('[') or v.startswith('{')):
            try:
                d[k] = json.loads(v)
            except Exception:
                pass
    return d
