"""
مؤشر إشارة — Pivot High Breakout
كسر أعلى قمة محورية (Pivot High) بعد تشكّلها
"""
import numpy as np

INDICATOR_NAME    = "Pivot High Breakout"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"pivot_bars": 2}


def _get_ts(r):
    """Get timestamp from candle dict — supports both 'timestamp' and 'time' keys."""
    return r.get("timestamp") or r.get("time") or 0


def generate_signals(df, params=None):
    """
    df     : list[dict] — {time/timestamp, open, high, low, close, volume}
    params : dict | None
    return : list[dict] — [{"timestamp": ms, "price": float, "reason": str}, ...]
    """
    p          = params or PARAMETERS
    pivot_bars = int(p.get("pivot_bars", 2))
    n          = len(df)

    if n <= 2 * pivot_bars:
        return []

    highs  = np.array([r["high"]   for r in df], dtype=np.float64)
    closes = np.array([r["close"]  for r in df], dtype=np.float64)
    ts     = np.array([_get_ts(r)  for r in df], dtype=np.int64)

    center  = highs[pivot_bars : n - pivot_bars]
    is_piv  = np.ones(n - 2 * pivot_bars, dtype=bool)
    for j in range(1, pivot_bars + 1):
        is_piv &= (center > highs[pivot_bars - j : n - pivot_bars - j])
        is_piv &= (center > highs[pivot_bars + j : n - pivot_bars + j])

    pivot_at = np.zeros(n, dtype=bool)
    pivot_at[pivot_bars : n - pivot_bars] = is_piv

    out  = []
    last = None

    for i in range(pivot_bars, n):
        ci = i - pivot_bars
        if ci >= 0 and pivot_at[ci]:
            last = float(highs[ci])

        if last is None:
            continue

        if i > 0 and closes[i] > last and closes[i - 1] <= last:
            out.append({
                "timestamp": int(ts[i]),
                "price":     float(closes[i]),
                "reason":    f"كسر قمة {round(last, 4)}",
            })
            last = None

    return out
