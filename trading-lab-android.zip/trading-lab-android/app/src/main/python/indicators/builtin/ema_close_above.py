"""
إشارة EMA Close Above
══════════════════════════════════════════════════════════════
الشرط: تقاطع إغلاق السعر صعوداً فوق EMA
        close[i-1] <= EMA[i-1]  AND  close[i] > EMA[i]

مطابق تماماً لـ TradingView:
    ta.crossover(close, ta.ema(close, period))

الخوارزمية: SMA كبذرة → EMA تراكمية (مطابق TV)
══════════════════════════════════════════════════════════════
"""
import numpy as np

INDICATOR_NAME    = "EMA Close Above"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"period": 50}


def _calc_ema(closes: np.ndarray, period: int) -> np.ndarray:
    """
    EMA مطابق TradingView:
    - البذرة: SMA أول (period) شمعة
    - ثم: EMA تراكمية بـ alpha = 2/(period+1)
    """
    n      = len(closes)
    ema    = np.empty(n, dtype=np.float64)
    ema[:] = np.nan

    if n < period:
        return ema

    ema[period - 1] = closes[:period].mean()          # SMA كبذرة
    alpha = 2.0 / (period + 1)
    for i in range(period, n):
        ema[i] = closes[i] * alpha + ema[i - 1] * (1.0 - alpha)

    return ema


def generate_signals(df, params=None):
    """
    df     : list[dict] — {time/timestamp, open, high, low, close, volume}
    params : dict | None — {"period": int}

    يُعيد  : list[dict]
              [{"timestamp": int(ms), "price": float, "reason": str}, ...]

    المنطق: شمعة إغلاقها يتجاوز EMA صعوداً (crossover)
            close[i-1] <= EMA[i-1]  AND  close[i] > EMA[i]
    """
    p      = params or PARAMETERS
    period = max(2, int(p.get("period", 50)))
    n      = len(df)

    if n < period + 2:
        return []

    closes = np.array([float(r["close"])                        for r in df], dtype=np.float64)
    ts     = np.array([int(r.get("timestamp") or r.get("time") or 0) for r in df], dtype=np.int64)

    ema = _calc_ema(closes, period)

    # Vectorized crossover
    prev_c = closes[:-1];  curr_c = closes[1:]
    prev_e = ema[:-1];     curr_e = ema[1:]

    valid  = ~(np.isnan(prev_e) | np.isnan(curr_e))
    cross  = (prev_c <= prev_e) & (curr_c > curr_e) & valid
    idxs   = np.where(cross)[0] + 1           # +1 لأن المصفوفات مزاحة بمقدار 1

    return [
        {
            "timestamp": int(ts[i]),
            "price":     float(closes[i]),
            "reason":    f"Close({round(float(closes[i]), 4)}) ↑ EMA{period}({round(float(ema[i]), 4)})",
        }
        for i in idxs
    ]
