"""
فلتر EMA — مطابق تماماً لـ TradingView ta.ema()
═══════════════════════════════════════════════════════════════
الشرط: close > EMA(close, period)
البذرة: SMA أول (period) شمعة — نفس TradingView
الخوارزمية: SMA بذرة + حلقة EMA تراكمية (مطابق TV — لا يمكن vectorize حلقة EMA)
═══════════════════════════════════════════════════════════════
"""
import numpy as np

INDICATOR_NAME    = "EMA Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 20}


def generate_mask(df, params=None):
    """
    df     : list[dict]  — {time, open, high, low, close, volume}
    params : dict | None — {"period": int}
    يُعيد  : list[dict | None]
              None  → شمعة warmup (قبل أول EMA صالح)
              dict  → {"active": bool, "ema": float}
                       active = True إذا close > EMA(period)
                       ema    = قيمة EMA الفعلية للشمعة
    """
    p      = params or PARAMETERS
    period = max(2, int(p.get("period", 20)))
    n      = len(df)

    result = [None] * n
    if n < period:
        return result

    closes = np.array([float(r["close"]) for r in df], dtype=np.float64)

    # ── حساب EMA مطابق TradingView ──────────────────────────────────────
    # 1. البذرة: SMA أول (period) شمعة
    ema    = np.empty(n, dtype=np.float64)
    ema[:] = np.nan
    ema[period - 1] = closes[:period].mean()   # SMA كبذرة

    # 2. EMA التراكمية من index (period) فصاعداً
    alpha = 2.0 / (period + 1)
    for i in range(period, n):
        ema[i] = closes[i] * alpha + ema[i - 1] * (1.0 - alpha)

    # ── الشرط: close > EMA — يُعيد dict يحتوي active + ema ─────────────
    for i in range(n):
        if np.isnan(ema[i]):
            result[i] = None          # warmup — لا قيمة بعد
        else:
            result[i] = {
                "active": bool(closes[i] > ema[i]),
                "ema":    round(float(ema[i]), 4),
            }

    return result
