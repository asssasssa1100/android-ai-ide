"""
مؤشر إشارة — Stochastic Crossover
مطابق تماماً لـ TradingView: ta.stoch + ta.crossover

دقة عالية:
  • K = NaN عند rng==0 (مثل TV — لا يُعطي 0 كـ fallback)
  • Crossover: K[i-1] < D[i-1] AND K[i] > D[i]  (strict < على الشمعة السابقة)
  • Fully vectorized بـ NumPy (سريع على 900k+ شمعة)
"""
import numpy as np
import pandas as pd

INDICATOR_NAME    = "Stochastic Crossover"
INDICATOR_VERSION = "1.1.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"k_period": 14, "smooth_k": 1, "d_period": 3}


def _get_ts(r):
    return r.get("timestamp") or r.get("time") or 0


def generate_signals(df, params=None):
    """
    df     : list[dict] — {time/timestamp, open, high, low, close, volume}
    params : dict | None
    return : list[dict] — [{"timestamp": ms, "price": float, "reason": str}, ...]
    """
    p        = params or PARAMETERS
    k_period = int(p.get("k_period", 14))
    smooth_k = int(p.get("smooth_k", 1))
    d_period = int(p.get("d_period", 3))
    n        = len(df)

    if n < k_period + d_period + 2:
        return []

    highs  = np.array([r["high"]  for r in df], dtype=np.float64)
    lows   = np.array([r["low"]   for r in df], dtype=np.float64)
    closes = np.array([r["close"] for r in df], dtype=np.float64)
    ts     = np.array([_get_ts(r) for r in df], dtype=np.int64)

    ll  = pd.Series(lows ).rolling(k_period, min_periods=k_period).min().to_numpy(dtype=np.float64)
    hh  = pd.Series(highs).rolling(k_period, min_periods=k_period).max().to_numpy(dtype=np.float64)
    rng = hh - ll

    # K raw: NaN عندما rng==0 أو قبل warmup (مطابق TV — لا يُعطي 0 كـ fallback)
    with np.errstate(divide="ignore", invalid="ignore"):
        raw_k = np.where(rng > 0, 100.0 * (closes - ll) / rng, 50.0)  # 50 عند rng==0 مطابق TradingView
    raw_k[: k_period - 1] = np.nan

    # ── K smoothing ──────────────────────────────────────────────────────────
    # نستخدم حلقة scalar بدلاً من pandas rolling.mean()
    # السبب: pandas يستخدم Kahan summation → فارق 1-2 بت عن Python's sum()
    # → إشارة زائدة واحدة في كل بضعة آلاف شمعة.
    if smooth_k > 1:
        k = np.full(n, np.nan)
        for i in range(k_period - 1 + smooth_k - 1, n):
            s = 0.0
            for j in range(smooth_k):
                s += raw_k[i - smooth_k + 1 + j]
            k[i] = s / smooth_k
    else:
        k = raw_k.copy()

    # ── D line — scalar sum مطابق لـ Python ──────────────────────────────────
    d = np.full(n, np.nan)
    k_first = k_period - 1 + (smooth_k - 1)
    d_first = k_first + d_period - 1
    for i in range(d_first, n):
        s = 0.0
        all_ok = True
        for j in range(d_period):
            v = k[i - d_period + 1 + j]
            if v != v:   # isnan check بدون استدعاء np.isnan (أسرع في loop)
                all_ok = False
                break
            s += v
        if all_ok:
            d[i] = s / d_period

    # ── Vectorized crossover: Pine Script ta.crossover(K, D) ──────────────────
    prev_k = k[:-1];  curr_k = k[1:]
    prev_d = d[:-1];  curr_d = d[1:]

    valid = ~(np.isnan(prev_k) | np.isnan(prev_d) | np.isnan(curr_k) | np.isnan(curr_d))
    cross = (prev_k <= prev_d) & (curr_k > curr_d) & valid
    idxs  = np.where(cross)[0] + 1

    return [
        {
            "timestamp": int(ts[i]),
            "price":     float(closes[i]),
            "reason":    f"Stoch K({round(float(k[i]),1)})↑D({round(float(d[i]),1)})",
        }
        for i in idxs
    ]
