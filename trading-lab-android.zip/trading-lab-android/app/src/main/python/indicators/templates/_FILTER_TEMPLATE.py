"""
قالب فلتر — انسخه وعدّل المنطق بداخله
══════════════════════════════════════════════════════════════════
■ df     : list[dict]  ← كل dict يمثل شمعة واحدة بالمفاتيح:
               "timestamp" (int ms) | "time" (int ms)
               "open"  (float)
               "high"  (float)
               "low"   (float)
               "close" (float)
               "volume" (float)

■ الإرجاع: list[dict | None]  ← بنفس طول df (عنصر لكل شمعة)
               None  → شمعة في فترة الإحماء (warmup) — لا قرار بعد
               dict  → {"active": bool, ...قيم إضافية اختيارية}
                        active = True  → الفلتر يسمح بالدخول
                        active = False → الفلتر يمنع الدخول

■ تحذيرات مهمة:
   - لا تُرجع list[bool] — هذا الشكل القديم وغير مدعوم
   - شموع فترة الإحماء يجب أن تكون None (ليس False)
   - يمكن إضافة قيم إضافية في dict للعرض في التدقيق
     مثال: {"active": True, "ema": 0.4521, "rsi": 62.3}
   - الفلتر يعمل على نفس إطار الإشارة أو إطار أعلى منه
     المحرك يتكفّل بمزامنة الأطر تلقائياً

■ تحذير SMA / RMA — مهم جداً للمطابقة مع TradingView:
   - لا تستخدم pd.Series.rolling().mean() لحساب SMA
     لأن pandas تستخدم Kahan summation التي تختلف بـ 1-2 bit عن Python الصرف،
     مما يولّد نتائج وهمية عند نقاط التقاطع الحرجة.
   - استخدم دالة _sma_scalar() المرفقة بدلاً منها.
   - EMA و ewm آمنان ولا يعانيان من هذه المشكلة.
══════════════════════════════════════════════════════════════════
"""
import numpy as np

INDICATOR_NAME    = "My Filter"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 20}


# ── دالة SMA آمنة (مطابقة لـ TradingView وPython الصرف) ─────────────────────
def _sma_scalar(src: list, period: int) -> list:
    """
    يحسب SMA بحلقة Python الصرف — يتجنب خطأ Kahan summation في pandas.
    src    : list[float]   — المدخلات
    period : int           — نافذة الحساب
    يعيد   : list[float]  — نفس الطول؛ nan لشموع الإحماء
    """
    n   = len(src)
    out = [float("nan")] * n
    for i in range(period - 1, n):
        s = 0.0
        for j in range(period):
            s += src[i - period + 1 + j]
        out[i] = s / period
    return out


def generate_mask(df, params=None):
    """
    df     : list[dict]  — كل عنصر: {timestamp/time, open, high, low, close, volume}
    params : dict | None — إذا None يُستخدم PARAMETERS

    يُعيد  : list[dict | None]  ← بنفس طول df
              None            → warmup (لا قيمة بعد)
              {"active": bool, ...} → نتيجة الفلتر للشمعة
    """
    p      = params or PARAMETERS
    period = max(2, int(p.get("period", 20)))
    n      = len(df)

    result = [None] * n
    if n < period:
        return result

    # ── استخرج المصفوفات من list[dict] ──────────────────────────────────────
    closes = np.array([float(r["close"]) for r in df], dtype=np.float64)

    # ── احسب المؤشر: EMA مطابق TradingView ─────────────────────────────────
    # البذرة: SMA أول (period) شمعة — آمنة لأنها حساب numpy.mean وليس rolling
    ema    = np.empty(n, dtype=np.float64)
    ema[:] = np.nan
    ema[period - 1] = closes[:period].mean()
    alpha = 2.0 / (period + 1)
    for i in range(period, n):
        ema[i] = closes[i] * alpha + ema[i - 1] * (1.0 - alpha)

    # مثال SMA آمن (استخدم _sma_scalar بدلاً من rolling().mean()):
    # sma = _sma_scalar(closes.tolist(), period)

    # ── أنتج list[dict | None] ──────────────────────────────────────────────
    for i in range(n):
        if np.isnan(ema[i]):
            result[i] = None    # warmup — لا قرار بعد
        else:
            result[i] = {
                "active": bool(closes[i] > ema[i]),   # True = يسمح بالدخول
                "ema":    round(float(ema[i]), 4),     # قيمة إضافية (اختيارية)
            }

    return result
