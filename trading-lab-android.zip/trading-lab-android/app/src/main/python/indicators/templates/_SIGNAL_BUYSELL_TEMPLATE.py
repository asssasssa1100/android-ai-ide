"""
قالب إشارة شراء + بيع — انسخه وعدّل المنطق بداخله
══════════════════════════════════════════════════════════════════
■ هذا القالب للمؤشرات التي تحدد دخول الصفقة وخروجها معاً:
   generate_signals()      → إشارات الشراء  (دخول الصفقة)
   generate_exit_signals() → إشارات البيع   (خروج الصفقة)

■ عند الاختبار اختر نمط "إشارة خروج 🔄" في ورقة الاختبار.
   لا حاجة لـ SL / TP — كل صفقة تُغلق عند أول إشارة بيع بعدها.

■ df : list[dict]  ← كل dict يمثل شمعة واحدة بالمفاتيح:
         "timestamp" (int ms) | "time" (int ms)
         "open"   (float)
         "high"   (float)
         "low"    (float)
         "close"  (float)
         "volume" (float)

■ تحذير SMA / RMA:
   - لا تستخدم pd.Series.rolling().mean() — استخدم _sma_scalar()
   - EMA و ewm آمنان.
══════════════════════════════════════════════════════════════════
"""
import numpy as np
import pandas as pd

INDICATOR_NAME    = "اسم الإشارة"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"fast": 9, "slow": 21}


def _sma_scalar(src: list, period: int) -> list:
    n   = len(src)
    out = [float("nan")] * n
    for i in range(period - 1, n):
        s = 0.0
        for j in range(period):
            s += src[i - period + 1 + j]
        out[i] = s / period
    return out


def generate_signals(df, params=None):
    """
    إشارات الشراء (دخول الصفقة).

    df     : list[dict]  {timestamp/time, open, high, low, close, volume}
    params : dict | None

    يُعيد  : list[dict]
              [{"timestamp": int, "price": float, "reason": str}, ...]
    """
    p    = params or PARAMETERS
    fast = max(2, int(p.get("fast", 9)))
    slow = max(3, int(p.get("slow", 21)))
    n    = len(df)

    if n < slow + 2:
        return []

    closes = np.array([float(r["close"])                              for r in df], dtype=np.float64)
    ts     = np.array([int(r.get("timestamp") or r.get("time") or 0) for r in df], dtype=np.int64)

    # ── EMA آمن ──────────────────────────────────────────────────────────────
    ema_fast = pd.Series(closes).ewm(span=fast, adjust=False).mean().to_numpy()
    ema_slow = pd.Series(closes).ewm(span=slow, adjust=False).mean().to_numpy()

    prev_f = ema_fast[:-1];  curr_f = ema_fast[1:]
    prev_s = ema_slow[:-1];  curr_s = ema_slow[1:]

    # ── إشارة شراء: EMA السريعة تعبر EMA البطيئة من الأسفل إلى الأعلى ──────
    buy_cross = (prev_f <= prev_s) & (curr_f > curr_s)
    buy_idxs  = np.where(buy_cross)[0] + 1

    return [
        {
            "timestamp": int(ts[i]),
            "price":     float(closes[i]),
            "reason":    f"BUY EMA{fast}({round(float(ema_fast[i]),4)}) ↑ EMA{slow}({round(float(ema_slow[i]),4)})",
        }
        for i in buy_idxs
    ]


def generate_exit_signals(df, params=None):
    """
    إشارات البيع (خروج الصفقة).

    df     : list[dict]  {timestamp/time, open, high, low, close, volume}
    params : dict | None

    يُعيد  : list[dict]
              [{"timestamp": int, "price": float, "reason": str}, ...]

    ملاحظة: المحرك يبحث عن أول إشارة بيع بعد كل إشارة شراء ويُغلق الصفقة عندها.
    """
    p    = params or PARAMETERS
    fast = max(2, int(p.get("fast", 9)))
    slow = max(3, int(p.get("slow", 21)))
    n    = len(df)

    if n < slow + 2:
        return []

    closes = np.array([float(r["close"])                              for r in df], dtype=np.float64)
    ts     = np.array([int(r.get("timestamp") or r.get("time") or 0) for r in df], dtype=np.int64)

    ema_fast = pd.Series(closes).ewm(span=fast, adjust=False).mean().to_numpy()
    ema_slow = pd.Series(closes).ewm(span=slow, adjust=False).mean().to_numpy()

    prev_f = ema_fast[:-1];  curr_f = ema_fast[1:]
    prev_s = ema_slow[:-1];  curr_s = ema_slow[1:]

    # ── إشارة بيع: EMA السريعة تعبر EMA البطيئة من الأعلى إلى الأسفل ───────
    sell_cross = (prev_f >= prev_s) & (curr_f < curr_s)
    sell_idxs  = np.where(sell_cross)[0] + 1

    return [
        {
            "timestamp": int(ts[i]),
            "price":     float(closes[i]),
            "reason":    f"SELL EMA{fast}({round(float(ema_fast[i]),4)}) ↓ EMA{slow}({round(float(ema_slow[i]),4)})",
        }
        for i in sell_idxs
    ]
