"""
قالب إشارة — انسخه وعدّل المنطق بداخله
══════════════════════════════════════════════════════════════════
■ df     : list[dict]  ← كل dict يمثل شمعة واحدة بالمفاتيح:
               "timestamp" (int ms) | "time" (int ms)
               "open"  (float)
               "high"  (float)
               "low"   (float)
               "close" (float)
               "volume" (float)

■ الإرجاع: list[dict] — قائمة بالشموع التي تُعدّ إشارات دخول
               كل dict يحتوي:
               "timestamp" : int   ← وقت الشمعة بالميلي ثانية
               "price"     : float ← سعر الإغلاق
               "reason"    : str   ← نص يُعرض في التدقيق

■ تحذيرات مهمة:
   - لا تُرجع أبداً list[int] (أرقام صفوف) — هذا الشكل القديم وغير مدعوم
   - الشمعة رقم 0 لا تُستخدم كإشارة (لا توجد شمعة سابقة للمقارنة)
   - احسب المؤشرات بـ NumPy/pandas ثم حوّل النتائج إلى list[dict]

■ تحذير SMA / RMA — مهم جداً للمطابقة مع TradingView:
   - لا تستخدم pd.Series.rolling().mean() لحساب المتوسطات المتحركة البسيطة (SMA)
     لأن pandas تستخدم Kahan summation التي تختلف بـ 1-2 bit عن Python الصرف،
     مما يولّد إشارات وهمية عند نقاط التقاطع الحرجة.
   - استخدم دالة _sma_scalar() المرفقة بدلاً منها — تعطي نتائج مطابقة تماماً.
   - EMA و ewm آمنان ولا يعانيان من هذه المشكلة.
══════════════════════════════════════════════════════════════════
"""
import numpy as np
import pandas as pd

INDICATOR_NAME    = "My Signal"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"fast": 9, "slow": 21}


# ── دالة SMA آمنة (مطابقة لـ TradingView وPython الصرف) ─────────────────────
def _sma_scalar(src: list, period: int) -> list:
    """
    يحسب SMA بحلقة Python الصرف — يتجنب خطأ Kahan summation في pandas.
    src    : list[float]   — المدخلات
    period : int           — نافذة الحساب
    يعيد   : list[float]  — نفس الطول؛ nan لشموع الإحماء
    """
    n   = len(src)
    out = [float("nan")] * n
    for i in range(period - 1, n):
        s = 0.0
        for j in range(period):
            s += src[i - period + 1 + j]
        out[i] = s / period
    return out


def generate_signals(df, params=None):
    """
    df     : list[dict]  — كل عنصر: {timestamp/time, open, high, low, close, volume}
    params : dict | None — إذا None يُستخدم PARAMETERS

    يُعيد  : list[dict]
              [{"timestamp": int, "price": float, "reason": str}, ...]
              قائمة فارغة [] إذا لم تكن هناك إشارات أو البيانات قصيرة جداً
    """
    p    = params or PARAMETERS
    fast = max(2, int(p.get("fast", 9)))
    slow = max(3, int(p.get("slow", 21)))
    n    = len(df)

    if n < slow + 2:
        return []

    # ── استخرج المصفوفات من list[dict] ──────────────────────────────────────
    closes = np.array([float(r["close"])                              for r in df], dtype=np.float64)
    ts     = np.array([int(r.get("timestamp") or r.get("time") or 0) for r in df], dtype=np.int64)

    # ── احسب المؤشر ─────────────────────────────────────────────────────────
    # مثال: تقاطع EMA صاعد (fast يعبر slow من الأسفل)
    # EMA آمن — يمكن استخدام ewm مباشرة
    ema_fast = pd.Series(closes).ewm(span=fast, adjust=False).mean().to_numpy()
    ema_slow = pd.Series(closes).ewm(span=slow, adjust=False).mean().to_numpy()

    # مثال SMA آمن (استخدم _sma_scalar بدلاً من rolling().mean()):
    # sma_fast = _sma_scalar(closes.tolist(), fast)
    # sma_slow = _sma_scalar(closes.tolist(), slow)

    prev_f = ema_fast[:-1];  curr_f = ema_fast[1:]
    prev_s = ema_slow[:-1];  curr_s = ema_slow[1:]

    cross = (prev_f <= prev_s) & (curr_f > curr_s)
    idxs  = np.where(cross)[0] + 1    # +1 لتعويض الإزاحة

    # ── أعد list[dict] ──────────────────────────────────────────────────────
    return [
        {
            "timestamp": int(ts[i]),
            "price":     float(closes[i]),
            "reason":    f"EMA{fast}({round(float(ema_fast[i]),4)}) ↑ EMA{slow}({round(float(ema_slow[i]),4)})",
        }
        for i in idxs
    ]
