"""main.py — نقطة دخول للتطبيق على Android (Chaquopy)"""
import os
import sys
import shutil


def _get_data_dir():
    d = os.environ.get("TRADING_LAB_DATA")
    if d:
        return d
    return "/data/data/com.tradinglab/files/trading_lab"


def _extract_indicator_name(content: str):
    """استخرج INDICATOR_NAME من محتوى الملف."""
    for line in content.splitlines():
        s = line.strip()
        if s.startswith("INDICATOR_NAME"):
            val = s.split("=", 1)[1].strip()
            if (val.startswith('"') and val.endswith('"')) or \
               (val.startswith("'") and val.endswith("'")):
                val = val[1:-1]
            return val
    return None


def _copy_builtins(py_dir: str, indicators_dir: str):
    """
    Copy bundled builtin indicator files from the APK Python bundle
    to the writable INDICATORS_DIR so they can be loaded at runtime.
    On Chaquopy, bundled .py files may not be accessible directly via
    os.path.exists unless they are in a real writable filesystem path.

    Also syncs any uploaded copies (UUID-named files) that share the same
    INDICATOR_NAME — so the latest builtin code is always executed on verify.
    """
    src = os.path.join(py_dir, "indicators", "builtin")
    dst = os.path.join(indicators_dir, "builtin")
    if not os.path.isdir(src):
        return
    os.makedirs(dst, exist_ok=True)

    # name → latest content mapping (built from bundled sources)
    name_to_content = {}

    for fname in os.listdir(src):
        if not fname.endswith(".py"):
            continue
        s = os.path.join(src, fname)
        d = os.path.join(dst, fname)
        # Always overwrite builtin copy to keep it up-to-date
        shutil.copy2(s, d)
        # Read content and extract name for uploaded-copy sync
        try:
            with open(s, "r", encoding="utf-8") as f:
                content = f.read()
            ind_name = _extract_indicator_name(content)
            if ind_name:
                name_to_content[ind_name] = content
        except Exception:
            pass

    # Sync uploaded copies: if an uploaded .py file shares a name with a
    # builtin, overwrite it so it always runs the latest builtin code.
    if not name_to_content:
        return
    try:
        for fname in os.listdir(indicators_dir):
            if not fname.endswith(".py") or fname.startswith("_"):
                continue
            fpath = os.path.join(indicators_dir, fname)
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    existing = f.read()
                ind_name = _extract_indicator_name(existing)
                if ind_name and ind_name in name_to_content:
                    with open(fpath, "w", encoding="utf-8") as f:
                        f.write(name_to_content[ind_name])
            except Exception:
                pass
    except Exception:
        pass


def start_server(port: int = 5000):
    data_dir = _get_data_dir()

    indicators_dir = os.path.join(data_dir, "indicators")
    os.environ["TRADING_LAB_DATA"] = data_dir
    os.environ["TL_DATA_DIR"]      = os.path.join(data_dir, "data")
    os.environ["TL_IND_DIR"]       = indicators_dir

    for sub in ["data", "indicators"]:
        os.makedirs(os.path.join(data_dir, sub), exist_ok=True)

    py_dir = os.path.dirname(os.path.abspath(__file__))
    if py_dir not in sys.path:
        sys.path.insert(0, py_dir)

    # Copy builtin indicators to writable storage
    _copy_builtins(py_dir, indicators_dir)

    from flask import Flask, send_from_directory, jsonify
    from flask_cors import CORS
    from db import init_db
    from routes.data_routes      import bp as data_bp
    from routes.indicators_routes import bp as ind_bp
    from routes.test_routes      import bp as test_bp
    from routes.analysis_routes  import bp as analysis_bp
    from routes.audit_routes     import bp as audit_bp

    WWW_DIR = os.path.join(py_dir, "www")

    app = Flask(__name__, static_folder=WWW_DIR, static_url_path="")
    app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024
    CORS(app)

    app.register_blueprint(data_bp)
    app.register_blueprint(ind_bp)
    app.register_blueprint(test_bp)
    app.register_blueprint(analysis_bp)
    app.register_blueprint(audit_bp)

    @app.route("/")
    def index():
        return send_from_directory(WWW_DIR, "index.html")

    @app.route("/api/health")
    def health():
        return jsonify({"ok": True, "version": "2.1.0"})

    init_db()
    app.run(host="127.0.0.1", port=port, debug=False,
            use_reloader=False, threaded=True)
