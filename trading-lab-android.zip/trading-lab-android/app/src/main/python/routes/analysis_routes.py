import json
import time
import threading
import uuid
from flask import Blueprint, request, jsonify
from db import get_conn, row_to_dict
from services.backtest_service import compute_stats
from services.analysis_service import (
    filter_trades_from_saved,
    run_top10_from_saved,
    run_multicur_top10,
    get_available_data,
    compute_stats_from_trades,
)

_TF_MS = {
    "1m":  60_000,   "3m":  180_000,  "5m":  300_000,
    "15m": 900_000,  "30m": 1_800_000, "1h":  3_600_000,
    "2h":  7_200_000, "4h":  14_400_000, "6h":  21_600_000,
    "8h":  28_800_000, "12h": 43_200_000,
    "1d":  86_400_000, "3d":  259_200_000, "1w":  604_800_000,
}

bp = Blueprint("analysis", __name__, url_prefix="/api/analysis")

# {id: threading.Event}  — stop events for running jobs
_running = {}
# {id: threading.Event}  — resume events (set = resume, clear = pause)
_paused  = {}
# {id: threading.Event}  — stop events for running trend jobs
_trend_running = {}


# ── List / Detail ──────────────────────────────────────────────────────────────

@bp.route("", methods=["GET"])
@bp.route("/", methods=["GET"])
def list_analyses():
    conn = get_conn()
    anl_rows = conn.execute(
        """SELECT id, test_id, signal_name, symbol, filters_json, status, progress,
                  trades_before, trades_after, wins, losses, wr_before, wr_after,
                  win_rate, created_at, finished_at, 'analysis' as record_type
           FROM analyses ORDER BY created_at DESC"""
    ).fetchall()
    tp10_rows = conn.execute(
        """SELECT id, test_id, signal_name, symbol, status, progress,
                  combos_tested, created_at, 'top10' as record_type
           FROM top10 ORDER BY created_at DESC"""
    ).fetchall()
    conn.close()
    result = [row_to_dict(r) for r in anl_rows]
    for r in tp10_rows:
        d = row_to_dict(r)
        d["is_top10"] = True
        result.append(d)
    result.sort(key=lambda x: x.get("created_at", 0), reverse=True)
    return jsonify(result)


@bp.route("/<anl_id>", methods=["GET"])
def get_analysis(anl_id):
    conn = get_conn()
    row  = conn.execute("SELECT * FROM analyses WHERE id=?", (anl_id,)).fetchone()
    conn.close()
    return jsonify(row_to_dict(row)) if row else (jsonify({"error": "not found"}), 404)


# ── Available data for analysis sheet ─────────────────────────────────────────

@bp.route("/available_data", methods=["GET"])
def available_data():
    symbol = request.args.get("symbol", "").upper()
    if not symbol:
        return jsonify({"error": "symbol required"}), 400
    data = get_available_data(symbol)
    return jsonify(data)


# ── Create analysis (manual) ───────────────────────────────────────────────────

@bp.route("", methods=["POST"])
@bp.route("/", methods=["POST"])
def create_analysis():
    data    = request.json or {}
    test_id = data.get("test_id") or ""
    filters = data.get("filters") or []

    if not test_id:
        return jsonify({"error": "test_id required"}), 400

    conn = get_conn()
    test = conn.execute("SELECT * FROM tests WHERE id=?", (test_id,)).fetchone()
    conn.close()
    if not test:
        return jsonify({"error": "test not found"}), 404

    test_d = row_to_dict(test)
    raw_trades = test_d.get("result_json") or "[]"
    if isinstance(raw_trades, str):
        try:
            trades_all = json.loads(raw_trades)
        except Exception:
            trades_all = []
    else:
        trades_all = list(raw_trades)

    stats_before = compute_stats_from_trades(trades_all)

    anl_id = "ANL-" + str(uuid.uuid4())[:4].upper()
    now    = int(time.time() * 1000)

    symbol = test_d.get("symbol") or ""
    if not symbol:
        sj = test_d.get("symbols_json") or "[]"
        try:
            syms   = json.loads(sj) if isinstance(sj, str) else sj
            symbol = syms[0] if syms else ""
        except Exception:
            symbol = ""
    symbol = symbol.upper().strip()

    conn = get_conn()
    conn.execute(
        """INSERT INTO analyses
           (id, test_id, signal_name, symbol, filters_json, status,
            trades_before, wr_before, created_at)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (anl_id, test_id,
         test_d.get("signal_name", ""),
         symbol,
         json.dumps(filters), "running",
         stats_before["trades"], stats_before["wr"], now)
    )
    conn.commit()
    conn.close()

    signal_tf    = test_d.get("tf", "5m").lower()
    signal_tf_ms = _TF_MS.get(signal_tf, 300_000)

    stop_event = threading.Event()
    _running[anl_id] = stop_event
    t = threading.Thread(
        target=_analysis_worker,
        args=(anl_id, test_d, trades_all, filters, symbol, stop_event, signal_tf_ms),
        daemon=True,
    )
    t.start()
    return jsonify({"id": anl_id})


@bp.route("/<anl_id>/stop", methods=["POST"])
def stop_analysis(anl_id):
    flag = _running.get(anl_id)
    if flag:
        flag.set()
    return jsonify({"ok": True})


@bp.route("/<anl_id>/export", methods=["GET"])
def export_analysis(anl_id):
    from flask import Response
    conn = get_conn()
    row  = conn.execute("SELECT * FROM analyses WHERE id=?", (anl_id,)).fetchone()
    conn.close()
    if not row:
        return jsonify({"error": "not found"}), 404
    d = dict(row)
    try:
        trades  = json.loads(d.get("result_json") or "[]")
    except Exception:
        trades = []
    try:
        filters = json.loads(d.get("filters_json") or "[]")
    except Exception:
        filters = []
    export_data = {
        "analysis_id": d.get("id"),
        "signal_name": d.get("signal_name"),
        "symbol":      d.get("symbol"),
        "tf":          d.get("tf"),
        "rr":          d.get("rr"),
        "wr_before":   d.get("wr_before"),
        "wr_after":    d.get("wr_after"),
        "trades":      d.get("trades_after"),
        "wins":        d.get("wins"),
        "losses":      d.get("losses"),
        "filters":     filters,
        "trades_list": trades,
    }
    filename = f"{anl_id}-analysis.json"
    return Response(
        json.dumps(export_data, ensure_ascii=False, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@bp.route("/<anl_id>", methods=["DELETE"])
def delete_analysis(anl_id):
    conn = get_conn()
    conn.execute("DELETE FROM analyses WHERE id=?", (anl_id,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


# ── Top 10 ─────────────────────────────────────────────────────────────────────

@bp.route("/top10", methods=["GET"])
def list_top10():
    conn = get_conn()
    rows = conn.execute(
        "SELECT id,test_id,signal_name,symbol,status,progress,combos_tested,created_at "
        "FROM top10 ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return jsonify([row_to_dict(r) for r in rows])


@bp.route("/top10/<tp_id>", methods=["GET"])
def get_top10(tp_id):
    conn = get_conn()
    row  = conn.execute("SELECT * FROM top10 WHERE id=?", (tp_id,)).fetchone()
    conn.close()
    return jsonify(row_to_dict(row)) if row else (jsonify({"error": "not found"}), 404)


@bp.route("/top10", methods=["POST"])
def create_top10():
    data             = request.json or {}
    test_id          = data.get("test_id") or ""
    indicator_ids    = data.get("indicator_ids") or []
    allowed_tfs      = data.get("tfs") or []
    min_trades       = int(data.get("min_trades") or 5)
    min_coverage_pct = float(data.get("min_coverage_pct") or 20.0)

    if not test_id:
        return jsonify({"error": "test_id required"}), 400

    conn = get_conn()
    test = row_to_dict(conn.execute("SELECT * FROM tests WHERE id=?", (test_id,)).fetchone())
    conn.close()
    if not test:
        return jsonify({"error": "test not found"}), 404

    if not indicator_ids:
        conn = get_conn()
        rows = conn.execute("SELECT id FROM indicators WHERE type='filter'").fetchall()
        conn.close()
        indicator_ids = [r["id"] for r in rows]

    symbol = test.get("symbol") or ""
    if not symbol:
        sj = test.get("symbols_json") or "[]"
        try:
            syms   = json.loads(sj) if isinstance(sj, str) else sj
            symbol = syms[0] if syms else ""
        except Exception:
            symbol = ""
    symbol = symbol.upper().strip()

    tp_id = "TP10-" + str(uuid.uuid4())[:4].upper()
    now   = int(time.time() * 1000)

    conn = get_conn()
    conn.execute(
        """INSERT INTO top10
           (id, test_id, signal_name, symbol, status, created_at,
            min_trades, min_coverage_pct, allowed_tfs_json)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (tp_id, test_id, test.get("signal_name", ""), symbol,
         "running", now, min_trades, min_coverage_pct, json.dumps(allowed_tfs))
    )
    conn.commit()
    conn.close()

    signal_tf_ms = _TF_MS.get(test.get("tf", "5m").lower(), 300_000)

    stop_event   = threading.Event()
    resume_event = threading.Event()
    resume_event.set()   # يبدأ غير موقوف
    _running[tp_id] = stop_event
    _paused[tp_id]  = resume_event

    t = threading.Thread(
        target=_top10_worker,
        args=(tp_id, test, symbol, indicator_ids, allowed_tfs,
              min_trades, min_coverage_pct, stop_event, resume_event, signal_tf_ms),
        daemon=True,
    )
    t.start()
    return jsonify({"id": tp_id})


@bp.route("/top10/<tp_id>/pause", methods=["POST"])
def pause_top10(tp_id):
    """إيقاف مؤقت — يحفظ نقطة التقدم ويعلّق الخيط."""
    ev = _paused.get(tp_id)
    if ev:
        ev.clear()          # يجعل resume_event غير مضبوط → الخيط يتوقف
        conn = get_conn()
        conn.execute("UPDATE top10 SET status='paused' WHERE id=? AND status='running'",
                     (tp_id,))
        conn.commit()
        conn.close()
    return jsonify({"ok": True})


@bp.route("/top10/<tp_id>/resume", methods=["POST"])
def resume_top10(tp_id):
    """
    استئناف — إذا كان الخيط لا يزال حياً: يرفع الإشارة فقط.
    إذا انتهى الخيط (حُفظ checkpoint): يُنشئ خيطاً جديداً.
    """
    conn = get_conn()
    row  = row_to_dict(conn.execute("SELECT * FROM top10 WHERE id=?", (tp_id,)).fetchone())
    conn.close()
    if not row:
        return jsonify({"error": "not found"}), 404

    # حاول رفع الإشارة للخيط الحالي أولاً
    ev = _paused.get(tp_id)
    if ev:
        ev.set()
        conn = get_conn()
        conn.execute("UPDATE top10 SET status='running' WHERE id=?", (tp_id,))
        conn.commit()
        conn.close()
        return jsonify({"ok": True, "resumed": "live"})

    # الخيط انتهى — استخدم checkpoint المحفوظ لإنشاء خيط جديد
    try:
        ckpt_raw = row.get("checkpoint_json") or "{}"
        if isinstance(ckpt_raw, str):
            checkpoint = json.loads(ckpt_raw)
        else:
            checkpoint = ckpt_raw if isinstance(ckpt_raw, dict) else {}
    except Exception:
        checkpoint = {}

    if not checkpoint:
        return jsonify({"error": "no checkpoint to resume from"}), 400

    # استعد البيانات اللازمة
    test_id = row.get("test_id") or ""
    conn    = get_conn()
    test    = row_to_dict(conn.execute("SELECT * FROM tests WHERE id=?", (test_id,)).fetchone())
    conn.close()
    if not test:
        return jsonify({"error": "test not found"}), 404

    indicator_ids = checkpoint.get("indicator_ids") or []
    if not indicator_ids:
        conn = get_conn()
        inds = conn.execute("SELECT id FROM indicators WHERE type='filter'").fetchall()
        conn.close()
        indicator_ids = [r["id"] for r in inds]

    allowed_tfs      = row.get("allowed_tfs_json") or []
    min_trades       = int(row.get("min_trades") or 5)
    min_coverage_pct = float(row.get("min_coverage_pct") or 20.0)
    symbol           = row.get("symbol") or ""
    signal_tf_ms     = _TF_MS.get(test.get("tf", "5m").lower(), 300_000)

    conn = get_conn()
    conn.execute("UPDATE top10 SET status='running' WHERE id=?", (tp_id,))
    conn.commit()
    conn.close()

    stop_event   = threading.Event()
    resume_event = threading.Event()
    resume_event.set()
    _running[tp_id] = stop_event
    _paused[tp_id]  = resume_event

    t = threading.Thread(
        target=_top10_worker,
        args=(tp_id, test, symbol, indicator_ids, allowed_tfs,
              min_trades, min_coverage_pct, stop_event, resume_event, signal_tf_ms,
              checkpoint),
        daemon=True,
    )
    t.start()
    return jsonify({"ok": True, "resumed": "new_thread"})


@bp.route("/top10/<tp_id>", methods=["DELETE"])
def delete_top10(tp_id):
    stop = _running.get(tp_id)
    if stop:
        stop.set()
    conn = get_conn()
    conn.execute("DELETE FROM top10 WHERE id=?", (tp_id,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


# ── Workers ────────────────────────────────────────────────────────────────────

def _analysis_worker(anl_id, test_d, trades_all, filters, symbol,
                     stop_event, signal_tf_ms: int = 300_000):
    try:
        filtered = filter_trades_from_saved(trades_all, filters, symbol,
                                            signal_tf_ms=signal_tf_ms)
        stats    = compute_stats_from_trades(filtered)

        conn = get_conn()
        conn.execute(
            """UPDATE analyses SET status='done', progress=1,
               trades_after=?, wins=?, losses=?, wr_after=?, win_rate=?,
               result_json=?, finished_at=? WHERE id=?""",
            (stats["trades"], stats["wins"], stats["losses"],
             stats["wr"], stats["wr"],
             json.dumps(filtered), int(time.time() * 1000), anl_id)
        )
        conn.commit()
        conn.close()
    except Exception:
        conn = get_conn()
        conn.execute("UPDATE analyses SET status='error' WHERE id=?", (anl_id,))
        conn.commit()
        conn.close()
    finally:
        _running.pop(anl_id, None)


def _top10_worker(tp_id, test_d, symbol, indicator_ids, allowed_tfs,
                  min_trades, min_coverage_pct,
                  stop_event, resume_event,
                  signal_tf_ms: int = 300_000,
                  checkpoint: dict = None):
    """
    Hybrid Top-10 worker.
    - stop_event  → إيقاف نهائي (حذف)
    - resume_event → إيقاف مؤقت (pause/resume): الخيط ينتظر حتى يُرفع
    """
    last_checkpoint = checkpoint or {}
    last_progress   = 0.0

    def prog_cb(pct):
        nonlocal last_progress
        # انتظر إذا كان موقوفاً مؤقتاً
        resume_event.wait()

        if stop_event.is_set():
            return   # سيُكتشف في الحلقة الرئيسية

        # حدّث DB كل نصف بالمئة على الأقل
        if pct - last_progress >= 0.005 or pct >= 0.99:
            last_progress = pct
            conn = get_conn()
            conn.execute("UPDATE top10 SET progress=? WHERE id=?", (pct, tp_id))
            conn.commit()
            conn.close()

    try:
        raw_t = test_d.get("result_json") or "[]"
        if isinstance(raw_t, str):
            try:
                trades = json.loads(raw_t)
            except Exception:
                trades = []
        else:
            trades = list(raw_t)

        output = run_top10_from_saved(
            trades, symbol, indicator_ids, allowed_tfs,
            min_trades=min_trades,
            min_coverage_pct=min_coverage_pct,
            progress_cb=prog_cb,
            signal_tf_ms=signal_tf_ms,
            stop_event=stop_event,
            checkpoint=last_checkpoint if last_checkpoint else None,
        )

        results     = output["results"]
        combos_done = output["combos_done"]
        stopped     = output["stopped"]
        ckpt        = output.get("checkpoint") or {}

        conn = get_conn()
        if stopped:
            # حفظ نقطة التقدم وتحديث الحالة
            ckpt["indicator_ids"] = indicator_ids   # للاستئناف لاحقاً
            conn.execute(
                """UPDATE top10 SET status='paused', progress=?,
                   combos_tested=?, result_json=?, checkpoint_json=?
                   WHERE id=?""",
                (last_progress,
                 combos_done,
                 json.dumps(results),
                 json.dumps(ckpt),
                 tp_id)
            )
        else:
            conn.execute(
                """UPDATE top10 SET status='done', progress=1,
                   combos_tested=?, result_json=?, finished_at=?,
                   checkpoint_json='{}' WHERE id=?""",
                (combos_done, json.dumps(results),
                 int(time.time() * 1000), tp_id)
            )
        conn.commit()
        conn.close()

    except Exception as e:
        conn = get_conn()
        conn.execute("UPDATE top10 SET status='error' WHERE id=?", (tp_id,))
        conn.commit()
        conn.close()
    finally:
        _running.pop(tp_id, None)
        _paused.pop(tp_id, None)


# ── Multi-Currency Top-10 ──────────────────────────────────────────────────────

# جدول DB: multicur_top10
# (id, signal_name, symbols_json, allowed_tfs_json, min_trades,
#  min_wr_strict, min_currencies_pct, status, progress,
#  combos_done, result_json, missing_data_json, created_at, finished_at)

_multicur_running = {}   # {id: threading.Event}


@bp.route("/multicur_top10", methods=["GET"])
def list_multicur_top10():
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, signal_name, symbols_json, allowed_tfs_json, min_trades, "
        "min_wr_strict, min_currencies_pct, status, progress, combos_done, "
        "result_json, missing_data_json, error_msg, created_at, finished_at "
        "FROM multicur_top10 ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return jsonify([row_to_dict(r) for r in rows])


@bp.route("/multicur_top10/<mc_id>", methods=["GET"])
def get_multicur_top10(mc_id):
    conn = get_conn()
    row  = conn.execute("SELECT * FROM multicur_top10 WHERE id=?", (mc_id,)).fetchone()
    conn.close()
    return jsonify(row_to_dict(row)) if row else (jsonify({"error": "not found"}), 404)


@bp.route("/multicur_top10", methods=["POST"])
def create_multicur_top10():
    data               = request.json or {}
    signal_name        = (data.get("signal_name") or "").strip()
    symbols            = data.get("symbols") or []
    indicator_ids      = data.get("indicator_ids") or []
    allowed_tfs        = data.get("tfs") or []
    min_trades         = int(data.get("min_trades") or 5)
    min_wr_strict      = float(data.get("min_wr_strict") or 50.0)
    min_currencies_pct = float(data.get("min_currencies_pct") or 80.0)

    if not signal_name:
        return jsonify({"error": "signal_name required"}), 400
    if not symbols or len(symbols) < 2:
        return jsonify({"error": "يجب اختيار عملتين على الأقل"}), 400

    # إذا لم تُحدَّد indicator_ids → خذ كل الفلاتر
    if not indicator_ids:
        conn = get_conn()
        rows = conn.execute("SELECT id FROM indicators WHERE type='filter'").fetchall()
        conn.close()
        indicator_ids = [r["id"] for r in rows]

    if not indicator_ids:
        return jsonify({"error": "لا توجد فلاتر — ارفع مؤشراً أولاً"}), 400

    # تأكد وجود جدول multicur_top10
    _ensure_multicur_table()

    mc_id = "MCT-" + str(uuid.uuid4())[:4].upper()
    now   = int(time.time() * 1000)

    conn = get_conn()
    conn.execute(
        """INSERT INTO multicur_top10
           (id, signal_name, symbols_json, allowed_tfs_json, min_trades,
            min_wr_strict, min_currencies_pct, status, progress, combos_done,
            result_json, missing_data_json, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (mc_id, signal_name,
         json.dumps(symbols), json.dumps(allowed_tfs),
         min_trades, min_wr_strict, min_currencies_pct,
         "running", 0.0, 0,
         json.dumps([]), json.dumps([]), now)
    )
    conn.commit()
    conn.close()

    stop_event = threading.Event()
    _multicur_running[mc_id] = stop_event

    threading.Thread(
        target=_multicur_worker,
        args=(mc_id, signal_name, symbols, indicator_ids, allowed_tfs,
              min_trades, min_wr_strict, min_currencies_pct, stop_event),
        daemon=True,
    ).start()

    return jsonify({"id": mc_id})


@bp.route("/multicur_top10/<mc_id>/stop", methods=["POST"])
def stop_multicur_top10(mc_id):
    ev = _multicur_running.get(mc_id)
    if ev:
        ev.set()
    conn = get_conn()
    conn.execute(
        "UPDATE multicur_top10 SET status='stopped' WHERE id=? AND status='running'",
        (mc_id,)
    )
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


@bp.route("/multicur_top10/<mc_id>", methods=["DELETE"])
def delete_multicur_top10(mc_id):
    ev = _multicur_running.get(mc_id)
    if ev:
        ev.set()
    conn = get_conn()
    conn.execute("DELETE FROM multicur_top10 WHERE id=?", (mc_id,))
    conn.commit()
    conn.close()
    _multicur_running.pop(mc_id, None)
    return jsonify({"ok": True})


@bp.route("/multicur_top10/available_signals", methods=["GET"])
def multicur_available_signals():
    """يُعيد قائمة الإشارات التي لديها اختبارات منتهية مع عملاتها."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT signal_name, symbols_json, symbol, tf FROM tests WHERE status='done'"
    ).fetchall()
    conn.close()

    by_signal: dict = {}
    for row in rows:
        d = row_to_dict(row)
        sn = d.get("signal_name") or ""
        if not sn:
            continue
        raw = d.get("symbols_json") or "[]"
        try:
            syms = json.loads(raw) if isinstance(raw, str) else list(raw)
        except Exception:
            syms = []
        if not syms and d.get("symbol"):
            syms = [d["symbol"]]
        if sn not in by_signal:
            by_signal[sn] = {"signal_name": sn, "symbols": set(), "tfs": set()}
        for s in syms:
            by_signal[sn]["symbols"].add(s.upper())
        if d.get("tf"):
            by_signal[sn]["tfs"].add(d["tf"])

    result = [
        {"signal_name": v["signal_name"],
         "symbols":     sorted(v["symbols"]),
         "tfs":         sorted(v["tfs"])}
        for v in by_signal.values()
        if len(v["symbols"]) >= 2
    ]
    return jsonify(result)


def _ensure_multicur_table():
    """ينشئ جدول multicur_top10 إذا لم يكن موجوداً، ويضيف الأعمدة المفقودة."""
    conn = get_conn()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS multicur_top10 (
            id                TEXT PRIMARY KEY,
            signal_name       TEXT,
            symbols_json      TEXT DEFAULT '[]',
            allowed_tfs_json  TEXT DEFAULT '[]',
            min_trades        INTEGER DEFAULT 5,
            min_wr_strict     REAL    DEFAULT 35.0,
            min_currencies_pct REAL   DEFAULT 70.0,
            status            TEXT    DEFAULT 'running',
            progress          REAL    DEFAULT 0.0,
            combos_done       INTEGER DEFAULT 0,
            result_json       TEXT    DEFAULT '[]',
            missing_data_json TEXT    DEFAULT '[]',
            error_msg         TEXT    DEFAULT '',
            created_at        INTEGER,
            finished_at       INTEGER
        )
    """)
    # أضف عمود error_msg إن لم يكن موجوداً (للجداول القديمة)
    try:
        conn.execute("ALTER TABLE multicur_top10 ADD COLUMN error_msg TEXT DEFAULT ''")
        conn.commit()
    except Exception:
        pass
    conn.commit()
    conn.close()


def _multicur_worker(mc_id, signal_name, symbols, indicator_ids, allowed_tfs,
                     min_trades, min_wr_strict, min_currencies_pct, stop_event):
    last_progress = 0.0

    def prog_cb(pct):
        nonlocal last_progress
        if stop_event.is_set():
            return
        if pct - last_progress >= 0.005 or pct >= 0.99:
            last_progress = pct
            conn = get_conn()
            conn.execute("UPDATE multicur_top10 SET progress=? WHERE id=?", (pct, mc_id))
            conn.commit()
            conn.close()

    try:
        output = run_multicur_top10(
            signal_name        = signal_name,
            symbols            = symbols,
            indicator_ids      = indicator_ids,
            allowed_tfs        = allowed_tfs,
            min_trades         = min_trades,
            min_wr_strict      = min_wr_strict,
            min_currencies_pct = min_currencies_pct,
            progress_cb        = prog_cb,
            stop_event         = stop_event,
        )

        results      = output["results"]
        combos_done  = output["combos_done"]
        missing_data = output["missing_data"]
        stopped      = output["stopped"]

        conn = get_conn()
        if stopped:
            conn.execute(
                """UPDATE multicur_top10 SET status='stopped', progress=?,
                   combos_done=?, result_json=?, missing_data_json=?
                   WHERE id=?""",
                (last_progress, combos_done,
                 json.dumps(results), json.dumps(missing_data), mc_id)
            )
        else:
            conn.execute(
                """UPDATE multicur_top10 SET status='done', progress=1,
                   combos_done=?, result_json=?, missing_data_json=?,
                   finished_at=? WHERE id=?""",
                (combos_done, json.dumps(results), json.dumps(missing_data),
                 int(time.time() * 1000), mc_id)
            )
        conn.commit()
        conn.close()

    except Exception as exc:
        import traceback
        err_msg = str(exc) or traceback.format_exc().strip().splitlines()[-1]
        conn = get_conn()
        conn.execute(
            "UPDATE multicur_top10 SET status='error', error_msg=? WHERE id=?",
            (err_msg[:400], mc_id)
        )
        conn.commit()
        conn.close()
    finally:
        _multicur_running.pop(mc_id, None)


# ── Trend Analysis ─────────────────────────────────────────────────────────────

@bp.route("/trend", methods=["GET"])
def list_trends():
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, symbol, allowed_tfs, min_candles, min_bullish_pct, "
        "max_combo_size, sort_by, result_count, elapsed_ms, created_at, "
        "status, progress "
        "FROM trend_results ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return jsonify([row_to_dict(r) for r in rows])


@bp.route("/trend/<tr_id>", methods=["GET"])
def get_trend(tr_id):
    conn = get_conn()
    row  = conn.execute("SELECT * FROM trend_results WHERE id=?", (tr_id,)).fetchone()
    conn.close()
    return jsonify(row_to_dict(row)) if row else (jsonify({"error": "not found"}), 404)


@bp.route("/trend/<tr_id>", methods=["DELETE"])
def delete_trend(tr_id):
    stop = _trend_running.get(tr_id)
    if stop:
        stop.set()
    conn = get_conn()
    conn.execute("DELETE FROM trend_results WHERE id=?", (tr_id,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


@bp.route("/trend/<tr_id>/stop", methods=["POST"])
def stop_trend(tr_id):
    """إيقاف حساب الاتجاه الجاري."""
    stop = _trend_running.get(tr_id)
    if stop:
        stop.set()
    conn = get_conn()
    conn.execute(
        "UPDATE trend_results SET status='stopped' WHERE id=? AND status='running'",
        (tr_id,),
    )
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


@bp.route("/trend", methods=["POST"])
def create_trend():
    data            = request.json or {}
    symbol          = (data.get("symbol") or "").upper().strip()
    allowed_tfs     = data.get("allowed_tfs") or []
    min_candles     = int(data.get("min_candles") or 500)
    min_bullish_pct = float(data.get("min_bullish_pct") or 50.0)
    max_combo_size  = int(data.get("max_combo_size") or 3)
    sort_by         = data.get("sort_by") or "bullish_pct"

    if not symbol:
        return jsonify({"error": "symbol required"}), 400

    tr_id = "TRD-" + str(uuid.uuid4())[:4].upper()
    now   = int(time.time() * 1000)

    # أدرج سجل "جارٍ" فوراً ثم ابدأ خيط الخلفية
    conn = get_conn()
    conn.execute(
        """INSERT INTO trend_results
           (id, symbol, allowed_tfs, min_candles, min_bullish_pct,
            max_combo_size, sort_by, result_json, result_count,
            elapsed_ms, created_at, status, progress)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (tr_id, symbol,
         json.dumps(allowed_tfs), min_candles, min_bullish_pct,
         max_combo_size, sort_by,
         json.dumps([]), 0, 0, now, "running", 0.0)
    )
    conn.commit()
    conn.close()

    stop_event = threading.Event()
    _trend_running[tr_id] = stop_event

    threading.Thread(
        target=_trend_worker,
        args=(tr_id, symbol, allowed_tfs, min_candles,
              min_bullish_pct, max_combo_size, sort_by, stop_event),
        daemon=True,
    ).start()

    return jsonify({"id": tr_id, "status": "running"})


def _trend_worker(tr_id, symbol, allowed_tfs, min_candles,
                  min_bullish_pct, max_combo_size, sort_by, stop_event):
    """يحسب الاتجاهات في الخلفية ويحدّث قاعدة البيانات عند الانتهاء."""
    import time as _time
    from services.trend_service import compute_trend

    t0 = _time.time()
    try:
        results = compute_trend(
            symbol          = symbol,
            allowed_tfs     = allowed_tfs if allowed_tfs else None,
            min_candles     = min_candles,
            min_bullish_pct = min_bullish_pct,
            max_combo_size  = max_combo_size,
            sort_by         = sort_by,
            top_n           = 10,
        )
        elapsed_ms = round((_time.time() - t0) * 1000)

        if stop_event.is_set():
            conn = get_conn()
            conn.execute(
                "UPDATE trend_results SET status='stopped' WHERE id=?", (tr_id,)
            )
            conn.commit()
            conn.close()
            return

        conn = get_conn()
        conn.execute(
            """UPDATE trend_results
               SET status='done', progress=1, result_json=?,
                   result_count=?, elapsed_ms=?
               WHERE id=?""",
            (json.dumps(results), len(results), elapsed_ms, tr_id),
        )
        conn.commit()
        conn.close()

    except Exception as e:
        conn = get_conn()
        conn.execute(
            "UPDATE trend_results SET status='error', progress=0 WHERE id=?",
            (tr_id,),
        )
        conn.commit()
        conn.close()
    finally:
        _trend_running.pop(tr_id, None)
