import json
import time
import threading
import uuid
from flask import Blueprint, request, jsonify
from db import get_conn, row_to_dict
from services.backtest_service import run_backtest, compute_stats
from services.analysis_service import filter_trades_from_saved, compute_stats_from_trades

bp = Blueprint("audit", __name__, url_prefix="/api/audit")


# ── Readiness check ───────────────────────────────────────────────────────────

@bp.route("/readiness", methods=["POST"])
def check_readiness():
    """
    يتحقق من جاهزية جميع العملات لتشغيل التدقيق.

    Body JSON:
        filters    : [{indicator_id, tf}]  — الفلاتر المطلوبة
        currencies : [str]                 — رموز العملات

    Response:
        {
          "ready": bool,
          "currencies": [
            {
              "symbol"          : str,
              "ready"           : bool,
              "missing_tfs"     : [str],   // أطر ناقصة في currency_tfs
              "missing_filters" : [{indicator_id, tf}]  // filter_results ناقصة
            }
          ]
        }
    """
    data       = request.json or {}
    filters    = data.get("filters") or []
    currencies = [s.upper().strip() for s in (data.get("currencies") or []) if s]

    if not currencies:
        return jsonify({"error": "currencies required"}), 400

    # الأطر الزمنية المطلوبة (من الفلاتر)
    needed_tfs = list({f.get("tf", "5m") for f in filters if isinstance(f, dict)})

    conn    = get_conn()
    results = []
    all_ok  = True

    for sym in currencies:
        # ── 1. تحقق من بيانات الأطر الزمنية ─────────────────────────────
        missing_tfs = []
        for tf in needed_tfs:
            row = conn.execute(
                "SELECT candles FROM currency_tfs WHERE symbol=? AND tf=?",
                (sym, tf)
            ).fetchone()
            if not row or (row["candles"] or 0) < 10:
                missing_tfs.append(tf)

        # ── 2. تحقق من filter_results لكل (indicator_id, tf) ─────────────
        missing_filters = []
        for f in filters:
            if not isinstance(f, dict):
                continue
            ind_id = f.get("indicator_id", "")
            tf     = f.get("tf", "5m")
            if not ind_id:
                continue
            row = conn.execute(
                "SELECT candle_count FROM filter_results "
                "WHERE indicator_id=? AND symbol=? AND tf=?",
                (ind_id, sym, tf)
            ).fetchone()
            if not row:
                missing_filters.append({"indicator_id": ind_id, "tf": tf})

        cur_ready = not missing_tfs and not missing_filters
        if not cur_ready:
            all_ok = False

        results.append({
            "symbol":          sym,
            "ready":           cur_ready,
            "missing_tfs":     missing_tfs,
            "missing_filters": missing_filters,
        })

    conn.close()
    return jsonify({"ready": all_ok, "currencies": results})

_running = {}


@bp.route("", methods=["GET"])
@bp.route("/", methods=["GET"])
def list_audits():
    conn = get_conn()
    rows = conn.execute(
        "SELECT id,signal_id,filters_json,currencies_json,status,progress,"
        "total_trades,total_wr,created_at FROM audits ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return jsonify([row_to_dict(r) for r in rows])


@bp.route("/<audit_id>", methods=["GET"])
def get_audit(audit_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM audits WHERE id=?", (audit_id,)).fetchone()
    conn.close()
    return jsonify(row_to_dict(row)) if row else (jsonify({"error": "not found"}), 404)


@bp.route("", methods=["POST"])
@bp.route("/", methods=["POST"])
def create_audit():
    data        = request.json or {}
    signal_name = (data.get("signal_name") or data.get("signal_id") or "").strip()
    sig_params  = data.get("signal_params") or {}
    filters_raw = data.get("filters") or []
    rr          = float(data.get("rr") or 2.0)
    currencies  = [s.upper() for s in (data.get("currencies") or data.get("symbols") or [])]

    if not signal_name or not currencies:
        return jsonify({"error": "signal_name and currencies required"}), 400

    # Resolve signal_name → signal_id
    conn2 = get_conn()
    row2  = conn2.execute(
        "SELECT id FROM indicators WHERE name=? AND type='signal'", (signal_name,)
    ).fetchone()
    conn2.close()
    _BUILTIN_IDS = {"stoch": "stoch", "Stochastic Crossover": "stoch",
                    "breakout": "breakout", "Pivot High Breakout": "breakout"}
    signal_id = (row2["id"] if row2 else _BUILTIN_IDS.get(signal_name, signal_name))

    # Normalise filters: support both {indicator_id, tf} and {indicator_name, tf}
    conn3 = get_conn()
    filters = []
    for f in filters_raw:
        if isinstance(f, str):
            # legacy: plain filter name string
            r = conn3.execute("SELECT id FROM indicators WHERE name=? AND type='filter'", (f,)).fetchone()
            if r: filters.append({"indicator_id": r["id"], "tf": "5m"})
        elif isinstance(f, dict):
            if f.get("indicator_id"):
                filters.append({"indicator_id": f["indicator_id"], "tf": f.get("tf","5m")})
            elif f.get("indicator_name"):
                nm = f["indicator_name"]
                r  = conn3.execute("SELECT id FROM indicators WHERE name=? AND type='filter'", (nm,)).fetchone()
                if r: filters.append({"indicator_id": r["id"], "tf": f.get("tf","5m")})
    conn3.close()

    signal_id = signal_id  # noqa — resolved above

    audit_id = "TDQ-" + str(uuid.uuid4())[:4].upper()
    now      = int(time.time() * 1000)

    conn = get_conn()
    conn.execute(
        """INSERT INTO audits
           (id, signal_id, signal_params, filters_json, rr, currencies_json, status, created_at)
           VALUES (?,?,?,?,?,?,?,?)""",
        (audit_id, signal_id, json.dumps(sig_params), json.dumps(filters),
         rr, json.dumps(currencies), "running", now)
    )
    conn.commit()
    conn.close()

    stop_event = threading.Event()
    _running[audit_id] = stop_event
    t = threading.Thread(
        target=_audit_worker,
        args=(audit_id, signal_id, sig_params, filters, rr, currencies, stop_event),
        daemon=True
    )
    t.start()
    return jsonify({"id": audit_id})


@bp.route("/<audit_id>/stop", methods=["POST"])
def stop_audit(audit_id):
    flag = _running.get(audit_id)
    if flag:
        flag.set()
    return jsonify({"ok": True})


@bp.route("/<audit_id>", methods=["DELETE"])
def delete_audit(audit_id):
    conn = get_conn()
    conn.execute("DELETE FROM audits WHERE id=?", (audit_id,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


def _audit_worker(audit_id, signal_id, sig_params, filters, rr, currencies, stop_event):
    """
    لكل عملة:
      1. شغّل الـ backtest للحصول على الصفقات
      2. طبّق الفلاتر من filter_results المحفوظة (filter_trades_from_saved)
         إذا لم تتوفر filter_results للعملة → احسبها أولاً
      3. احسب الإحصاءات
    """
    results = []
    total   = len(currencies)
    all_wr  = []

    for i, symbol in enumerate(currencies):
        if stop_event.is_set():
            break
        try:
            # الخطوة 1: توليد الصفقات
            trades = run_backtest(symbol, signal_id, sig_params, rr)

            # الخطوة 2: تطبيق الفلاتر من filter_results
            if filters:
                # تحقق إذا filter_results موجودة لأي فلتر على هذه العملة
                from db import get_conn as _gc
                conn2 = _gc()
                missing_filters = []
                for f in filters:
                    ind_id = f.get("indicator_id") or f.get("id") or ""
                    tf_f   = f.get("tf", "5m")
                    row = conn2.execute(
                        "SELECT candle_count FROM filter_results "
                        "WHERE indicator_id=? AND symbol=? AND tf=?",
                        (ind_id, symbol.upper(), tf_f)
                    ).fetchone()
                    if row is None:
                        missing_filters.append(tf_f)
                conn2.close()

                # إذا توجد فلاتر غير محسوبة → احسبها الآن
                if missing_filters:
                    from services.filter_service import compute_filters as _cf
                    for tf_missing in set(missing_filters):
                        try:
                            _cf(symbol, tf_missing)
                        except Exception:
                            pass

                # الآن طبّق الفلاتر من DB
                trades = filter_trades_from_saved(trades, filters, symbol)

            stats = compute_stats_from_trades(trades)
            all_wr.append(stats["wr"])
            results.append({
                "symbol":  symbol,
                "trades":  stats["trades"],
                "wins":    stats["wins"],
                "losses":  stats["losses"],
                "wr":      stats["wr"],
            })
        except Exception as e:
            results.append({"symbol": symbol, "error": str(e)})

        pct = (i + 1) / total
        conn = get_conn()
        conn.execute("UPDATE audits SET progress=? WHERE id=?", (pct, audit_id))
        conn.commit()
        conn.close()

    avg_wr = round(sum(all_wr) / len(all_wr), 2) if all_wr else 0
    status = "paused" if stop_event.is_set() else "done"

    conn = get_conn()
    conn.execute(
        """UPDATE audits SET status=?, progress=1, total_trades=?,
           total_wr=?, result_json=?, finished_at=? WHERE id=?""",
        (status, sum(r.get("trades", 0) for r in results),
         avg_wr, json.dumps(results), int(time.time() * 1000), audit_id)
    )
    conn.commit()
    conn.close()
    _running.pop(audit_id, None)
