import os
import time
import threading
import pandas as pd
from flask import Blueprint, request, jsonify, send_file
from db import get_conn, row_to_dict
from config import DATA_DIR, FETCH_START_MS
from storage import (
    get_or_create_currency, find_currency,
    csv_path, tf_dir, signal_dir, ensure_dirs,
    TF_NORM, TF_ALL,
)
from services.binance_service import (
    fetch_klines_batch,
    klines_to_df,
    validate_symbol,
)

bp = Blueprint("data", __name__, url_prefix="/api/data")

TF_ALL_LOWER = ["5m", "15m", "1h", "4h", "1d"]
TF_NON5M     = ["15m", "1h", "4h", "1d"]

_fetch_stop_flags = {}
_tf_locks         = {}
_tf_locks_lock    = threading.Lock()

# ── تتبع jobs حساب الفلاتر (background threads) ──────────
# key: "BTCUSDT-5m"  →  { status, done, total, pct, errors, ... }
_filter_jobs:  dict = {}
_filter_locks: dict = {}
_filter_locks_lock = threading.Lock()


def _filter_lock(symbol: str, tf: str) -> threading.Lock:
    key = f"{symbol}-{tf}"
    with _filter_locks_lock:
        if key not in _filter_locks:
            _filter_locks[key] = threading.Lock()
        return _filter_locks[key]


def _tf_lock(symbol: str) -> threading.Lock:
    with _tf_locks_lock:
        lock = _tf_locks.get(symbol)
        if lock is None:
            lock = threading.Lock()
            _tf_locks[symbol] = lock
        return lock


def _get_cur_info(symbol: str) -> dict:
    """جلب { symbol, currency_id } من DB أو من المجلدات."""
    symbol = symbol.upper()
    conn = get_conn()
    row = conn.execute(
        "SELECT currency_id FROM currencies WHERE symbol=?", (symbol,)
    ).fetchone()
    conn.close()
    if row and row["currency_id"]:
        return {"symbol": symbol, "currency_id": row["currency_id"]}
    return get_or_create_currency(symbol)


def _get_csv_path(symbol: str, cur_id: str, tf: str) -> str:
    return csv_path(symbol, cur_id, tf)


def _read_5m(symbol: str) -> pd.DataFrame:
    info = _get_cur_info(symbol)
    p = csv_path(symbol, info["currency_id"], "5m")
    if not os.path.exists(p):
        return pd.DataFrame()
    return pd.read_csv(p, dtype={"timestamp": "int64"})


def _save_tf_meta(conn, symbol: str, tf: str, df: pd.DataFrame):
    if df.empty:
        conn.execute(
            "DELETE FROM currency_tfs WHERE symbol=? AND tf=?", (symbol, tf)
        )
    else:
        conn.execute(
            """INSERT INTO currency_tfs (symbol, tf, candles, first_ts, last_ts)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(symbol, tf) DO UPDATE SET
                   candles  = excluded.candles,
                   first_ts = excluded.first_ts,
                   last_ts  = excluded.last_ts""",
            (symbol, tf, len(df),
             int(df["timestamp"].iloc[0]),
             int(df["timestamp"].iloc[-1])),
        )


def _load_tfs_for(symbol: str, conn) -> dict:
    rows = conn.execute(
        "SELECT tf, candles, first_ts, last_ts FROM currency_tfs WHERE symbol=?",
        (symbol,),
    ).fetchall()

    filters_total = conn.execute(
        "SELECT COUNT(*) as n FROM indicators WHERE type='filter'"
    ).fetchone()["n"]

    tested_rows = conn.execute(
        "SELECT tf, COUNT(*) as n FROM filter_results "
        "WHERE symbol=? AND candle_count >= 0 GROUP BY tf",
        (symbol,),
    ).fetchall()
    tested_map = {r["tf"]: r["n"] for r in tested_rows}

    result = {}
    for r in rows:
        tf_lower = r["tf"].lower()
        result[tf_lower] = {
            "candles":        r["candles"],
            "first_ts":       r["first_ts"],
            "last_ts":        r["last_ts"],
            "filters_tested": tested_map.get(r["tf"], tested_map.get(tf_lower, 0)),
            "filters_total":  filters_total,
        }
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Currencies CRUD
# ─────────────────────────────────────────────────────────────────────────────

@bp.route("/currencies", methods=["GET"])
def list_currencies():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM currencies ORDER BY symbol").fetchall()
    out  = []
    for r in rows:
        d   = row_to_dict(r)
        sym = d["symbol"]
        tfs = _load_tfs_for(sym, conn)
        d["tfs"] = {
            tf: tfs.get(tf, {"candles": 0, "first_ts": None, "last_ts": None})
            for tf in TF_ALL_LOWER
        }
        out.append(d)
    conn.close()
    return jsonify(out)


@bp.route("/currencies/<symbol>", methods=["DELETE"])
def delete_currency(symbol):
    import shutil
    symbol = symbol.upper()
    info   = _get_cur_info(symbol)
    cur_id = info["currency_id"]

    conn = get_conn()
    conn.execute("DELETE FROM currencies   WHERE symbol=?", (symbol,))
    conn.execute("DELETE FROM currency_tfs WHERE symbol=?", (symbol,))
    conn.execute("DELETE FROM filter_results WHERE symbol=?", (symbol,))
    conn.commit()
    conn.close()

    # احذف مجلد العملة كاملاً
    from storage import currency_dir
    folder = currency_dir(symbol, cur_id)
    if os.path.isdir(folder):
        shutil.rmtree(folder, ignore_errors=True)

    return jsonify({"ok": True})


# ─────────────────────────────────────────────────────────────────────────────
# 5m fetch (Binance)
# ─────────────────────────────────────────────────────────────────────────────

@bp.route("/fetch", methods=["POST"])
def start_fetch():
    data   = request.json or {}
    symbol = (data.get("symbol") or "").upper().strip()
    if not symbol:
        return jsonify({"error": "symbol required"}), 400

    if symbol in _fetch_stop_flags and not _fetch_stop_flags[symbol].is_set():
        return jsonify({"error": "already fetching"}), 409

    conn = get_conn()
    existing = conn.execute(
        "SELECT last_ts FROM currencies WHERE symbol=?", (symbol,)
    ).fetchone()
    conn.close()

    start_ms = FETCH_START_MS
    if existing and existing["last_ts"]:
        # أعد جلب آخر شمعة لأنها كانت حية (مفتوحة) وقت الجلب الأول
        start_ms = int(existing["last_ts"])

    stop_event = threading.Event()
    _fetch_stop_flags[symbol] = stop_event
    threading.Thread(
        target=_fetch_worker,
        args=(symbol, start_ms, stop_event),
        daemon=True,
    ).start()
    return jsonify({"ok": True, "symbol": symbol})


@bp.route("/fetch/<symbol>/stop", methods=["POST"])
def stop_fetch(symbol):
    symbol = symbol.upper()
    flag = _fetch_stop_flags.get(symbol)
    if flag:
        flag.set()
    return jsonify({"ok": True})


@bp.route("/currencies/<symbol>/update", methods=["POST"])
def update_currency(symbol):
    symbol = symbol.upper()
    conn = get_conn()
    existing = conn.execute(
        "SELECT last_ts FROM currencies WHERE symbol=?", (symbol,)
    ).fetchone()
    conn.close()

    start_ms = FETCH_START_MS
    if existing and existing["last_ts"]:
        # أعد جلب آخر شمعة لأنها كانت حية (مفتوحة) وقت الجلب السابق
        start_ms = int(existing["last_ts"])

    stop_event = threading.Event()
    _fetch_stop_flags[symbol] = stop_event
    threading.Thread(
        target=_fetch_worker,
        args=(symbol, start_ms, stop_event),
        daemon=True,
    ).start()
    return jsonify({"ok": True})


# ─────────────────────────────────────────────────────────────────────────────
# Per-TF resample
# ─────────────────────────────────────────────────────────────────────────────

@bp.route("/currencies/<symbol>/tf/<tf>/compute", methods=["POST"])
def compute_tf(symbol, tf):
    """جلب شموع الإطار العلوي مباشرة من Binance (لا اشتقاق من 5m)."""
    symbol   = symbol.upper()
    tf_lower = tf.lower()
    if tf_lower not in TF_NON5M:
        return jsonify({"error": "invalid tf"}), 400

    info   = _get_cur_info(symbol)
    cur_id = info["currency_id"]

    try:
        df_tf = _fetch_tf_direct(symbol, tf_lower, cur_id)
    except Exception as e:
        return jsonify({"error": f"fetch failed: {e}"}), 500

    if df_tf.empty:
        return jsonify({"error": "no data fetched from Binance"}), 400

    with _tf_lock(symbol):
        ensure_dirs(symbol, cur_id, tf_lower)
        p = csv_path(symbol, cur_id, tf_lower)
        df_tf.to_csv(p, index=False)

        conn = get_conn()
        try:
            _save_tf_meta(conn, symbol, tf_lower, df_tf)
            conn.commit()
        finally:
            conn.close()

    return jsonify({
        "ok":       True,
        "tf":       tf_lower,
        "candles":  len(df_tf),
        "first_ts": int(df_tf["timestamp"].iloc[0]),
        "last_ts":  int(df_tf["timestamp"].iloc[-1]),
    })


@bp.route("/currencies/<symbol>/tf/<tf>", methods=["DELETE"])
def delete_tf(symbol, tf):
    symbol   = symbol.upper()
    tf_lower = tf.lower()
    if tf_lower not in TF_NON5M:
        return jsonify({"error": "cannot delete 5m via tf endpoint"}), 400

    info   = _get_cur_info(symbol)
    cur_id = info["currency_id"]

    with _tf_lock(symbol):
        p = csv_path(symbol, cur_id, tf_lower)
        if os.path.exists(p):
            os.remove(p)
        conn = get_conn()
        try:
            conn.execute(
                "DELETE FROM currency_tfs WHERE symbol=? AND tf=?", (symbol, tf_lower)
            )
            conn.commit()
        finally:
            conn.close()
    return jsonify({"ok": True})


# ─────────────────────────────────────────────────────────────────────────────
# Filter strip compute
# ─────────────────────────────────────────────────────────────────────────────

@bp.route("/currencies/<symbol>/filters/<tf>/status", methods=["GET"])
def filter_job_status(symbol, tf):
    """يُعيد حالة حساب الفلاتر (للـ polling من الـ frontend)."""
    key = f"{symbol.upper()}-{tf.lower()}"
    job = _filter_jobs.get(key)
    if not job:
        return jsonify({"status": "idle"})
    return jsonify(job)


@bp.route("/currencies/<symbol>/filters/<tf>/compute", methods=["POST"])
def compute_filters(symbol, tf):
    symbol   = symbol.upper()
    tf_lower = tf.lower()
    if tf_lower not in TF_ALL_LOWER:
        return jsonify({"error": "invalid tf"}), 400

    key = f"{symbol}-{tf_lower}"

    # لو جاري حساب مسبقاً → أرجع الحالة الحالية
    if key in _filter_jobs and _filter_jobs[key].get("status") == "running":
        return jsonify({"ok": True, "already_running": True, **_filter_jobs[key]})

    # ابدأ job جديد
    _filter_jobs[key] = {"status": "running", "done": 0, "total": 0, "pct": 0, "errors": []}

    def _worker():
        lock = _filter_lock(symbol, tf_lower)
        if not lock.acquire(blocking=False):
            _filter_jobs[key].update({"status": "error", "error": "يوجد حساب جارٍ"})
            return
        try:
            from services.filter_service import compute_filters as _compute

            def _progress_cb(done: int, total: int):
                pct = round(done / total * 100) if total > 0 else 0
                _filter_jobs[key].update({"done": done, "total": total, "pct": pct})

            result = _compute(symbol, tf_lower, progress_cb=_progress_cb)

            conn = get_conn()
            total_filters = conn.execute(
                "SELECT COUNT(*) as n FROM indicators WHERE type='filter'"
            ).fetchone()["n"]
            conn.close()

            _filter_jobs[key].update({
                "status":        "done" if result.get("ok") else "error",
                "filters_done":  result.get("filters_done", 0),
                "total_filters": total_filters,
                "errors":        result.get("errors", []),
                "pct":           100,
                "error":         result.get("error", ""),
            })
        except Exception as e:
            _filter_jobs[key].update({"status": "error", "error": str(e)})
        finally:
            lock.release()

    threading.Thread(target=_worker, daemon=True).start()
    return jsonify({"ok": True, "started": True, "key": key})


@bp.route("/currencies/<symbol>/filters/<tf>", methods=["GET"])
def get_filter_results(symbol, tf):
    symbol   = symbol.upper()
    tf_lower = tf.lower()
    conn = get_conn()
    rows = conn.execute(
        "SELECT indicator_id, candle_count, computed_at FROM filter_results WHERE symbol=? AND tf=?",
        (symbol, tf_lower)
    ).fetchall()
    conn.close()
    return jsonify({
        "ok":      True,
        "symbol":  symbol,
        "tf":      tf_lower,
        "results": [dict(r) for r in rows],
    })


# ─────────────────────────────────────────────────────────────────────────────
# Export
# ─────────────────────────────────────────────────────────────────────────────

@bp.route("/currencies/<symbol>/export", methods=["GET"])
def export_currency(symbol):
    symbol   = symbol.upper()
    tf       = (request.args.get("tf") or "5m").strip().lower()
    if tf not in TF_ALL_LOWER:
        return jsonify({"error": "invalid tf"}), 400

    info = _get_cur_info(symbol)
    p    = csv_path(symbol, info["currency_id"], tf)
    if not os.path.exists(p):
        return jsonify({"error": "not found"}), 404
    tf_upper = TF_NORM.get(tf, tf.upper())
    return send_file(p, as_attachment=True,
                     download_name=f"{symbol}-{info['currency_id']}-{tf_upper}.csv")


# ─────────────────────────────────────────────────────────────────────────────
# CSV import (5m base)
# ─────────────────────────────────────────────────────────────────────────────

@bp.route("/import", methods=["POST"])
def import_csv():
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400
    f      = request.files["file"]
    symbol = (request.form.get("symbol") or "").upper().strip()
    if not symbol:
        return jsonify({"error": "symbol required"}), 400
    try:
        df = pd.read_csv(f)
        df = _normalize_import(df)
        if df.empty:
            return jsonify({"error": "could not parse CSV"}), 400
        _save_candles(symbol, df)
        return jsonify({"ok": True, "candles": len(df)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def _normalize_import(df: pd.DataFrame) -> pd.DataFrame:
    ts_col = next(
        (c for c in df.columns if c.lower() in
         ("timestamp", "time", "date", "datetime", "open_time")),
        None,
    )
    if ts_col is None:
        return pd.DataFrame()
    df = df.rename(columns={ts_col: "timestamp"})
    ts0 = df["timestamp"].iloc[0]
    if isinstance(ts0, str):
        df["timestamp"] = pd.to_datetime(df["timestamp"]).astype("int64") // 10**6
    elif float(ts0) > 1e12:
        df["timestamp"] = df["timestamp"].astype("int64")
    else:
        df["timestamp"] = (df["timestamp"].astype(float) * 1000).astype("int64")
    for col in ["open", "high", "low", "close", "volume"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df[["timestamp", "open", "high", "low", "close", "volume"]].dropna()
    df = df.sort_values("timestamp").reset_index(drop=True)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# Internals
# ─────────────────────────────────────────────────────────────────────────────

# فترة كل إطار زمني بالمللي ثانية
_TF_MS = {
    "15m": 15 * 60 * 1000,
    "1h":  60 * 60 * 1000,
    "4h":  4  * 60 * 60 * 1000,
    "1d":  24 * 60 * 60 * 1000,
}


def _fetch_tf_direct(symbol: str, tf: str, cur_id: str) -> pd.DataFrame:
    """جلب شموع إطار زمني عالٍ مباشرة من Binance بدون اشتقاق من 5m.

    - يبدأ من آخر شمعة محفوظة (لإعادة جلبها وتصحيح قيمها إن كانت مفتوحة)
    - يحذف الشمعة الحية (التي لم تُغلق بعد)
    - يدمج النتائج مع البيانات الموجودة (الجديدة تحل محل القديمة عند التكرار)
    """
    tf_lower = tf.lower()
    tf_ms    = _TF_MS.get(tf_lower, 15 * 60 * 1000)
    p        = csv_path(symbol, cur_id, tf_lower)

    if os.path.exists(p):
        existing = pd.read_csv(p, dtype={"timestamp": "int64"})
        # أعد جلب آخر شمعة لتصحيح قيمها
        start_ms = int(existing["timestamp"].iloc[-1])
    else:
        existing = pd.DataFrame()
        start_ms = FETCH_START_MS

    now_ms     = int(time.time() * 1000)
    all_frames = []
    cur_ms     = start_ms

    while cur_ms < now_ms:
        try:
            raw = fetch_klines_batch(symbol, cur_ms, interval=tf_lower)
        except Exception:
            break
        if not raw or not isinstance(raw, list):
            break

        # احذف الشمعة الحية (close_time لم يمر بعد)
        if int(raw[-1][6]) >= int(time.time() * 1000):
            raw = raw[:-1]
        if not raw:
            break

        df_batch = klines_to_df(raw)
        if df_batch.empty:
            break
        all_frames.append(df_batch)

        cur_ms = int(raw[-1][0]) + tf_ms
        time.sleep(0.15)

    if not all_frames:
        return existing if not existing.empty else pd.DataFrame()

    df_new = pd.concat(all_frames, ignore_index=True)

    # دمج مع البيانات الموجودة — الجديدة أولاً لتحل محل القديمة
    if not existing.empty:
        df_new = pd.concat([df_new, existing], ignore_index=True)

    df_new = (df_new
              .drop_duplicates(subset=["timestamp"], keep="first")
              .sort_values("timestamp")
              .reset_index(drop=True))
    return df_new


def _fetch_worker(symbol: str, start_ms: int, stop_event: threading.Event):
    now_ms   = int(time.time() * 1000)
    total_5m = (now_ms - FETCH_START_MS) // (5 * 60 * 1000)

    conn = get_conn()
    conn.execute(
        "INSERT OR IGNORE INTO currencies (symbol, fetching) VALUES (?, 1)",
        (symbol,),
    )
    conn.execute(
        "UPDATE currencies SET fetching=1, fetch_pct=0 WHERE symbol=?",
        (symbol,),
    )
    conn.commit()
    conn.close()

    cur_ms            = start_ms
    consecutive_errors = 0
    MAX_CONSECUTIVE    = 5
    last_error         = None

    while cur_ms < now_ms and not stop_event.is_set():
        try:
            raw = fetch_klines_batch(symbol, cur_ms)
            consecutive_errors = 0
        except Exception as e:
            consecutive_errors += 1
            last_error = str(e)
            if consecutive_errors >= MAX_CONSECUTIVE:
                break
            time.sleep(2)
            continue

        if not raw:
            break
        if not isinstance(raw, list):
            last_error = f"binance error: {raw}"
            break

        # احذف الشمعة الحية (لم تُغلق بعد) — close_time في المستقبل
        if int(raw[-1][6]) >= int(time.time() * 1000):
            raw = raw[:-1]
        if not raw:
            break  # كل الشموع حية (نهاية البيانات)

        df_batch = klines_to_df(raw)
        if df_batch.empty:
            break
        _save_candles(symbol, df_batch)

        cur_ms  = int(raw[-1][0]) + 5 * 60 * 1000
        fetched = (cur_ms - FETCH_START_MS) // (5 * 60 * 1000)
        pct     = min(fetched / max(total_5m, 1), 1.0)

        conn = get_conn()
        conn.execute(
            "UPDATE currencies SET fetch_pct=? WHERE symbol=?", (pct, symbol)
        )
        conn.commit()
        conn.close()
        time.sleep(0.15)

    conn = get_conn()
    if cur_ms >= now_ms and not last_error:
        conn.execute(
            "UPDATE currencies SET fetching=0, fetch_pct=1 WHERE symbol=?",
            (symbol,),
        )
    else:
        conn.execute(
            "UPDATE currencies SET fetching=0 WHERE symbol=?", (symbol,)
        )
    conn.commit()
    conn.close()
    _fetch_stop_flags.pop(symbol, None)

    _refresh_existing_tfs(symbol)


def _refresh_existing_tfs(symbol: str):
    """بعد تحديث 5m، أعد جلب الأطر العليا مباشرة من Binance."""
    info   = _get_cur_info(symbol)
    cur_id = info["currency_id"]

    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT tf FROM currency_tfs WHERE symbol=? AND tf <> '5m'",
            (symbol,),
        ).fetchall()
        tfs_to_refresh = [r["tf"] for r in rows]
    finally:
        conn.close()

    with _tf_lock(symbol):
        conn = get_conn()
        try:
            for tf in tfs_to_refresh:
                try:
                    df_tf = _fetch_tf_direct(symbol, tf, cur_id)
                    if df_tf.empty:
                        continue
                    ensure_dirs(symbol, cur_id, tf)
                    p = csv_path(symbol, cur_id, tf)
                    df_tf.to_csv(p, index=False)
                    _save_tf_meta(conn, symbol, tf, df_tf)
                except Exception:
                    continue
            conn.commit()
        finally:
            conn.close()


def _save_candles(symbol: str, df: pd.DataFrame):
    if df.empty:
        return

    info   = get_or_create_currency(symbol)
    cur_id = info["currency_id"]

    ensure_dirs(symbol, cur_id, "5m")
    p = csv_path(symbol, cur_id, "5m")

    if os.path.exists(p):
        existing = pd.read_csv(p, dtype={"timestamp": "int64"})
        # البيانات الجديدة أولاً لتحل محل القديمة عند تكرار الـ timestamp
        df = pd.concat([df, existing], ignore_index=True)
    df = (df.drop_duplicates(subset=["timestamp"], keep="first")
            .sort_values("timestamp")
            .reset_index(drop=True))
    df.to_csv(p, index=False)

    conn = get_conn()
    conn.execute(
        """INSERT INTO currencies (symbol, currency_id, candles, first_ts, last_ts)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(symbol) DO UPDATE SET
               currency_id = excluded.currency_id,
               candles     = excluded.candles,
               first_ts    = excluded.first_ts,
               last_ts     = excluded.last_ts""",
        (symbol, cur_id, len(df),
         int(df["timestamp"].iloc[0]),
         int(df["timestamp"].iloc[-1])),
    )
    _save_tf_meta(conn, symbol, "5m", df)
    conn.commit()
    conn.close()


# ── Debug endpoint ──────────────────────────────────────────────────────────
@bp.route("/debug/<symbol>", methods=["GET"])
def debug_symbol(symbol):
    """يعرض كل المسارات والمعلومات للتشخيص."""
    symbol = symbol.upper()
    from storage import find_currency, csv_path as _csv_path, DATA_DIR
    import glob

    # من DB
    conn = get_conn()
    db_row = conn.execute(
        "SELECT * FROM currencies WHERE symbol=?", (symbol,)
    ).fetchone()
    filter_rows = conn.execute(
        "SELECT indicator_id, tf, candle_count FROM filter_results WHERE symbol=?",
        (symbol,)
    ).fetchall()
    conn.close()

    db_info = dict(db_row) if db_row else {}

    # من filesystem
    fs_info = find_currency(symbol)

    # كل الملفات المتعلقة بالعملة
    pattern = os.path.join(DATA_DIR, f"{symbol}-*")
    folders = glob.glob(pattern)
    all_files = []
    for folder in folders:
        for root, dirs, files in os.walk(folder):
            for f in files:
                all_files.append(os.path.join(root, f).replace(DATA_DIR, "DATA_DIR"))

    return jsonify({
        "symbol":       symbol,
        "db":           db_info,
        "filesystem":   fs_info,
        "data_dir":     DATA_DIR,
        "files":        all_files[:50],
        "filter_results": [dict(r) for r in filter_rows],
    })
