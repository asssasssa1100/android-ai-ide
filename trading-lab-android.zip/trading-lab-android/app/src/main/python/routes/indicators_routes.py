import os
import json
import time
import ast
import uuid
import importlib.util
import pandas as pd
import requests
from flask import Blueprint, request, jsonify
from db import get_conn, row_to_dict
from config import INDICATORS_DIR, BINANCE_BASE_URL
from storage import find_currency, get_or_create_currency, csv_path


def _load_builtin_content(ind_name: str):
    """
    يبحث في مجلد builtin عن ملف يحتوي INDICATOR_NAME مطابق لـ ind_name.
    يُعيد المحتوى النصي إذا وُجد، وإلا None.
    يُستخدم عند الرفع لاستبدال النسخة القديمة بالأحدث تلقائياً.
    """
    builtin_dir = os.path.join(INDICATORS_DIR, "builtin")
    if not os.path.isdir(builtin_dir):
        return None
    try:
        for fname in os.listdir(builtin_dir):
            if not fname.endswith(".py"):
                continue
            fpath = os.path.join(builtin_dir, fname)
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    content = f.read()
                for line in content.splitlines():
                    s = line.strip()
                    if s.startswith("INDICATOR_NAME"):
                        val = s.split("=", 1)[1].strip().strip("'\"")
                        if val == ind_name:
                            return content
                        break
            except Exception:
                pass
    except Exception:
        pass
    return None

bp = Blueprint("indicators", __name__, url_prefix="/api/indicators")

_BUILTIN_LIST = [
    {
        "id":          "stoch",
        "name":        "Stochastic Crossover",
        "version":     "1.0.0",
        "type":        "signal",
        "filename":    "stoch.py",
        "params_json": {"k_period": 14, "smooth_k": 1, "d_period": 3},
        "params":      {"k_period": 14, "smooth_k": 1, "d_period": 3},
        "builtin":     True,
    },
    {
        "id":          "breakout",
        "name":        "Pivot High Breakout",
        "version":     "1.0.0",
        "type":        "signal",
        "filename":    "breakout.py",
        "params_json": {"pivot_bars": 2},
        "params":      {"pivot_bars": 2},
        "builtin":     True,
    },
]


# ─────────────────────────────────────────────────────────
# LIST / UPLOAD / DELETE
# ─────────────────────────────────────────────────────────

@bp.route("/", methods=["GET"])
@bp.route("", methods=["GET"])
def list_indicators():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM indicators ORDER BY name").fetchall()
    conn.close()
    uploaded     = [row_to_dict(r) for r in rows]
    uploaded_ids = {r["id"] for r in uploaded}
    builtins     = [b for b in _BUILTIN_LIST if b["id"] not in uploaded_ids]
    return jsonify(builtins + uploaded)


@bp.route("/upload", methods=["POST"])
@bp.route("/", methods=["POST"])
@bp.route("", methods=["POST"])
def upload_indicator():
    if "file" not in request.files:
        return jsonify({"error": "no file"}), 400

    f        = request.files["file"]
    filename = f.filename or ""
    if not filename.endswith(".py"):
        return jsonify({"error": "must be .py file"}), 400

    try:
        content = f.read().decode("utf-8")
    except UnicodeDecodeError:
        return jsonify({"error": "file must be UTF-8 text"}), 400

    meta = _parse_metadata(content)
    if not meta.get("type"):
        return jsonify({"error": "missing INDICATOR_TYPE in file"}), 400
    if meta["type"] not in ("filter", "signal"):
        return jsonify({"error": "INDICATOR_TYPE must be 'filter' or 'signal'"}), 400
    if not meta.get("name"):
        return jsonify({"error": "missing INDICATOR_NAME in file"}), 400

    try:
        compile(content, filename, "exec")
    except SyntaxError as e:
        return jsonify({"error": f"syntax error: {e}"}), 400

    # إذا تطابق اسم المؤشر مع builtin → استبدل بالنسخة الأحدث تلقائياً
    # يحل مشكلة رفع نسخة قديمة من الهاتف
    builtin_content = _load_builtin_content(meta["name"])
    if builtin_content:
        content = builtin_content
        # أعد تحليل الميتاداتا من النسخة الأحدث
        meta = _parse_metadata(content)

    ind_id    = str(uuid.uuid4())[:8]
    save_name = f"{ind_id}.py"
    save_path = os.path.join(INDICATORS_DIR, save_name)
    with open(save_path, "w", encoding="utf-8") as out:
        out.write(content)

    conn = get_conn()
    conn.execute(
        "INSERT INTO indicators (id, name, version, type, filename, params_json) "
        "VALUES (?,?,?,?,?,?)",
        (
            ind_id,
            meta["name"],
            meta.get("version", "1.0.0"),
            meta["type"],
            save_name,
            json.dumps(meta.get("params", {})),
        ),
    )
    conn.commit()
    conn.close()
    return jsonify({"ok": True, "id": ind_id, "type": meta["type"], "name": meta["name"]})


@bp.route("/<ind_id>", methods=["DELETE"])
def delete_indicator(ind_id):
    if any(b["id"] == ind_id for b in _BUILTIN_LIST):
        return jsonify({"ok": False, "error": "المؤشرات المدمجة لا يمكن حذفها"}), 400
    conn = get_conn()
    row  = conn.execute(
        "SELECT filename FROM indicators WHERE id=?", (ind_id,)
    ).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "error": "not found"}), 404
    path = os.path.join(INDICATORS_DIR, row["filename"])
    if os.path.exists(path):
        os.remove(path)
    conn.execute("DELETE FROM indicators WHERE id=?", (ind_id,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


# ─────────────────────────────────────────────────────────
# LIVE VERIFY
# ─────────────────────────────────────────────────────────

@bp.route("/<ind_id>/verify", methods=["POST"])
def verify_indicator(ind_id):
    """
    يشغّل المؤشر على بيانات حقيقية (مخزّنة + مباشرة من Binance).

    Body: { symbol?, tf?, limit? }
    """
    body   = request.get_json(silent=True) or {}
    limit  = int(body.get("limit") or 1500)
    symbol = "BTCUSDT"
    tf     = "5m"

    # ── Lookup indicator ──────────────────────────────────
    conn = get_conn()
    row  = conn.execute("SELECT * FROM indicators WHERE id=?", (ind_id,)).fetchone()
    conn.close()
    if row:
        ind = row_to_dict(row)
    else:
        ind = next((b for b in _BUILTIN_LIST if b["id"] == ind_id), None)
        if ind is None:
            return jsonify({"ok": False, "error": "indicator not found"}), 404

    # ── 1. CSV المخزّن (نظام المجلدات الجديد) ────────────
    df_list = []
    info    = find_currency(symbol)
    if info:
        p = csv_path(symbol, info["currency_id"], tf)
        if os.path.exists(p):
            try:
                df_raw = pd.read_csv(p)
                if not df_raw.empty:
                    if len(df_raw) > limit:
                        df_raw = df_raw.tail(limit).reset_index(drop=True)
                    df_list = _df_to_list(df_raw)
            except Exception as e:
                return jsonify({"ok": False, "error": f"read csv: {e}"}), 400

    # ── 2. بيانات لايف من Binance ─────────────────────────
    # إذا لا يوجد CSV → جلب 500 شمعة (ضروري لتقارب EMA)
    # إذا يوجد CSV  → جلب 30 فقط للتحديث
    live_count = 30 if df_list else 500
    try:
        live = _fetch_live_klines(symbol, tf, count=live_count)
    except Exception:
        live = []

    if live:
        if df_list:
            last_cached_ts = df_list[-1]["time"]
            new_live = [c for c in live if c["time"] > last_cached_ts]
            df_list  = df_list + new_live
        else:
            df_list = live

    if not df_list:
        return jsonify({
            "ok":    False,
            "error": f"لا توجد بيانات {tf} لـ {symbol} — افتح بطاقة العملة وحساب الفريم",
        }), 400

    # ── 3. تحميل وتشغيل المؤشر ────────────────────────────
    try:
        if ind.get("builtin"):
            # المؤشرات المدمجة: استخدام نظام الاستيراد مباشرة (أكثر موثوقية)
            mod_name = f"indicators.builtin.{ind['id']}"
            import sys
            if mod_name in sys.modules:
                del sys.modules[mod_name]
            mod = importlib.import_module(mod_name)
        else:
            # المؤشرات المرفوعة: تحميل من مسار الملف
            path = os.path.join(INDICATORS_DIR, ind["filename"])
            if not os.path.exists(path):
                return jsonify({"ok": False, "error": "ملف المؤشر مفقود"}), 500
            # طبقة حماية: إذا كان الملف قديماً وهناك builtin بنفس الاسم → حدّث قبل التحميل
            try:
                builtin_latest = _load_builtin_content(ind.get("name", ""))
                if builtin_latest:
                    with open(path, "w", encoding="utf-8") as _f:
                        _f.write(builtin_latest)
            except Exception:
                pass
            spec = importlib.util.spec_from_file_location(
                f"ind_{ind_id}_{int(time.time()*1000)}", path
            )
            if spec is None or spec.loader is None:
                return jsonify({"ok": False, "error": "تعذر تحميل الملف"}), 500
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
    except Exception as e:
        return jsonify({"ok": False, "error": f"خطأ تحميل: {type(e).__name__}: {e}"}), 400

    params = ind.get("params") or {}
    if isinstance(params, str):
        try:
            params = json.loads(params)
        except Exception:
            params = {}

    t0 = time.time()
    try:
        if ind["type"] == "filter":
            if not hasattr(mod, "generate_mask"):
                return jsonify({
                    "ok": False,
                    "error": "الفلتر يجب أن يحتوي على generate_mask(df, params)"
                }), 400
            result = mod.generate_mask(df_list, params)
        else:
            if not hasattr(mod, "generate_signals"):
                return jsonify({
                    "ok": False,
                    "error": "الإشارة يجب أن تحتوي على generate_signals(df, params)"
                }), 400
            result = mod.generate_signals(df_list, params)
    except Exception as e:
        return jsonify({
            "ok": False,
            "error": f"خطأ تنفيذ: {type(e).__name__}: {e}"
        }), 400

    elapsed_ms = int((time.time() - t0) * 1000)

    common = {
        "ok":             True,
        "indicator_name": ind.get("name"),
        "version":        ind.get("version"),
        "params":         params,
        "symbol":         symbol,
        "tf":             tf,
    }

    if ind["type"] == "filter":
        return _build_filter_response(common, df_list, result, elapsed_ms)
    else:
        return _build_signal_response(common, df_list, result, elapsed_ms)


# ─────────────────────────────────────────────────────────
# Response builders
# ─────────────────────────────────────────────────────────

def _build_filter_response(common, df_list, result, elapsed_ms):
    if not isinstance(result, list):
        return jsonify({
            "ok": False,
            "error": f"generate_mask يجب أن يعيد list (وصلنا {type(result).__name__})"
        }), 400
    if len(result) != len(df_list):
        return jsonify({
            "ok": False,
            "error": f"طول الناتج ({len(result)}) ≠ عدد الشموع ({len(df_list)})",
        }), 400

    norm = []
    for r in result:
        if r is None:
            norm.append((None, {}))
        elif isinstance(r, bool):
            norm.append((r, {}))
        elif isinstance(r, dict):
            active = r.get("active")
            if not isinstance(active, bool):
                active = bool(r.get("value"))
            extras = {k: v for k, v in r.items() if k != "active"}
            norm.append((active, extras))
        else:
            try:
                norm.append((bool(r), {}))
            except Exception:
                norm.append((None, {}))

    active_count   = sum(1 for a, _ in norm if a is True)
    inactive_count = sum(1 for a, _ in norm if a is False)
    warmup         = sum(1 for a, _ in norm if a is None)

    last_value       = None
    last_value_label = None
    for i in range(len(norm) - 1, -1, -1):
        a, ex = norm[i]
        if a is None:
            continue
        for k, v in ex.items():
            if isinstance(v, (int, float)):
                last_value       = round(float(v), 4)
                last_value_label = k
                break
        if last_value is not None:
            break

    last_candles = []
    for i in range(len(df_list) - 1, max(-1, len(df_list) - 6), -1):
        c    = df_list[i]
        a, ex = norm[i]
        last_candles.append({
            "time":   _fmt_time(c["time"]),
            "ts":     int(c["time"]),
            "open":   float(c["open"]),
            "high":   float(c["high"]),
            "low":    float(c["low"]),
            "close":  float(c["close"]),
            "volume": float(c["volume"]),
            "active": a,
            "extras": _round_extras(ex),
        })

    common.update({
        "type": "filter",
        "stats": {
            "total":             len(df_list),
            "active_count":      active_count,
            "inactive_count":    inactive_count,
            "warmup":            warmup,
            "last_value":        last_value,
            "last_value_label":  last_value_label,
            "ms":                elapsed_ms,
        },
        "last_candles": last_candles,
    })
    return jsonify(common)


def _build_signal_response(common, df_list, result, elapsed_ms):
    if not isinstance(result, list):
        return jsonify({
            "ok": False,
            "error": f"generate_signals يجب أن يعيد list (وصلنا {type(result).__name__})"
        }), 400

    sigs = []
    for r in result:
        if isinstance(r, (int, float)):
            sigs.append({"time": int(r), "extras": {}})
        elif isinstance(r, dict):
            ts = r.get("time") or r.get("ts") or r.get("timestamp")
            if ts is None:
                continue
            extras = {k: v for k, v in r.items() if k not in ("time", "ts", "timestamp")}
            sigs.append({"time": int(ts), "extras": extras})
        else:
            return jsonify({
                "ok": False,
                "error": "generate_signals يجب أن يعيد list من timestamps أو dicts",
            }), 400

    sigs.sort(key=lambda s: s["time"])

    ts_to_idx  = {int(c["time"]): i for i, c in enumerate(df_list)}
    now_ms     = int(time.time() * 1000)
    cutoff_30d = now_ms - 30 * 24 * 60 * 60 * 1000
    signals_30d = sum(1 for s in sigs if s["time"] >= cutoff_30d)

    gaps = []
    for i in range(1, len(sigs)):
        a_idx = ts_to_idx.get(sigs[i - 1]["time"])
        b_idx = ts_to_idx.get(sigs[i]["time"])
        if a_idx is not None and b_idx is not None:
            gaps.append(b_idx - a_idx)
    avg_gap = int(round(sum(gaps) / len(gaps))) if gaps else None

    last_signal       = sigs[-1] if sigs else None
    last_signal_label = _fmt_time(last_signal["time"]).split(" ")[1] if last_signal else "—"
    last_signal_ts    = last_signal["time"] if last_signal else None

    last_signals_out = []
    for s in reversed(sigs[-5:]):
        idx = ts_to_idx.get(s["time"])
        if idx is None:
            continue
        c = df_list[idx]
        last_signals_out.append({
            "time":   _fmt_time(c["time"]),
            "ts":     int(c["time"]),
            "open":   float(c["open"]),
            "high":   float(c["high"]),
            "low":    float(c["low"]),
            "close":  float(c["close"]),
            "volume": float(c["volume"]),
            "extras": _round_extras(s["extras"]),
        })

    common.update({
        "type": "signal",
        "stats": {
            "total":             len(df_list),
            "signals_count":     len(sigs),
            "signals_30d":       signals_30d,
            "last_signal_label": last_signal_label,
            "last_signal_ts":    last_signal_ts,
            "avg_gap_candles":   avg_gap,
            "ms":                elapsed_ms,
        },
        "last_signals": last_signals_out,
    })
    return jsonify(common)


# ─────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────

def _df_to_list(df_raw: pd.DataFrame) -> list:
    return [
        {
            "time":   int(r["timestamp"]),
            "open":   float(r["open"]),
            "high":   float(r["high"]),
            "low":    float(r["low"]),
            "close":  float(r["close"]),
            "volume": float(r["volume"]),
        }
        for r in df_raw.to_dict("records")
    ]


def _fetch_live_klines(symbol: str, tf: str, count: int = 30) -> list:
    # نطلب شمعة إضافية لأننا سنستبعد الأخيرة (غير مغلقة بعد)
    params = {
        "symbol":   symbol.upper(),
        "interval": tf,
        "limit":    int(count) + 1,
    }
    resp = requests.get(f"{BINANCE_BASE_URL}/klines", params=params, timeout=8)
    resp.raise_for_status()
    raw = resp.json()
    if not isinstance(raw, list):
        return []
    candles = [
        {
            "time":   int(k[0]),
            "open":   float(k[1]),
            "high":   float(k[2]),
            "low":    float(k[3]),
            "close":  float(k[4]),
            "volume": float(k[5]),
        }
        for k in raw
    ]
    # استبعاد آخر شمعة — لم تُغلق بعد (شمعة حية متشكّلة)
    return candles[:-1] if candles else []


def _fmt_time(ts_ms: int) -> str:
    t = time.gmtime(int(ts_ms) // 1000)
    return time.strftime("%Y-%m-%d %H:%M", t)


def _round_extras(extras: dict) -> dict:
    out = {}
    for k, v in extras.items():
        if isinstance(v, bool):
            out[k] = v
        elif isinstance(v, (int, float)):
            out[k] = round(float(v), 4)
        else:
            out[k] = v
    return out


def _parse_metadata(content: str) -> dict:
    meta = {}
    for line in content.splitlines():
        s = line.strip()
        if s.startswith("INDICATOR_NAME"):
            meta["name"] = _extract_str(s)
        elif s.startswith("INDICATOR_VERSION"):
            meta["version"] = _extract_str(s)
        elif s.startswith("INDICATOR_TYPE"):
            meta["type"] = _extract_str(s)
        elif s.startswith("PARAMETERS"):
            try:
                val = s.split("=", 1)[1].strip()
                meta["params"] = ast.literal_eval(val)
            except Exception:
                pass
    return meta


def _extract_str(line: str) -> str:
    val = line.split("=", 1)[1].strip()
    if (val.startswith('"') and val.endswith('"')) or (
        val.startswith("'") and val.endswith("'")
    ):
        val = val[1:-1]
    return val
