import json
import time
import threading
import uuid
from flask import Blueprint, request, jsonify
from db import get_conn, row_to_dict
from services.backtest_service import (
    run_backtest, compute_stats, ensure_all_tfs, save_test_signal_json
)

bp = Blueprint("test", __name__, url_prefix="/api/test")

_running_tests = {}

_BUILTIN_SIGNALS = [
    {"id": "stoch",    "name": "Stochastic Crossover"},
    {"id": "breakout", "name": "Pivot High Breakout"},
]


def _resolve_signal(signal_name: str):
    conn = get_conn()
    row = conn.execute(
        "SELECT id, name FROM indicators WHERE name=? AND type='signal'",
        (signal_name,)
    ).fetchone()
    conn.close()
    if row:
        return row["id"], row["name"]
    for b in _BUILTIN_SIGNALS:
        if b["name"] == signal_name:
            return b["id"], b["name"]
    return None, None


@bp.route("", methods=["GET"])
@bp.route("/", methods=["GET"])
def list_tests():
    conn = get_conn()
    rows = conn.execute(
        """SELECT id, signal_name, symbol, symbols_json, tf, rr,
                  status, progress, trades, wins, losses, opens,
                  win_rate, net_pnl, created_at, finished_at
           FROM tests ORDER BY created_at DESC"""
    ).fetchall()
    conn.close()
    result = []
    for r in rows:
        d = dict(r)
        try:
            d["symbols"] = json.loads(d.get("symbols_json") or "[]")
        except Exception:
            d["symbols"] = []
        if not d.get("symbol") and d["symbols"]:
            d["symbol"] = d["symbols"][0]
        result.append(d)
    return jsonify({"tests": result})


@bp.route("/<test_id>", methods=["GET"])
def get_test(test_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM tests WHERE id=?", (test_id,)).fetchone()
    conn.close()
    if not row:
        return jsonify({"error": "not found"}), 404
    d = dict(row)
    try:
        d["symbols"]     = json.loads(d.get("symbols_json") or "[]")
        d["trades_list"] = json.loads(d.get("result_json") or "[]")
    except Exception:
        d["symbols"]     = []
        d["trades_list"] = []
    return jsonify(d)


@bp.route("", methods=["POST"])
@bp.route("/", methods=["POST"])
def create_test():
    data        = request.json or {}
    signal_name = (data.get("signal_name") or "").strip()
    symbols     = data.get("symbols") or []
    tf          = (data.get("tf") or "5m").strip().lower()
    rr          = float(data.get("rr") or 2.0)
    params      = data.get("params") or {}

    if not signal_name:
        return jsonify({"error": "signal_name مطلوب"}), 400
    if not symbols:
        return jsonify({"error": "symbols مطلوبة"}), 400
    if isinstance(symbols, str):
        symbols = [symbols]

    signal_id, resolved_name = _resolve_signal(signal_name)
    if not signal_id:
        return jsonify({"error": f"الإشارة '{signal_name}' غير موجودة"}), 404

    test_id = "TST-" + str(uuid.uuid4())[:6].upper()
    now     = int(time.time() * 1000)

    conn = get_conn()
    conn.execute(
        """INSERT INTO tests
             (id, signal_id, symbol,
              signal_name, symbols_json, tf, rr, status, created_at)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (
            test_id,
            signal_id,
            symbols[0] if symbols else '',
            resolved_name,
            json.dumps(symbols),
            tf, rr, "running", now,
        )
    )
    conn.commit()
    conn.close()

    stop_event = threading.Event()
    _running_tests[test_id] = stop_event
    t = threading.Thread(
        target=_test_worker,
        args=(test_id, symbols, signal_id, resolved_name, params, tf, rr, stop_event),
        daemon=True
    )
    t.start()
    return jsonify({"ok": True, "id": test_id})


@bp.route("/<test_id>/stop", methods=["POST"])
def stop_test(test_id):
    flag = _running_tests.get(test_id)
    if flag:
        flag.set()
    return jsonify({"ok": True})


@bp.route("/<test_id>/export", methods=["GET"])
def export_test(test_id):
    """تصدير صفقات الاختبار كملف JSON قابل للتحميل."""
    from flask import Response
    conn = get_conn()
    row = conn.execute("SELECT * FROM tests WHERE id=?", (test_id,)).fetchone()
    conn.close()
    if not row:
        return jsonify({"error": "not found"}), 404
    d = dict(row)
    try:
        trades = json.loads(d.get("result_json") or "[]")
    except Exception:
        trades = []
    export_data = {
        "test_id":     d.get("id"),
        "signal_name": d.get("signal_name"),
        "symbol":      d.get("symbol"),
        "tf":          d.get("tf"),
        "rr":          d.get("rr"),
        "win_rate":    d.get("win_rate"),
        "trades":      d.get("trades"),
        "wins":        d.get("wins"),
        "losses":      d.get("losses"),
        "opens":       d.get("opens"),
        "trades_list": trades,
    }
    filename = f"{test_id}-trades.json"
    return Response(
        json.dumps(export_data, ensure_ascii=False, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@bp.route("/<test_id>", methods=["DELETE"])
def delete_test(test_id):
    conn = get_conn()
    conn.execute("DELETE FROM analyses WHERE test_id=?", (test_id,))
    conn.execute("DELETE FROM top10   WHERE test_id=?", (test_id,))
    conn.execute("DELETE FROM tests   WHERE id=?",      (test_id,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


@bp.route("/pause_all", methods=["POST"])
def pause_all_tests():
    from services.backtest_service import set_test_pause
    set_test_pause()
    return jsonify({"ok": True, "status": "paused"})


@bp.route("/resume_all", methods=["POST"])
def resume_all_tests():
    from services.backtest_service import clear_test_pause
    clear_test_pause()
    return jsonify({"ok": True, "status": "resumed"})


@bp.route("/pause_status", methods=["GET"])
def pause_status():
    from services.backtest_service import is_test_paused
    return jsonify({"paused": is_test_paused()})


def _test_worker(test_id, symbols, signal_id, signal_name, params, tf, rr, stop_event):

    def progress_cb(pct):
        if stop_event.is_set():
            raise InterruptedError
        conn = get_conn()
        conn.execute("UPDATE tests SET progress=? WHERE id=?", (pct, test_id))
        conn.commit()
        conn.close()

    try:
        all_trades = []
        n = len(symbols)

        for sym_idx, symbol in enumerate(symbols):
            if stop_event.is_set():
                raise InterruptedError

            def sym_progress(pct, _si=sym_idx, _n=n):
                progress_cb((_si + pct) / _n)

            # ✅ إذا كان الفريم غير 5m تأكد من وجود بيانات الـ TF الصحيح
            if tf.lower() != "5m":
                ensure_all_tfs(symbol)

            trades = run_backtest(symbol, signal_id, params, rr,
                                  tf=tf, progress_cb=sym_progress)
            for t in trades:
                t["symbol"] = symbol
            all_trades.extend(trades)

            # ── حفظ SIGNAL.json لكل عملة مباشرة بعد اختبارها ──
            sym_trades = [t for t in all_trades if t.get("symbol") == symbol]
            sym_stats  = compute_stats(sym_trades)
            try:
                save_test_signal_json(symbol, tf, signal_name, sym_trades, sym_stats)
            except Exception:
                pass

        stats   = compute_stats(all_trades)
        net_pnl = round(
            sum(t["pnl_pct"] for t in all_trades if t.get("pnl_pct") is not None), 2
        )
        win_rate = stats["wr"]

        conn = get_conn()
        conn.execute(
            """UPDATE tests SET
                 status='done', progress=1,
                 trades=?, wins=?, losses=?, opens=?,
                 win_rate=?, net_pnl=?,
                 result_json=?, finished_at=?
               WHERE id=?""",
            (
                stats["trades"], stats["wins"], stats["losses"], stats["opens"],
                win_rate, net_pnl,
                json.dumps(all_trades),
                int(time.time() * 1000),
                test_id,
            )
        )
        conn.commit()
        conn.close()

    except InterruptedError:
        conn = get_conn()
        conn.execute("UPDATE tests SET status='paused' WHERE id=?", (test_id,))
        conn.commit()
        conn.close()

    except Exception as e:
        conn = get_conn()
        conn.execute(
            "UPDATE tests SET status='error', result_json=? WHERE id=?",
            (json.dumps({"error": str(e)}), test_id)
        )
        conn.commit()
        conn.close()

    finally:
        _running_tests.pop(test_id, None)
