"""server_config.py — جسر بين Java و config.py"""
import os


def set_data_dir(base_dir: str):
    """يُستدعى من Java لتحديد مجلد البيانات الرئيسي."""
    data_path = os.path.join(base_dir, "trading_lab")
    os.makedirs(os.path.join(data_path, "data"),       exist_ok=True)
    os.makedirs(os.path.join(data_path, "indicators"),  exist_ok=True)

    os.environ["TRADING_LAB_DATA"] = data_path
    os.environ["TL_DATA_DIR"]      = os.path.join(data_path, "data")
    os.environ["TL_IND_DIR"]       = os.path.join(data_path, "indicators")


def get_data_dir() -> str:
    return os.environ.get("TRADING_LAB_DATA", "/tmp/trading_lab")
