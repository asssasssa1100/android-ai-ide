"""
analysis_service.py
-------------------
Two filtering strategies:

1. filter_trades_from_saved  — matches trades against pre-saved filter_results
2. run_top10_from_saved      — Hybrid search:
                               Phase 1: Exhaustive size-1 (all pairs individually)
                               Phase 2: Exhaustive size-2 (all pairs of pairs)
                               Phase 3: Greedy from best found
                               مُسرَّع بـ NumPy boolean masks.
"""

import json
import itertools
import threading

import numpy as np
import pandas as pd

from config import INDICATORS_DIR
from db import get_conn, row_to_dict

TF_MS = {
    "1m":  60_000,    "3m":  180_000,   "5m":  300_000,
    "15m": 900_000,   "30m": 1_800_000,  "1h":  3_600_000,
    "2h":  7_200_000, "4h":  14_400_000, "6h":  21_600_000,
    "8h":  28_800_000,"12h": 43_200_000,
    "1d":  86_400_000,"3d":  259_200_000,"1w":  604_800_000,
}


# ─────────────────────────────────────────────────────────────────────────────
# Saved-data approach (unchanged — manual analysis)
# ─────────────────────────────────────────────────────────────────────────────

def filter_trades_from_saved(trades: list, filters: list, symbol: str,
                              signal_tf_ms: int = 300_000) -> list:
    """
    Filter trades using pre-saved active candle timestamps (filter_results table).

    filters: [{"indicator_id": "IND-XXX", "tf": "1h"}, ...]

    Window logic (mirrors TradingView request.security lookahead_off):
      - Same-TF filter (duration == signal_tf_ms):
          window = [candle_ts, candle_ts + duration)
      - Cross-TF filter (duration > signal_tf_ms):
          window = [candle_ts + duration, candle_ts + 2*duration)

    If a filter has no saved data for this symbol/tf -> blocks everything (returns []).
    """
    if not filters:
        return trades

    symbol = symbol.upper()
    all_windows: list = []

    conn = get_conn()
    for f in filters:
        ind_id = f.get("indicator_id") or f.get("id") or ""
        tf     = f.get("tf", "5m")

        row = conn.execute(
            "SELECT candles_json FROM filter_results "
            "WHERE indicator_id=? AND symbol=? AND tf=?",
            (ind_id, symbol, tf),
        ).fetchone()

        if row is None:
            conn.close()
            return []

        try:
            candles = json.loads(row["candles_json"] or "[]")
        except Exception:
            candles = []

        duration = TF_MS.get(tf, 300_000)

        if duration > signal_tf_ms:
            windows = sorted(
                (int(c["ts"]) + duration, int(c["ts"]) + 2 * duration)
                for c in candles if "ts" in c
            )
        else:
            windows = sorted(
                (int(c["ts"]), int(c["ts"]) + duration)
                for c in candles if "ts" in c
            )
        all_windows.append(windows)

    conn.close()

    def _in_windows(ts: int, windows: list) -> bool:
        for start, end in windows:
            if start <= ts < end:
                return True
            if start > ts:
                break
        return False

    return [
        trade for trade in trades
        if all(_in_windows(int(trade.get("entry_ts", 0)), wins)
               for wins in all_windows)
    ]


# ─────────────────────────────────────────────────────────────────────────────
# NumPy helpers
# ─────────────────────────────────────────────────────────────────────────────

def _build_trade_mask_np(trades_ts_np: np.ndarray, windows: list) -> np.ndarray:
    """
    O(N log M) mask building via numpy searchsorted.

    بدلاً من حلقة Python بـ O(N×M) كانت تُجمّد التطبيق مع 180,000 صفقة،
    نستخدم searchsorted لإيجاد النافذة المناسبة لكل timestamp في O(N log M).

    الشرط: windows يجب أن تكون مرتّبة تصاعدياً بـ start (كما يضمن sorted() في الكود).
    النوافذ غير متداخلة لكل (indicator_id, tf) — وهو الشكل الطبيعي للشموع.
    """
    n = len(trades_ts_np)
    mask = np.zeros(n, dtype=bool)
    if not windows or n == 0:
        return mask

    starts = np.array([w[0] for w in windows], dtype=np.int64)
    ends   = np.array([w[1] for w in windows], dtype=np.int64)

    # لكل صفقة: أوجد آخر نافذة حيث start <= ts  → O(N log M)
    idx = np.searchsorted(starts, trades_ts_np, side='right') - 1

    # صالح فقط إذا idx >= 0 (يوجد نافذة تبدأ قبل أو عند هذا الـ timestamp)
    valid = idx >= 0
    if not np.any(valid):
        return mask

    valid_pos  = np.where(valid)[0]
    window_idx = idx[valid_pos]

    # تحقق أن ts < end لتلك النافذة (داخل النافذة الفعلية)
    in_window = trades_ts_np[valid_pos] < ends[window_idx]
    mask[valid_pos[in_window]] = True

    return mask


def _score_combo(masks, wins_np, loss_np, effective_min):
    """
    يحسب إحصاءات تركيبة بسرعة باستخدام AND منطقي لجميع الـ masks.
    يُعيد None إذا لم تستوفِ الحد الأدنى للصفقات.
    """
    if len(masks) == 1:
        combined = masks[0]
    elif len(masks) == 2:
        combined = masks[0] & masks[1]
    else:
        combined = np.logical_and.reduce(masks)

    total_kept = int(combined.sum())
    if total_kept < effective_min:
        return None

    wins   = int(np.logical_and(combined, wins_np).sum())
    losses = int(np.logical_and(combined, loss_np).sum())
    closed = wins + losses
    wr     = round(wins / closed * 100, 2) if closed > 0 else 0.0

    return {
        "trades": total_kept,
        "closed": closed,
        "wins":   wins,
        "losses": losses,
        "wr":     wr,
    }


def _insert_top10(results: list, entry: dict) -> list:
    """يُدرج نتيجة في قائمة Top-10 مرتّبة بـ WR تنازلياً."""
    results.append(entry)
    results.sort(key=lambda x: x["wr"], reverse=True)
    return results[:10]


# ─────────────────────────────────────────────────────────────────────────────
# Hybrid Top-10 Search
# ─────────────────────────────────────────────────────────────────────────────

def run_top10_from_saved(
    trades: list,
    symbol: str,
    indicator_ids: list,
    allowed_tfs: list,
    min_trades: int = 5,
    min_coverage_pct: float = 20.0,
    rr: float = 2.0,
    progress_cb=None,
    signal_tf_ms: int = 300_000,
    stop_event=None,
    checkpoint: dict = None,
) -> dict:
    """
    Hybrid search — ثلاث مراحل:
      Phase 1 — Exhaustive size-1: كل زوج (indicator_id, tf) منفرداً
      Phase 2 — Exhaustive size-2: كل التركيبات الممكنة من زوجين
      Phase 3 — Greedy:            ابنِ أفضل تركيبة خطوة بخطوة

    min_coverage_pct: الحد الأدنى كنسبة مئوية من إجمالي الصفقات
                      effective_min = max(min_trades, n_trades * pct/100)

    يُعيد dict:
      {
        "results":     [...top10...],
        "combos_done": N,
        "checkpoint":  {...} | None,   # None عند الانتهاء الكامل
        "stopped":     bool,
      }
    """
    if not indicator_ids or not trades:
        return {"results": [], "combos_done": 0, "checkpoint": None, "stopped": False}

    if stop_event is None:
        stop_event = threading.Event()

    symbol   = symbol.upper()
    n_trades = len(trades)

    # ── الحد الأدنى الفعلي للصفقات ───────────────────────────────────────
    coverage_min  = int(n_trades * min_coverage_pct / 100.0)
    effective_min = max(min_trades, coverage_min)

    # ── 1. أوجد (indicator_id, tf) المتاحة ───────────────────────────────
    conn = get_conn()
    available: list = []
    for ind_id in indicator_ids:
        if allowed_tfs:
            placeholders = ",".join("?" * len(allowed_tfs))
            rows = conn.execute(
                f"SELECT tf FROM filter_results "
                f"WHERE indicator_id=? AND symbol=? AND tf IN ({placeholders})",
                (ind_id, symbol, *allowed_tfs),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT tf FROM filter_results WHERE indicator_id=? AND symbol=?",
                (ind_id, symbol),
            ).fetchall()
        for row in rows:
            available.append((ind_id, row["tf"]))

    if not available:
        conn.close()
        return {"results": [], "combos_done": 0, "checkpoint": None, "stopped": False}

    # ── 2. بناء نوافذ الفلاتر ────────────────────────────────────────────
    windows_cache = {}
    for ind_id, tf in available:
        row = conn.execute(
            "SELECT candles_json FROM filter_results "
            "WHERE indicator_id=? AND symbol=? AND tf=?",
            (ind_id, symbol, tf),
        ).fetchone()
        if row:
            try:
                candles = json.loads(row["candles_json"] or "[]")
            except Exception:
                candles = []
            duration = TF_MS.get(tf, 300_000)
            if duration > signal_tf_ms:
                windows_cache[(ind_id, tf)] = sorted(
                    (int(c["ts"]) + duration, int(c["ts"]) + 2 * duration)
                    for c in candles if "ts" in c
                )
            else:
                windows_cache[(ind_id, tf)] = sorted(
                    (int(c["ts"]), int(c["ts"]) + duration)
                    for c in candles if "ts" in c
                )
    conn.close()

    # ── 3. NumPy arrays للصفقات ───────────────────────────────────────────
    trades_ts_np = np.fromiter(
        (int(t.get("entry_ts", 0)) for t in trades), dtype=np.int64, count=n_trades
    )
    wins_np = np.fromiter(
        (t.get("result") == "win" for t in trades), dtype=bool, count=n_trades
    )
    loss_np = np.fromiter(
        (t.get("result") == "loss" for t in trades), dtype=bool, count=n_trades
    )

    # ── 4. بناء trade-mask لكل زوج ────────────────────────────────────────
    filter_mask = {}
    for key, windows in windows_cache.items():
        filter_mask[key] = _build_trade_mask_np(trades_ts_np, windows)

    N = len(available)

    # ── تحميل نقطة الحفظ (للاستئناف) ────────────────────────────────────
    start_phase = 1
    start_idx   = 0
    top_results = []
    combos_done = 0

    if checkpoint:
        start_phase = checkpoint.get("phase", 1)
        start_idx   = checkpoint.get("phase_idx", 0)
        top_results = checkpoint.get("best", [])
        combos_done = checkpoint.get("combos_done", 0)

    # ── تقدير إجمالي العمل لشريط التقدم ──────────────────────────────────
    phase1_total = N
    phase2_total = N * (N - 1) // 2
    phase3_est   = N * 3
    grand_total  = max(phase1_total + phase2_total + phase3_est, 1)

    _done_before_p3 = phase1_total + phase2_total

    def _report(done_in_phase, phase_offset):
        if progress_cb:
            try:
                progress_cb(min((phase_offset + done_in_phase) / grand_total, 0.99))
            except Exception:
                pass

    # ══════════════════════════════════════════════════════════════════════
    # PHASE 1 — Exhaustive size-1
    # ══════════════════════════════════════════════════════════════════════
    if start_phase <= 1:
        report_every_1 = max(1, phase1_total // 20)
        i_start = start_idx if start_phase == 1 else 0

        for i in range(i_start, N):
            if stop_event.is_set():
                ckpt = {"phase": 1, "phase_idx": i,
                        "best": top_results, "combos_done": combos_done}
                return {"results": top_results, "combos_done": combos_done,
                        "checkpoint": ckpt, "stopped": True}

            key = available[i]
            m   = filter_mask.get(key)
            if m is None:
                continue

            score = _score_combo([m], wins_np, loss_np, effective_min)
            combos_done += 1

            if score:
                entry = {
                    "filters": [{"indicator_id": key[0], "tf": key[1]}],
                    **score,
                }
                top_results = _insert_top10(top_results, entry)

            if combos_done % report_every_1 == 0:
                _report(i - i_start + 1, 0)

        start_phase = 2
        start_idx   = 0
        _report(phase1_total, 0)

    # ══════════════════════════════════════════════════════════════════════
    # PHASE 2 — Exhaustive size-2
    # ══════════════════════════════════════════════════════════════════════
    if start_phase <= 2:
        pairs     = list(itertools.combinations(range(N), 2))
        total2    = len(pairs)
        idx_start = start_idx if start_phase == 2 else 0
        report_every_2 = max(1, total2 // 50)

        for idx in range(idx_start, total2):
            if stop_event.is_set():
                ckpt = {"phase": 2, "phase_idx": idx,
                        "best": top_results, "combos_done": combos_done}
                return {"results": top_results, "combos_done": combos_done,
                        "checkpoint": ckpt, "stopped": True}

            i, j   = pairs[idx]
            k1, k2 = available[i], available[j]
            m1     = filter_mask.get(k1)
            m2     = filter_mask.get(k2)
            if m1 is None or m2 is None:
                continue

            score = _score_combo([m1, m2], wins_np, loss_np, effective_min)
            combos_done += 1

            if score:
                entry = {
                    "filters": [
                        {"indicator_id": k1[0], "tf": k1[1]},
                        {"indicator_id": k2[0], "tf": k2[1]},
                    ],
                    **score,
                }
                top_results = _insert_top10(top_results, entry)

            if (idx - idx_start + 1) % report_every_2 == 0:
                _report(idx - idx_start + 1, phase1_total)

        start_phase = 3
        start_idx   = 0
        _report(phase2_total, phase1_total)

    # ══════════════════════════════════════════════════════════════════════
    # PHASE 3 — Greedy from best found combination
    # ══════════════════════════════════════════════════════════════════════
    if start_phase <= 3:
        if top_results:
            best_filters = top_results[0]["filters"]
            current_keys = [(f["indicator_id"], f["tf"]) for f in best_filters]
        else:
            current_keys = [available[0]] if available else []

        used      = set(map(tuple, current_keys))
        remaining = [k for k in available if tuple(k) not in used]

        greedy_step  = start_idx if start_phase == 3 else 0
        max_depth    = min(N, 15)

        while remaining and greedy_step < max_depth:
            if stop_event.is_set():
                ckpt = {"phase": 3, "phase_idx": greedy_step,
                        "best": top_results, "combos_done": combos_done}
                return {"results": top_results, "combos_done": combos_done,
                        "checkpoint": ckpt, "stopped": True}

            best_score = None
            best_key   = None

            for key in remaining:
                trial_keys = current_keys + [key]
                masks = [filter_mask.get(tuple(k)) for k in trial_keys]
                if any(m is None for m in masks):
                    continue
                score = _score_combo(masks, wins_np, loss_np, effective_min)
                combos_done += 1
                if score and (best_score is None or score["wr"] > best_score["wr"]):
                    best_score = score
                    best_key   = key

            # إذا لم نجد تحسناً ذا قيمة بعد عمقين، نتوقف
            if best_key is None:
                break
            if (top_results and best_score
                    and best_score["wr"] <= top_results[0]["wr"]
                    and greedy_step >= 2):
                break

            current_keys.append(best_key)
            used.add(tuple(best_key))
            remaining = [k for k in remaining if tuple(k) not in used]
            greedy_step += 1

            if best_score:
                entry = {
                    "filters": [{"indicator_id": k[0], "tf": k[1]}
                                 for k in current_keys],
                    **best_score,
                }
                top_results = _insert_top10(top_results, entry)

            _report(greedy_step * len(remaining), _done_before_p3)

    if progress_cb:
        try:
            progress_cb(1.0)
        except Exception:
            pass

    return {
        "results":     top_results,
        "combos_done": combos_done,
        "checkpoint":  None,
        "stopped":     False,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Multi-Currency Top-10
# ─────────────────────────────────────────────────────────────────────────────

def run_multicur_top10(
    signal_name: str,
    symbols: list,
    indicator_ids: list,
    allowed_tfs: list,
    min_trades: int = 5,
    min_wr_strict: float = 50.0,
    min_currencies_pct: float = 80.0,
    progress_cb=None,
    stop_event=None,
) -> dict:
    """
    Multi-Currency Top-10 بخوارزمية Greedy متعددة البذور.

    تبحث عن تركيبات فلاتر تؤدي جيداً عبر جميع العملات المحددة دفعةً واحدة،
    مما يتجنب مشكلة Overfitting لعملة واحدة.

    المعاملات:
        signal_name       : اسم الإشارة (لتحديد الاختبارات المرتبطة بها)
        symbols           : قائمة العملات
        indicator_ids     : قائمة IDs الفلاتر المتاحة
        allowed_tfs       : الأطر الزمنية المسموحة
        min_trades        : الحد الأدنى للصفقات لكل عملة
        min_wr_strict     : الحد الأدنى لـ WR (يجب أن تحققه كل عملة - وضع صارم)
        min_currencies_pct: نسبة العملات التي يجب أن تحقق الحد الأدنى (وضع مرن)
        progress_cb       : callback(float 0..1) لتحديث شريط التقدم
        stop_event        : threading.Event للإيقاف

    يُعيد dict:
        {
          "results":      [...top10...],   # مرتّبة بـ avg_wr تنازلياً
          "combos_done":  int,
          "missing_data": [{"symbol": str, "tf": str}],  # عملات تنقصها بيانات الفلاتر
          "stopped":      bool,
        }

    كل نتيجة في results:
        {
          "filters":       [{"indicator_id": str, "tf": str}],
          "avg_wr":        float,
          "currencies_pass": int,   # عدد العملات التي اجتازت الحد
          "currencies_total": int,
          "per_currency":  [{"symbol": str, "wr": float, "trades": int, "wins": int}],
        }
    """
    if stop_event is None:
        stop_event = threading.Event()

    if not symbols or not indicator_ids:
        return {"results": [], "combos_done": 0, "missing_data": [], "stopped": False}

    symbols = [s.upper() for s in symbols]
    n_syms  = len(symbols)

    # ── 1. جلب بيانات الصفقات لكل عملة من الاختبارات ────────────────────
    # نبحث عن اختبارات تحتوي على signal_name وعلى هذه العملات
    conn = get_conn()
    test_rows = conn.execute(
        "SELECT id, symbols_json, symbol, tf, result_json FROM tests "
        "WHERE signal_name=? AND status='done'",
        (signal_name,),
    ).fetchall()
    conn.close()

    # بناء خريطة: symbol -> قائمة الصفقات (نأخذ أول اختبار لكل عملة)
    trades_map: dict = {}   # symbol -> list[trade]
    signal_tf_map: dict = {}  # symbol -> tf_ms

    for row in test_rows:
        row_d = row_to_dict(row)
        raw_syms = row_d.get("symbols_json") or "[]"
        if isinstance(raw_syms, str):
            try:
                row_syms = json.loads(raw_syms)
            except Exception:
                row_syms = []
        else:
            row_syms = list(raw_syms) if raw_syms else []
        # أضف symbol المنفرد إذا لزم
        if not row_syms and row_d.get("symbol"):
            row_syms = [row_d["symbol"]]

        raw_t = row_d.get("result_json") or "[]"
        if isinstance(raw_t, str):
            try:
                trades_list = json.loads(raw_t)
            except Exception:
                trades_list = []
        else:
            trades_list = list(raw_t)

        tf_str = (row_d.get("tf") or "5m").lower()
        tf_ms  = TF_MS.get(tf_str, 300_000)

        for sym in row_syms:
            sym_up = sym.upper()
            if sym_up in symbols and sym_up not in trades_map:
                sym_trades = [t for t in trades_list if str(t.get("symbol", sym_up)).upper() == sym_up]
                if not sym_trades:
                    sym_trades = trades_list
                if sym_trades:
                    trades_map[sym_up]   = sym_trades
                    signal_tf_map[sym_up] = tf_ms

    # العملات التي لم نجد لها اختبارات
    missing_symbols = [s for s in symbols if s not in trades_map]

    # ── 2. التحقق من توفر بيانات الفلاتر لكل عملة ────────────────────────
    missing_data: list = []
    conn = get_conn()
    for sym in symbols:
        for ind_id in indicator_ids:
            for tf in (allowed_tfs if allowed_tfs else ["5m", "15m", "1h", "4h", "1d"]):
                row = conn.execute(
                    "SELECT id FROM filter_results WHERE indicator_id=? AND symbol=? AND tf=?",
                    (ind_id, sym, tf),
                ).fetchone()
                if row is None:
                    # هذا المزيج مفقود — نُضيف تحذيراً
                    missing_data.append({"symbol": sym, "indicator_id": ind_id, "tf": tf})
    conn.close()

    # ── 3. بناء نوافذ الفلاتر لكل عملة ──────────────────────────────────
    # windows_cache[sym][(ind_id, tf)] = list of (start, end)
    conn = get_conn()
    windows_all: dict = {}
    available_keys_per_sym: dict = {}  # sym -> list of (ind_id, tf) متاحة فعلاً

    for sym in symbols:
        tf_ms_sym = signal_tf_map.get(sym, 300_000)
        windows_all[sym] = {}
        available_keys_per_sym[sym] = []

        if allowed_tfs:
            placeholders = ",".join("?" * len(allowed_tfs))
            all_fr = conn.execute(
                f"SELECT indicator_id, tf, candles_json FROM filter_results "
                f"WHERE symbol=? AND indicator_id IN ({','.join('?'*len(indicator_ids))}) "
                f"AND tf IN ({placeholders})",
                (sym, *indicator_ids, *allowed_tfs),
            ).fetchall()
        else:
            all_fr = conn.execute(
                f"SELECT indicator_id, tf, candles_json FROM filter_results "
                f"WHERE symbol=? AND indicator_id IN ({','.join('?'*len(indicator_ids))})",
                (sym, *indicator_ids),
            ).fetchall()

        for fr_row in all_fr:
            ind_id = fr_row["indicator_id"]
            tf     = fr_row["tf"]
            try:
                candles = json.loads(fr_row["candles_json"] or "[]")
            except Exception:
                candles = []
            duration = TF_MS.get(tf, 300_000)
            if duration > tf_ms_sym:
                wins = sorted(
                    (int(c["ts"]) + duration, int(c["ts"]) + 2 * duration)
                    for c in candles if "ts" in c
                )
            else:
                wins = sorted(
                    (int(c["ts"]), int(c["ts"]) + duration)
                    for c in candles if "ts" in c
                )
            windows_all[sym][(ind_id, tf)] = wins
            available_keys_per_sym[sym].append((ind_id, tf))

    conn.close()

    # المفاتيح المشتركة عبر كل العملات التي لديها صفقات
    active_syms = [s for s in symbols if s in trades_map]
    if not active_syms:
        # لم نجد صفقات لأي عملة — الاختبارات غير موجودة أو result_json فارغ
        for sym in symbols:
            missing_data.append({
                "symbol": sym, "tf": "—",
                "reason": "لا توجد نتائج اختبار لهذه العملة بهذه الإشارة"
            })
        return {"results": [], "combos_done": 0, "missing_data": missing_data, "stopped": False}

    # keys التي تتوفر لها بيانات في كل العملات النشطة
    all_keys_union = set()
    for sym in active_syms:
        for k in available_keys_per_sym[sym]:
            all_keys_union.add(tuple(k))

    common_keys = None
    for sym in active_syms:
        sym_keys = set(map(tuple, available_keys_per_sym[sym]))
        if common_keys is None:
            common_keys = sym_keys
        else:
            common_keys &= sym_keys

    if not common_keys:
        # لا يوجد فلتر مشترك — بيّن أي عملة تنقصها بيانات
        all_present = set()
        for sym in active_syms:
            all_present.update(set(map(tuple, available_keys_per_sym[sym])))
        for sym in active_syms:
            sym_k = set(map(tuple, available_keys_per_sym[sym]))
            missing_for_sym = all_present - sym_k
            for k in missing_for_sym:
                missing_data.append({
                    "symbol": sym, "tf": k[1],
                    "reason": f"اضغط 'تحديث' في صفحة البيانات لـ {sym}"
                })
        if not missing_data:
            # لا توجد بيانات فلاتر أصلاً — الحل: اضغط تحديث في صفحة البيانات
            for sym in active_syms:
                missing_data.append({
                    "symbol": sym, "tf": "—",
                    "reason": "لا توجد بيانات فلاتر — اضغط 'تحديث' في صفحة البيانات"
                })
        return {"results": [], "combos_done": 0, "missing_data": missing_data, "stopped": False}

    common_keys = list(common_keys)
    N = len(common_keys)

    # ── 4. بناء NumPy arrays لكل عملة ────────────────────────────────────
    np_data: dict = {}  # sym -> {ts, wins, loss, mask_per_key}
    for sym in active_syms:
        trades = trades_map[sym]
        n_t    = len(trades)
        ts_np  = np.fromiter(
            (int(t.get("entry_ts", 0)) for t in trades), dtype=np.int64, count=n_t
        )
        wins_np = np.fromiter(
            (t.get("result") == "win" for t in trades), dtype=bool, count=n_t
        )
        loss_np = np.fromiter(
            (t.get("result") == "loss" for t in trades), dtype=bool, count=n_t
        )
        masks: dict = {}
        for key in common_keys:
            wins_w = windows_all[sym].get(key, [])
            masks[key] = _build_trade_mask_np(ts_np, wins_w)
        np_data[sym] = {"ts": ts_np, "wins": wins_np, "loss": loss_np, "masks": masks}

    # ── 5. دالة تقييم تركيبة عبر جميع العملات ───────────────────────────
    min_pass = max(1, int(n_syms * min_currencies_pct / 100.0))

    def _eval_combo_multicur(keys_combo: list):
        """يُعيد None إذا فشلت، وإلا يُعيد dict مع إحصاءات لكل عملة."""
        per_cur = []
        pass_count = 0
        wr_sum = 0.0

        for sym in active_syms:
            d = np_data[sym]
            masks_c = [d["masks"].get(tuple(k)) for k in keys_combo]
            if any(m is None for m in masks_c):
                continue
            score = _score_combo(masks_c, d["wins"], d["loss"], min_trades)
            if score is None:
                per_cur.append({"symbol": sym, "wr": 0.0, "trades": 0, "wins": 0, "pass": False})
                continue
            passes = score["wr"] >= min_wr_strict
            if passes:
                pass_count += 1
            wr_sum += score["wr"]
            per_cur.append({
                "symbol": sym,
                "wr":     score["wr"],
                "trades": score["trades"],
                "wins":   score["wins"],
                "pass":   passes,
            })

        if pass_count < min_pass:
            return None

        avg_wr = round(wr_sum / len(per_cur), 2) if per_cur else 0.0
        return {
            "avg_wr":           avg_wr,
            "currencies_pass":  pass_count,
            "currencies_total": len(active_syms),
            "per_currency":     per_cur,
        }

    def _insert_multicur_top10(results: list, entry: dict) -> list:
        results.append(entry)
        results.sort(key=lambda x: (x["currencies_pass"], x["avg_wr"]), reverse=True)
        return results[:10]

    top_results = []
    combos_done = 0
    grand_total = max(N + N * (N - 1) // 2 + N * 3, 1)

    def _report(done):
        if progress_cb:
            try:
                progress_cb(min(done / grand_total, 0.99))
            except Exception:
                pass

    # ══ Phase 1: كل (ind, tf) منفرداً ═════════════════════════════════════
    for i, key in enumerate(common_keys):
        if stop_event.is_set():
            return {"results": top_results, "combos_done": combos_done,
                    "missing_data": missing_data, "stopped": True}
        combos_done += 1
        res = _eval_combo_multicur([key])
        if res:
            entry = {"filters": [{"indicator_id": key[0], "tf": key[1]}], **res}
            top_results = _insert_multicur_top10(top_results, entry)
        if i % max(1, N // 20) == 0:
            _report(i + 1)

    _report(N)

    # ══ Phase 2: تركيبات حجم 2 ════════════════════════════════════════════
    pairs = list(itertools.combinations(range(N), 2))
    for idx, (i, j) in enumerate(pairs):
        if stop_event.is_set():
            return {"results": top_results, "combos_done": combos_done,
                    "missing_data": missing_data, "stopped": True}
        combos_done += 1
        res = _eval_combo_multicur([common_keys[i], common_keys[j]])
        if res:
            entry = {
                "filters": [
                    {"indicator_id": common_keys[i][0], "tf": common_keys[i][1]},
                    {"indicator_id": common_keys[j][0], "tf": common_keys[j][1]},
                ],
                **res,
            }
            top_results = _insert_multicur_top10(top_results, entry)
        if idx % max(1, len(pairs) // 50) == 0:
            _report(N + idx + 1)

    _report(N + len(pairs))

    # ══ Phase 3: Greedy من أفضل بذرة ══════════════════════════════════════
    if top_results:
        best_filters = top_results[0]["filters"]
        current_keys = [(f["indicator_id"], f["tf"]) for f in best_filters]
    else:
        current_keys = [common_keys[0]] if common_keys else []

    used      = set(map(tuple, current_keys))
    remaining = [k for k in common_keys if tuple(k) not in used]
    max_depth = min(N, 12)
    step      = 0

    while remaining and step < max_depth:
        if stop_event.is_set():
            return {"results": top_results, "combos_done": combos_done,
                    "missing_data": missing_data, "stopped": True}

        best_score = None
        best_key   = None

        for key in remaining:
            combos_done += 1
            trial = current_keys + [key]
            res = _eval_combo_multicur(trial)
            if res and (best_score is None or
                        (res["currencies_pass"], res["avg_wr"]) >
                        (best_score["currencies_pass"], best_score["avg_wr"])):
                best_score = res
                best_key   = key

        if best_key is None:
            break
        if (top_results and best_score and
                best_score["avg_wr"] <= top_results[0]["avg_wr"] and step >= 2):
            break

        current_keys.append(best_key)
        used.add(tuple(best_key))
        remaining = [k for k in remaining if tuple(k) not in used]
        step += 1

        if best_score:
            entry = {
                "filters": [{"indicator_id": k[0], "tf": k[1]} for k in current_keys],
                **best_score,
            }
            top_results = _insert_multicur_top10(top_results, entry)

        _report(N + len(pairs) + step * len(remaining))

    if progress_cb:
        try:
            progress_cb(1.0)
        except Exception:
            pass

    return {
        "results":      top_results,
        "combos_done":  combos_done,
        "missing_data": missing_data,
        "stopped":      False,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Available data helper
# ─────────────────────────────────────────────────────────────────────────────

def get_available_data(symbol: str) -> dict:
    symbol = symbol.upper()
    conn   = get_conn()

    ind_rows = conn.execute(
        "SELECT id, name FROM indicators WHERE type='filter'"
    ).fetchall()
    ind_map = {r["id"]: r["name"] for r in ind_rows}

    fr_rows = conn.execute(
        "SELECT indicator_id, tf, candle_count FROM filter_results WHERE symbol=?",
        (symbol,),
    ).fetchall()

    tf_rows = conn.execute(
        "SELECT tf FROM currency_tfs WHERE symbol=?",
        (symbol,),
    ).fetchall()
    all_tfs = list({r["tf"] for r in tf_rows})

    conn.close()

    by_ind: dict = {}
    for r in fr_rows:
        ind_id = r["indicator_id"]
        if ind_id not in by_ind:
            by_ind[ind_id] = {"indicator_id": ind_id,
                              "name": ind_map.get(ind_id, ind_id),
                              "tfs": []}
        if r["candle_count"] >= 0:
            by_ind[ind_id]["tfs"].append(r["tf"])

    available_tfs = sorted({r["tf"] for r in fr_rows if r["candle_count"] >= 0})

    return {
        "symbol":     symbol,
        "indicators": list(by_ind.values()),
        "all_tfs":    available_tfs,
        "saved_tfs":  all_tfs,
    }


def compute_stats_from_trades(trades: list) -> dict:
    closed = [t for t in trades if t.get("result") in ("win", "loss")]
    wins   = [t for t in closed if t.get("result") == "win"]
    wr     = round(len(wins) / len(closed) * 100, 2) if closed else 0.0
    return {
        "trades":  len(trades),
        "closed":  len(closed),
        "wins":    len(wins),
        "losses":  len(closed) - len(wins),
        "wr":      wr,
    }


# ─────────────────────────────────────────────────────────────────────────────
# LEGACY (kept for compatibility)
# ─────────────────────────────────────────────────────────────────────────────

def filter_trades(trades: list, df_5m: pd.DataFrame, filters: list) -> list:
    if not filters:
        return trades
    ts_index = {ts: i for i, ts in enumerate(df_5m["timestamp"])}
    combined = [True] * len(df_5m)
    for f in filters:
        mask = _apply_filter_legacy(df_5m, f.get("id") or f.get("name", ""),
                                    f.get("tf", "5m"), f.get("params", {}))
        for i in range(len(combined)):
            combined[i] = combined[i] and (mask[i] if i < len(mask) else False)
    return [t for t in trades
            if (idx := ts_index.get(t.get("entry_ts"))) is not None
            and idx < len(combined) and combined[idx]]


def _apply_filter_legacy(df_5m, filter_id, tf, params):
    import os, importlib.util
    from services.binance_service import resample_to_tf
    df_tf = resample_to_tf(df_5m, tf) if tf != "5m" else df_5m.copy()
    path  = os.path.join(INDICATORS_DIR, f"{filter_id}.py")
    if not os.path.exists(path):
        return [True] * len(df_5m)
    spec = importlib.util.spec_from_file_location("_lf", path)
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "generate_mask"):
        return [True] * len(df_5m)
    mask_tf = [bool(x) for x in mod.generate_mask(list(df_tf.to_dict("records")), params)]
    if tf == "5m":
        return mask_tf
    periods = TF_MS.get(tf, 300_000) // 300_000
    mask_5m = []
    for val in mask_tf:
        mask_5m.extend([val] * periods)
    return mask_5m[:len(df_5m)]
