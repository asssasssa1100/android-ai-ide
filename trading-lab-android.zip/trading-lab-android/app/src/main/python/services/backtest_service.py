import os
import importlib.util
import pandas as pd
import numpy as np
import time
from pathlib import Path
from config import DATA_DIR, INDICATORS_DIR
from services.binance_service import resample_to_tf
from storage import get_or_create_currency, csv_path, save_signal_json

_BUILTIN_DIR = os.path.join(INDICATORS_DIR, "builtin")

_STATE_DIR = Path(os.environ.get("TL_DATA_DIR", "/tmp/trading_lab/data")).parent / "state"
_STATE_DIR.mkdir(parents=True, exist_ok=True)
TEST_PAUSE_FLAG = _STATE_DIR / "test_pause.flag"

def is_test_paused():   return TEST_PAUSE_FLAG.exists()
def set_test_pause():   TEST_PAUSE_FLAG.write_text("1")
def clear_test_pause():
    try: TEST_PAUSE_FLAG.unlink()
    except FileNotFoundError: pass


def load_5m_df(symbol: str) -> pd.DataFrame:
    """تحميل بيانات 5m — محتفظ به للتوافق مع الكود القديم."""
    return load_tf_df(symbol, "5m")


def load_tf_df(symbol: str, tf: str = "5m") -> pd.DataFrame:
    """تحميل بيانات أي فريم زمني من CSV الصحيح."""
    info = get_or_create_currency(symbol)
    p    = csv_path(symbol, info["currency_id"], tf.lower())
    if not os.path.exists(p):
        return pd.DataFrame()
    return pd.read_csv(p, dtype={
        "timestamp": "int64", "open": float,
        "high": float, "low": float, "close": float, "volume": float
    })


def ensure_all_tfs(symbol: str):
    info  = get_or_create_currency(symbol)
    cur_id = info["currency_id"]
    p5m   = csv_path(symbol, cur_id, "5m")
    if not os.path.exists(p5m):
        return
    try:
        df_5m = pd.read_csv(p5m, dtype={"timestamp": "int64", "open": float,
                                         "high": float, "low": float,
                                         "close": float, "volume": float})
        if df_5m.empty:
            return
        from storage import ensure_dirs
        for tf in ("15m", "1h", "4h", "1d"):
            p = csv_path(symbol, cur_id, tf)
            if not os.path.exists(p):
                try:
                    df_tf = resample_to_tf(df_5m, tf)
                    if not df_tf.empty:
                        ensure_dirs(symbol, cur_id, tf)
                        df_tf.to_csv(p, index=False)
                except Exception:
                    pass
    except Exception:
        pass


def compute_fractal_low_table(lows_np):
    n = len(lows_np)
    if n < 5:
        return np.array([], dtype=np.int64), np.array([], dtype=np.float64)
    center = lows_np[2:n - 2]
    is_f   = (
        (center < lows_np[0:n - 4]) &
        (center < lows_np[1:n - 3]) &
        (center < lows_np[3:n - 1]) &
        (center < lows_np[4:n])
    )
    pos_local       = np.where(is_f)[0]
    fractal_positions = pos_local + 2
    fractal_values  = lows_np[fractal_positions]
    return fractal_positions, fractal_values


def _swing_low_for_entry(entry_idx, lows_np, fractal_positions, fractal_values, max_lookback=80):
    """
    منطق SL المُحسَّن:

    1. نبحث عن أقرب فراكتال قاع مؤهل (شرط 5 شموع) قبل شمعة الإشارة.
    2. نتحقق: هل قاع شمعة الإشارة أو الشمعة التي قبلها مباشرة < قاع الفراكتال؟
       - نعم → الفراكتال يُلغى → SL = min(قاع الإشارة, قاع ما قبلها)
       - لا  → SL = قاع الفراكتال
    3. إذا لم يُعثر على فراكتال ضمن max_lookback → SL = min(قاع الإشارة, قاع ما قبلها)
    """
    n  = len(lows_np)
    ei = int(entry_idx)

    # قاع شمعة الإشارة + قاع الشمعة التي قبلها مباشرة
    sig_low  = float(lows_np[ei]) if ei < n else float('inf')
    prev_low = float(lows_np[ei - 1]) if ei > 0 else sig_low
    recent_low = min(sig_low, prev_low)

    # بحث عن أقرب فراكتال مؤهل ضمن نطاق max_lookback
    if len(fractal_positions) > 0:
        # الفراكتال عند pos يتطلب تأكيد شمعتين يمين → pos <= ei - 2
        idx = int(np.searchsorted(fractal_positions, ei - 2, side='right')) - 1
        if idx >= 0:
            f_pos = int(fractal_positions[idx])
            if (ei - f_pos) <= (max_lookback + 2):
                fractal_low = float(fractal_values[idx])
                # قاع الإشارة أو ما قبلها أدنى من الفراكتال → الفراكتال يُلغى
                if recent_low < fractal_low:
                    return recent_low
                # الفراكتال سليم → استخدمه
                return fractal_low

    # لا يوجد فراكتال → نستخدم أدنى قاع بين الإشارة والشمعة قبلها
    return recent_low


def run_backtest(symbol: str, signal_id: str, params: dict, rr: float,
                 tf: str = "5m", progress_cb=None) -> list:
    """
    Backtest على بيانات الفريم المحدد (tf).
    SL: Bill Williams Fractal Low (NumPy vectorized).
    Entry: close شمعة الإشارة (مطابقة TradingView bar-close execution).
    بعد الانتهاء يحفظ SIGNAL.json في مجلد العملة.
    """
    # ✅ تحميل البيانات من الفريم الصحيح — ليس دائماً 5m
    df = load_tf_df(symbol, tf)
    if df.empty:
        # احتياطي: إذا لم يوجد CSV للفريم المطلوب حاول إعادة البناء من 5m
        df5 = load_tf_df(symbol, "5m")
        if df5.empty:
            return []
        if tf.lower() != "5m":
            try:
                from services.binance_service import resample_to_tf
                df = resample_to_tf(df5, tf)
                if df.empty:
                    return []
            except Exception:
                return []
        else:
            df = df5
    if df.empty:
        return []

    signals = _get_signals(df, signal_id, params)
    if not signals:
        if progress_cb:
            progress_cb(1.0)
        return []

    # ── تحويل الأعمدة إلى numpy arrays مرة واحدة (أسرع 10-100x من df.iloc في loop) ──
    lows_np   = df["low"].to_numpy()
    highs_np  = df["high"].to_numpy()
    opens_np  = df["open"].to_numpy()
    closes_np = df["close"].to_numpy()
    ts_np     = df["timestamp"].to_numpy()
    n_candles = len(df)
    n_signals = len(signals)

    f_pos, f_val = compute_fractal_low_table(lows_np)

    trades = []
    CHUNK  = 500   # نُبلّغ عن التقدم كل chunk

    for chunk_start in range(0, n_signals, CHUNK):
        if is_test_paused():
            break
        chunk = signals[chunk_start:chunk_start + CHUNK]

        # تقدم حقيقي: نسبة الإشارات المُعالجة
        if progress_cb:
            progress_cb(chunk_start / n_signals)

        for signal_idx in chunk:
            # الدخول عند إغلاق شمعة الإشارة (مطابق TradingView bar-close)
            entry_price = float(closes_np[signal_idx])
            entry_ts    = int(ts_np[signal_idx])

            sl   = _swing_low_for_entry(signal_idx, lows_np, f_pos, f_val)
            # إذا كان SL فوق سعر الدخول → تجاهل الصفقة (لا SL عشوائي)
            if sl >= entry_price:
                continue
            risk = entry_price - sl
            if risk <= 0:
                continue
            tp = entry_price + risk * rr

            result     = "open"
            exit_ts    = None
            exit_price = None
            pnl_pct    = None

            # ── المسح الأمامي يبدأ من الشمعة التالية للإشارة ──
            for j in range(signal_idx + 1, n_candles):
                h = float(highs_np[j])
                l = float(lows_np[j])
                if h >= tp:
                    result     = "win"
                    exit_price = tp
                    exit_ts    = int(ts_np[j])
                    pnl_pct    = round(rr * (risk / entry_price) * 100, 2)
                    break
                if l <= sl:
                    result     = "loss"
                    exit_price = sl
                    exit_ts    = int(ts_np[j])
                    pnl_pct    = round(-(risk / entry_price) * 100, 2)
                    break

            trades.append({
                "entry_ts":    entry_ts,
                "entry_price": round(entry_price, 6),
                "sl":          round(sl, 6),
                "tp":          round(tp, 6),
                "result":      result,
                "exit_ts":     exit_ts,
                "exit_price":  round(exit_price, 6) if exit_price else None,
                "pnl_pct":     pnl_pct,
            })

    if progress_cb:
        progress_cb(1.0)
    return trades


def save_test_signal_json(symbol: str, tf: str, signal_name: str,
                          trades: list, stats: dict):
    """
    يحفظ نتائج الاختبار كـ SIGNAL.json في مجلد العملة.
    المسار: data/{SYM}-{ID}/{SYM}-{ID}-SIGNAL/{SYM}-{ID}-{TF}-SIGNAL.json
    """
    info = get_or_create_currency(symbol)
    save_signal_json(symbol, info["currency_id"], tf, signal_name, trades, stats)


def _get_module_warmup(mod, params: dict) -> int:
    base_params  = getattr(mod, "PARAMETERS", {}) or {}
    period_words = ("period", "fast", "slow", "length", "window", "bars", "k_period", "d_period")
    values = []
    for k, v in {**base_params, **params}.items():
        if any(w in k.lower() for w in period_words):
            if isinstance(v, (int, float)) and v > 0:
                values.append(int(v))
    return (max(values) + 1) if values else 0


def _get_signals(df: pd.DataFrame, signal_id: str, params: dict) -> list:
    if signal_id == "stoch":
        k_period = int(params.get("k_period", 14))
        d_period = int(params.get("d_period", 3))
        smooth_k = int(params.get("smooth_k", 1))
        warmup   = k_period + smooth_k + d_period - 1
        raw      = _stoch_signals(df, params)
        return [s for s in raw if s >= warmup]

    if signal_id == "breakout":
        pivot_bars = int(params.get("pivot_bars", 2))
        warmup     = pivot_bars * 3
        raw        = _breakout_signals(df, params)
        return [s for s in raw if s >= warmup]

    indicator_path = os.path.join(INDICATORS_DIR, f"{signal_id}.py")
    if not os.path.exists(indicator_path):
        indicator_path = os.path.join(_BUILTIN_DIR, f"{signal_id}.py")
    if not os.path.exists(indicator_path):
        _py_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        indicator_path = os.path.join(_py_dir, "indicators", "builtin", f"{signal_id}.py")
    if not os.path.exists(indicator_path):
        return []

    spec = importlib.util.spec_from_file_location(
        f"_tl_signal_{signal_id}_{int(time.time()*1000)}", indicator_path
    )
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    if not hasattr(mod, "generate_signals"):
        return []

    warmup  = _get_module_warmup(mod, params)
    df_list = df.to_dict("records")
    result  = mod.generate_signals(df_list, params or {})

    ts_index = {int(r["timestamp"]): i for i, r in enumerate(df_list)}
    indices  = []
    for r in result:
        if isinstance(r, dict):
            ts = r.get("timestamp") or r.get("time") or r.get("ts")
            if ts is not None:
                idx = ts_index.get(int(ts))
                if idx is not None and 0 <= idx < len(df):
                    indices.append(idx)
        elif isinstance(r, (int, float)):
            idx = int(r)
            if 0 <= idx < len(df):
                indices.append(idx)

    filtered = sorted(set(indices))
    return [s for s in filtered if s >= warmup]


def _stoch_signals(df: pd.DataFrame, params: dict) -> list:
    """
    Stochastic Crossover — مطابق تماماً لـ TradingView:
      K = 100 * (close - lowest_low) / (highest_high - lowest_low)
      D = SMA(K, d_period)
      Signal = ta.crossover(K, D)  →  K[i-1] < D[i-1] AND K[i] > D[i]
    - عند rng == 0 يُعيد NaN (مثل TV) لا 0، لتجنب إشارات وهمية
    - Fully vectorized بـ NumPy — يعمل بكفاءة على 900k شمعة
    """
    k_period = int(params.get("k_period", 14))
    smooth_k = int(params.get("smooth_k", 1))
    d_period = int(params.get("d_period", 3))
    n = len(df)
    if n < k_period + d_period + 2:
        return []

    closes = df["close"].to_numpy(dtype=np.float64)
    lows   = df["low"].to_numpy(dtype=np.float64)
    highs  = df["high"].to_numpy(dtype=np.float64)

    ll  = pd.Series(lows ).rolling(k_period, min_periods=k_period).min().to_numpy(dtype=np.float64)
    hh  = pd.Series(highs).rolling(k_period, min_periods=k_period).max().to_numpy(dtype=np.float64)
    rng = hh - ll

    # K raw: NaN عندما rng==0 أو قبل warmup — مطابق TV (لا يُعطي 0 كـ fallback)
    with np.errstate(divide="ignore", invalid="ignore"):
        raw_k = np.where(rng > 0, 100.0 * (closes - ll) / rng, 50.0)  # 50 عند rng==0 مطابق TradingView
    raw_k[: k_period - 1] = np.nan  # warmup explicit

    # ── K smoothing ──────────────────────────────────────────────────────────
    # نستخدم حلقة بسيطة (Python scalar sum) بدلاً من pandas rolling.mean()
    # السبب: pandas يستخدم Kahan summation الذي يعطي نتائج مختلفة بـ 1-2 بت
    # عن Python's sum() — هذا الفرق الدقيق ينتج إشارة زائدة واحدة.
    if smooth_k > 1:
        k = np.full(n, np.nan)
        for i in range(k_period - 1 + smooth_k - 1, n):
            s = 0.0
            for j in range(smooth_k):
                s += raw_k[i - smooth_k + 1 + j]
            k[i] = s / smooth_k
    else:
        k = raw_k.copy()

    # ── D line — نفس المبدأ: scalar sum مطابق لـ Python ─────────────────────
    d = np.full(n, np.nan)
    k_first = k_period - 1 + (smooth_k - 1)   # أول index صالح في K
    d_first = k_first + d_period - 1            # أول index صالح في D
    for i in range(d_first, n):
        s = 0.0
        all_ok = True
        for j in range(d_period):
            v = k[i - d_period + 1 + j]
            if v != v:   # isnan — أسرع من np.isnan في loop
                all_ok = False
                break
            s += v
        if all_ok:
            d[i] = s / d_period

    # ── Vectorized crossover: ta.crossover(K, D) ──────────────────────────────
    # تعريف TV الرسمي: K[i-1] <= D[i-1]  AND  K[i] > D[i]
    prev_k = k[:-1];  curr_k = k[1:]
    prev_d = d[:-1];  curr_d = d[1:]

    valid = ~(np.isnan(prev_k) | np.isnan(prev_d) | np.isnan(curr_k) | np.isnan(curr_d))
    cross = (prev_k <= prev_d) & (curr_k > curr_d) & valid

    return (np.where(cross)[0] + 1).tolist()


def _breakout_signals(df: pd.DataFrame, params: dict) -> list:
    pivot_bars = int(params.get("pivot_bars", 2))
    signals    = []
    highs      = df["high"].to_numpy()
    closes     = df["close"].to_numpy()
    n          = len(df)

    last = None
    for i in range(pivot_bars, n):
        ci = i - pivot_bars
        if ci >= pivot_bars and (ci + pivot_bars) < n:
            if all(highs[ci] > highs[ci - j] for j in range(1, pivot_bars + 1)) and \
               all(highs[ci] > highs[ci + j] for j in range(1, pivot_bars + 1)):
                last = float(highs[ci])
        if last is not None and i > 0:
            if closes[i] > last and closes[i - 1] <= last:
                signals.append(i)
                last = None
    return signals


def compute_stats(trades: list) -> dict:
    wins   = [t for t in trades if t["result"] == "win"]
    losses = [t for t in trades if t["result"] == "loss"]
    opens  = [t for t in trades if t["result"] == "open"]
    total  = len(wins) + len(losses)
    wr     = round(len(wins) / total * 100, 2) if total > 0 else 0
    return {
        "trades": len(trades),
        "wins":   len(wins),
        "losses": len(losses),
        "opens":  len(opens),
        "wr":     wr,
    }
