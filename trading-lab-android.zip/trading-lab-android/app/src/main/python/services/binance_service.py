import requests
import time
import pandas as pd
from config import BINANCE_BASE_URL, BINANCE_KLINES_LIMIT


def fetch_klines_batch(symbol: str, start_ms: int,
                       end_ms: int = None, interval: str = "5m") -> list:
    """Fetch one batch (up to 1000 candles) of klines from Binance.
    interval: "5m" | "15m" | "1h" | "4h" | "1d"
    """
    params = {
        "symbol": symbol.upper(),
        "interval": interval,
        "startTime": start_ms,
        "limit": BINANCE_KLINES_LIMIT,
    }
    if end_ms:
        params["endTime"] = end_ms

    resp = requests.get(f"{BINANCE_BASE_URL}/klines", params=params, timeout=15)
    resp.raise_for_status()
    return resp.json()


def klines_to_df(raw: list) -> pd.DataFrame:
    if not raw:
        return pd.DataFrame()
    df = pd.DataFrame(raw, columns=[
        "timestamp", "open", "high", "low", "close", "volume",
        "close_time", "quote_volume", "trades",
        "taker_buy_base", "taker_buy_quote", "ignore"
    ])
    df = df[["timestamp", "open", "high", "low", "close", "volume"]].copy()
    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = pd.to_numeric(df[col])
    df["timestamp"] = df["timestamp"].astype("int64")
    return df


def resample_to_tf(df_5m: pd.DataFrame, tf: str) -> pd.DataFrame:
    """Resample 5m df to 15m, 1h, 4h, or 1d using timestamp-based alignment.

    Groups candles by their actual timestamp boundary (not positional index),
    so partial leading/trailing groups are correctly aligned to TF boundaries
    regardless of where the 5m data starts.
    """
    interval_ms = {"15m": 15*60*1000, "1h": 60*60*1000,
                   "4h": 4*60*60*1000, "1d": 24*60*60*1000}
    ms = interval_ms.get(tf)
    if ms is None or df_5m.empty:
        return df_5m.copy()

    df = df_5m.copy()
    # Floor each candle's timestamp to the nearest TF boundary
    df["_grp"] = (df["timestamp"] // ms) * ms
    resampled = df.groupby("_grp", sort=True).agg(
        open=("open", "first"),
        high=("high", "max"),
        low=("low", "min"),
        close=("close", "last"),
        volume=("volume", "sum"),
    ).reset_index()
    resampled = resampled.rename(columns={"_grp": "timestamp"})
    return resampled[["timestamp", "open", "high", "low", "close", "volume"]].reset_index(drop=True)


def validate_symbol(symbol: str) -> bool:
    try:
        resp = requests.get(
            f"{BINANCE_BASE_URL}/ticker/price",
            params={"symbol": symbol.upper()},
            timeout=8,
        )
        return resp.status_code == 200
    except Exception:
        return False
