"""
filter_service.py
-----------------
يشغّل جميع مؤشرات الفلتر على (symbol, TF) ويحفظ الشموع النشطة.
الشموع تُحفظ في:
  - DB: جدول filter_results (للتوافق مع analysis_service)
  - ملف JSON: data/{SYMBOL}-{ID}/{SYMBOL}-{ID}-{TF}/{SYMBOL}-{ID}-{TF}-{IndicatorName}.json
"""
import os
import json
import time
import importlib.util

import pandas as pd

from config import INDICATORS_DIR
from db import get_conn, row_to_dict
from storage import (
    get_or_create_currency,
    csv_path,
    save_indicator_json,
    TF_NORM,
)

_BUILTIN_DIR = os.path.join(INDICATORS_DIR, "builtin")


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def compute_filters(symbol: str, tf: str, progress_cb=None) -> dict:
    """
    يشغّل جميع مؤشرات الفلتر على (symbol, tf) ويحفظ النتائج.

    يُعيد:
        { "ok": True, "filters_done": N, "errors": [...] }
    """
    import sys
    tf_lower = tf.lower() if tf else "5m"

    # ── 1. جلب معلومات العملة ──────────────────────────────
    info   = get_or_create_currency(symbol)
    cur_id = info["currency_id"]

    print(f"[FILTER] symbol={symbol} tf={tf_lower} cur_id={cur_id}", file=sys.stderr, flush=True)

    # ── 2. تحميل CSV الفريم ────────────────────────────────
    p = csv_path(symbol, cur_id, tf_lower)
    print(f"[FILTER] CSV path={p}", file=sys.stderr, flush=True)
    print(f"[FILTER] CSV exists={os.path.exists(p)}", file=sys.stderr, flush=True)

    # لو ما لقى الـ CSV، جرب بكل cur_id ممكن في المجلد
    if not os.path.exists(p):
        from storage import find_currency
        alt = find_currency(symbol)
        if alt and alt["currency_id"] != cur_id:
            alt_id = alt["currency_id"]
            alt_p  = csv_path(symbol, alt_id, tf_lower)
            print(f"[FILTER] Trying alt cur_id={alt_id} path={alt_p}", file=sys.stderr, flush=True)
            if os.path.exists(alt_p):
                cur_id = alt_id
                p      = alt_p
                print(f"[FILTER] Found CSV with alt_id!", file=sys.stderr, flush=True)

    if not os.path.exists(p):
        msg = f"لا توجد بيانات {tf_lower} لـ {symbol} — path: {p}"
        print(f"[FILTER] ERROR: {msg}", file=sys.stderr, flush=True)
        return {"ok": False, "error": msg}

    try:
        df = pd.read_csv(p, dtype={"timestamp": "int64"})
    except Exception as e:
        return {"ok": False, "error": f"خطأ قراءة CSV: {e}"}

    if df.empty:
        return {"ok": False, "error": "البيانات فارغة"}

    df_list = _df_to_list(df)

    # استبعاد آخر شمعة — قد تكون ناقصة (لم تكتمل عند إعادة الترقيم أو الجلب)
    # يضمن عدم استخدام إغلاق مؤقت لاتخاذ قرار الفلتر
    if len(df_list) > 1:
        df_list = df_list[:-1]

    # ── 3. جمع مؤشرات الفلتر ─────────────────────────────
    filters = _load_all_filters()
    total   = len(filters)
    if total == 0:
        return {"ok": True, "filters_done": 0, "errors": []}

    errors = []
    done   = 0
    now    = int(time.time() * 1000)

    # ── 4. تشغيل كل فلتر ─────────────────────────────────
    for ind in filters:
        ind_id   = ind["id"]
        ind_name = ind.get("name", ind_id)
        params   = ind.get("params") or {}
        if isinstance(params, str):
            try:
                params = json.loads(params)
            except Exception:
                params = {}

        try:
            mod = _load_module(ind)
            if mod is None or not hasattr(mod, "generate_mask"):
                raise ValueError("generate_mask() مفقودة")

            result = mod.generate_mask(df_list, params)

            if not isinstance(result, list) or len(result) != len(df_list):
                raise ValueError("نتيجة generate_mask() غير صحيحة")

            warmup = _get_module_warmup(mod, params)

            active_candles = []
            for i, val in enumerate(result):
                if i < warmup:
                    continue
                active = None
                if isinstance(val, bool):
                    active = val
                elif isinstance(val, dict):
                    active = val.get("active")
                    if not isinstance(active, bool):
                        active = bool(val.get("value"))
                elif val is not None:
                    try:
                        active = bool(val)
                    except Exception:
                        pass

                if active is True:
                    c = df_list[i]
                    active_candles.append({
                        "ts":     int(c["time"]),
                        "open":   float(c["open"]),
                        "high":   float(c["high"]),
                        "low":    float(c["low"]),
                        "close":  float(c["close"]),
                        "volume": float(c["volume"]),
                    })

            # ── حفظ في DB ────────────────────────────────
            conn = get_conn()
            conn.execute(
                """INSERT INTO filter_results
                       (indicator_id, symbol, tf, computed_at, candle_count, candles_json)
                   VALUES (?, ?, ?, ?, ?, ?)
                   ON CONFLICT(indicator_id, symbol, tf) DO UPDATE SET
                       computed_at  = excluded.computed_at,
                       candle_count = excluded.candle_count,
                       candles_json = excluded.candles_json""",
                (ind_id, symbol.upper(), tf_lower, now,
                 len(active_candles), json.dumps(active_candles))
            )
            conn.commit()
            conn.close()

            # ── حفظ JSON المؤشر في مجلد الفريم ──────────
            save_indicator_json(
                symbol, cur_id, tf_lower,
                ind_name, active_candles
            )

        except Exception as e:
            errors.append({"name": ind_name, "error": str(e)})

        done += 1
        if progress_cb:
            try:
                progress_cb(done, total)
            except Exception:
                pass

    return {
        "ok":            True,
        "filters_done":  done - len(errors),
        "filters_total": total,
        "errors":        errors,
    }


def get_filter_result(indicator_id: str, symbol: str, tf: str) -> dict:
    """يُعيد الشموع النشطة المحفوظة لمؤشر/عملة/فريم."""
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM filter_results WHERE indicator_id=? AND symbol=? AND tf=?",
        (indicator_id, symbol.upper(), tf.lower())
    ).fetchone()
    conn.close()
    if not row:
        return {}
    d = dict(row)
    try:
        d["candles"] = json.loads(d.get("candles_json") or "[]")
    except Exception:
        d["candles"] = []
    return d


# ─────────────────────────────────────────────────────────────────────────────
# Internals
# ─────────────────────────────────────────────────────────────────────────────

def _df_to_list(df: pd.DataFrame) -> list:
    return [
        {
            "time":      int(r["timestamp"]),
            "timestamp": int(r["timestamp"]),
            "open":      float(r["open"]),
            "high":      float(r["high"]),
            "low":       float(r["low"]),
            "close":     float(r["close"]),
            "volume":    float(r["volume"]),
        }
        for r in df.to_dict("records")
    ]


def _get_module_warmup(mod, params: dict) -> int:
    """
    يُحسب أول index صالح في نتيجة generate_mask.

    المؤشر نفسه يُعيد False للشموع قبل الـ warmup — لكن لو أعدنا
    warmup = period + 1 نحذف شمعتين صالحتين (period-1 و period).

    الصحيح: أول قيمة EMA/SMA صالحة = index period-1
    لذا نحذف فقط indices 0 .. period-2 → warmup = period - 1
    """
    base_params  = getattr(mod, "PARAMETERS", {}) or {}
    period_words = ("period", "fast", "slow", "length", "window", "bars")
    values = []
    for k, v in {**base_params, **params}.items():
        if any(w in k.lower() for w in period_words):
            if isinstance(v, (int, float)) and v > 0:
                values.append(int(v))
    return (max(values) + 1) if values else 0


def _load_all_filters() -> list:
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM indicators WHERE type='filter' ORDER BY name"
    ).fetchall()
    conn.close()
    return [row_to_dict(r) for r in rows]


def _load_module(ind: dict):
    ind_id = ind["id"]
    fname  = ind.get("filename", "")

    path = os.path.join(INDICATORS_DIR, fname) if fname else None

    if not path or not os.path.exists(path):
        bname = fname if fname.endswith(".py") else f"{ind_id}.py"
        path  = os.path.join(_BUILTIN_DIR, bname)

    if not path or not os.path.exists(path):
        return None

    try:
        spec = importlib.util.spec_from_file_location(
            f"_fl_{ind_id}_{int(time.time()*1000)}", path
        )
        if spec is None or spec.loader is None:
            return None
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None
