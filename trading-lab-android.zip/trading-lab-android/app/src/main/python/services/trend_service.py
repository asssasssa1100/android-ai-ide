"""
trend_service.py
----------------
يحسب أفضل تركيبات الفلاتر بناءً على نسبة الشموع الصاعدة.
لا يحتاج إلى صفقات — يعمل مباشرةً على filter_results المحفوظة.

الخوارزمية: Hybrid
  Phase 1 — Exhaustive size-1: كل فلتر منفرداً
  Phase 2 — Exhaustive size-2: كل أزواج الفلاتر
  Phase 3 — Greedy:            ابنِ أفضل تركيبة خطوة بخطوة للأحجام الأكبر
"""

import json
import itertools
import csv
import os

import numpy as np

from db import get_conn
from storage import find_currency, csv_path

TF_MS = {
    "1m":  60_000,    "3m":  180_000,   "5m":  300_000,
    "15m": 900_000,   "30m": 1_800_000,  "1h":  3_600_000,
    "2h":  7_200_000, "4h":  14_400_000, "6h":  21_600_000,
    "8h":  28_800_000,"12h": 43_200_000,
    "1d":  86_400_000,"3d":  259_200_000,"1w":  604_800_000,
}

TF_ORDER = ["1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","3d","1w"]


def _load_csv_close_map(symbol: str, tf: str) -> dict:
    """يحمّل ملف CSV ويبني {ts_ms: close}."""
    cur = find_currency(symbol)
    if not cur:
        return {}
    path = csv_path(symbol, cur["currency_id"], tf)
    if not os.path.exists(path):
        return {}
    close_map = {}
    try:
        with open(path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                ts = int(float(row.get("timestamp") or row.get("time") or 0))
                cl = float(row.get("close") or 0)
                if ts and cl:
                    close_map[ts] = cl
    except Exception:
        pass
    return close_map


def _score_trend_combo(masks, n_ref, bullish_ref, min_candles):
    """
    يحسب (agreements, bullish, bullish_pct) لتركيبة.
    يُعيد None إذا لم تكتمل الشرط.
    """
    if len(masks) == 1:
        combined = masks[0].copy()
    elif len(masks) == 2:
        combined = masks[0] & masks[1]
    else:
        combined = np.logical_and.reduce(masks)

    combined[-1] = False   # لا شمعة تالية لآخر شمعة
    agreements   = int(combined.sum())

    if agreements < min_candles:
        return None

    bullish     = int(np.logical_and(combined, bullish_ref).sum())
    bullish_pct = round(bullish / agreements * 100, 2) if agreements > 0 else 0.0
    return agreements, bullish, bullish_pct


def _insert_top_n(results: list, entry: dict, sort_by: str, top_n: int) -> list:
    """يُدرج نتيجة في القائمة المرتّبة ويُعيد أفضل top_n."""
    results.append(entry)
    if sort_by == "agreements":
        results.sort(key=lambda x: x["agreements"], reverse=True)
    else:
        results.sort(key=lambda x: (x["bullish_pct"], x["agreements"]), reverse=True)
    return results[:top_n]


def compute_trend(
    symbol: str,
    allowed_tfs: list = None,
    min_candles: int = 500,
    min_bullish_pct: float = 50.0,
    max_combo_size: int = 3,
    sort_by: str = "bullish_pct",
    top_n: int = 10,
    progress_cb=None,
) -> list:
    """
    يحسب أفضل تركيبات الفلاتر بناءً على نسبة الشموع الصاعدة.

    Returns list of:
      {
        "filters":      [{"indicator_id": ..., "tf": ..., "name": ...}, ...],
        "agreements":   N,
        "bullish":      B,
        "bullish_pct":  pct,
      }
    """
    symbol = symbol.upper()

    # ── 1. حمّل معلومات الفلاتر المتاحة ──────────────────────────────────
    conn = get_conn()
    ind_rows = conn.execute(
        "SELECT id, name FROM indicators WHERE type='filter'"
    ).fetchall()
    ind_map = {r["id"]: r["name"] for r in ind_rows}

    if allowed_tfs:
        tfs_lower    = [t.lower() for t in allowed_tfs]
        placeholders = ",".join("?" * len(tfs_lower))
        fr_rows = conn.execute(
            f"SELECT indicator_id, tf, candles_json FROM filter_results "
            f"WHERE symbol=? AND tf IN ({placeholders}) AND candle_count > 0",
            (symbol, *tfs_lower),
        ).fetchall()
    else:
        fr_rows = conn.execute(
            "SELECT indicator_id, tf, candles_json FROM filter_results "
            "WHERE symbol=? AND candle_count > 0",
            (symbol,),
        ).fetchall()
    conn.close()

    if not fr_rows:
        return []

    # ── 2. استخرج الفلاتر المتاحة وبيانات الشموع النشطة ─────────────────
    available    = []
    active_ts_map = {}

    for row in fr_rows:
        ind_id = row["indicator_id"]
        tf     = row["tf"]
        try:
            candles = json.loads(row["candles_json"] or "[]")
        except Exception:
            candles = []
        if not candles:
            continue
        ts_list = sorted(int(c["ts"]) for c in candles if "ts" in c)
        if not ts_list:
            continue
        key = (ind_id, tf)
        active_ts_map[key] = ts_list
        available.append(key)

    if not available:
        return []

    # ── 3. بناء خريطة السعر المرجعية ──────────────────────────────────────
    avail_tfs = sorted(
        {tf for _, tf in available},
        key=lambda t: TF_ORDER.index(t) if t in TF_ORDER else 99,
    )

    ref_close_map = {}
    ref_tf_ms     = TF_MS.get(avail_tfs[0], 300_000)

    for tf in avail_tfs:
        cm = _load_csv_close_map(symbol, tf)
        if len(cm) > 50:
            ref_close_map = cm
            ref_tf_ms     = TF_MS.get(tf, 300_000)
            break

    if not ref_close_map:
        for key in sorted(available, key=lambda k: TF_ORDER.index(k[1]) if k[1] in TF_ORDER else 99):
            ind_id, tf = key
            conn = get_conn()
            row_csv = conn.execute(
                "SELECT candles_json FROM filter_results WHERE indicator_id=? AND symbol=? AND tf=?",
                (ind_id, symbol, tf),
            ).fetchone()
            conn.close()
            if row_csv:
                try:
                    candles = json.loads(row_csv["candles_json"] or "[]")
                    for c in candles:
                        ts = int(c.get("ts") or c.get("time") or 0)
                        cl = float(c.get("close") or 0)
                        if ts and cl:
                            ref_close_map[ts] = cl
                except Exception:
                    pass
            if len(ref_close_map) > 50:
                ref_tf_ms = TF_MS.get(tf, 300_000)
                break

    if len(ref_close_map) < 2:
        return []

    # ── 4. NumPy arrays للمرجع السعري ─────────────────────────────────────
    ref_ts_arr = np.array(sorted(ref_close_map.keys()), dtype=np.int64)
    ref_cl_arr = np.array([ref_close_map[ts] for ts in ref_ts_arr], dtype=np.float64)
    n_ref      = len(ref_ts_arr)

    bullish_ref         = np.zeros(n_ref, dtype=bool)
    bullish_ref[:-1]    = ref_cl_arr[1:] > ref_cl_arr[:-1]

    # ── 5. بناء filter masks على المرجع السعري ────────────────────────────
    filter_masks = {}

    for key in available:
        ind_id, tf = key
        ts_list    = active_ts_map[key]
        dur        = TF_MS.get(tf, 300_000)
        mask       = np.zeros(n_ref, dtype=bool)
        ts_np      = np.array(ts_list, dtype=np.int64)

        for start_ts in ts_np:
            end_ts   = start_ts + dur
            in_win   = (ref_ts_arr >= start_ts) & (ref_ts_arr < end_ts)
            mask    |= in_win

        filter_masks[key] = mask

    N          = len(available)
    top_results = []

    # ══════════════════════════════════════════════════════════════════════
    # PHASE 1 — Exhaustive size-1
    # ══════════════════════════════════════════════════════════════════════
    for i, key in enumerate(available):
        m   = filter_masks.get(key)
        if m is None:
            continue
        res = _score_trend_combo([m], n_ref, bullish_ref, min_candles)
        if res and res[2] >= min_bullish_pct:
            agreements, bullish, bullish_pct = res
            entry = {
                "filters": [{"indicator_id": key[0], "tf": key[1],
                              "name": ind_map.get(key[0], key[0])}],
                "agreements": agreements, "bullish": bullish, "bullish_pct": bullish_pct,
            }
            top_results = _insert_top_n(top_results, entry, sort_by, top_n)

    if progress_cb:
        try: progress_cb(N / max(N + N*(N-1)//2, 1))
        except Exception: pass

    # ══════════════════════════════════════════════════════════════════════
    # PHASE 2 — Exhaustive size-2
    # ══════════════════════════════════════════════════════════════════════
    pairs   = list(itertools.combinations(range(N), 2))
    total2  = len(pairs)

    for idx, (i, j) in enumerate(pairs):
        k1, k2 = available[i], available[j]
        m1, m2 = filter_masks.get(k1), filter_masks.get(k2)
        if m1 is None or m2 is None:
            continue
        res = _score_trend_combo([m1, m2], n_ref, bullish_ref, min_candles)
        if res and res[2] >= min_bullish_pct:
            agreements, bullish, bullish_pct = res
            entry = {
                "filters": [
                    {"indicator_id": k1[0], "tf": k1[1], "name": ind_map.get(k1[0], k1[0])},
                    {"indicator_id": k2[0], "tf": k2[1], "name": ind_map.get(k2[0], k2[0])},
                ],
                "agreements": agreements, "bullish": bullish, "bullish_pct": bullish_pct,
            }
            top_results = _insert_top_n(top_results, entry, sort_by, top_n)

        if progress_cb and idx % max(1, total2 // 20) == 0:
            try: progress_cb(min((N + idx) / max(N + total2, 1), 0.95))
            except Exception: pass

    if progress_cb:
        try: progress_cb(0.96)
        except Exception: pass

    # ══════════════════════════════════════════════════════════════════════
    # PHASE 3 — Greedy (للأحجام > 2 فقط إذا طلب المستخدم max_combo_size > 2)
    # ══════════════════════════════════════════════════════════════════════
    if max_combo_size > 2 and available:
        # ابدأ من أفضل تركيبة وُجدت حتى الآن
        if top_results:
            best_fs      = top_results[0]["filters"]
            current_keys = [(f["indicator_id"], f["tf"]) for f in best_fs]
        else:
            current_keys = [available[0]]

        used      = set(map(tuple, current_keys))
        remaining = [k for k in available if tuple(k) not in used]

        max_depth = min(max_combo_size - len(current_keys), N - len(current_keys))

        for depth in range(max_depth):
            if not remaining:
                break

            best_score_val = -1.0
            best_key       = None
            best_res       = None

            for key in remaining:
                trial_keys = current_keys + [key]
                masks = [filter_masks.get(tuple(k)) for k in trial_keys]
                if any(m is None for m in masks):
                    continue
                res = _score_trend_combo(masks, n_ref, bullish_ref, min_candles)
                if res:
                    agreements, bullish, bullish_pct = res
                    score_val = bullish_pct if sort_by != "agreements" else agreements
                    if score_val > best_score_val:
                        best_score_val = score_val
                        best_key       = key
                        best_res       = res

            if best_key is None:
                break

            current_keys.append(best_key)
            used.add(tuple(best_key))
            remaining = [k for k in remaining if tuple(k) not in used]

            if best_res and best_res[2] >= min_bullish_pct:
                agreements, bullish, bullish_pct = best_res
                entry = {
                    "filters": [
                        {"indicator_id": k[0], "tf": k[1],
                         "name": ind_map.get(k[0], k[0])}
                        for k in current_keys
                    ],
                    "agreements": agreements, "bullish": bullish, "bullish_pct": bullish_pct,
                }
                top_results = _insert_top_n(top_results, entry, sort_by, top_n)

    if progress_cb:
        try: progress_cb(1.0)
        except Exception: pass

    return top_results
