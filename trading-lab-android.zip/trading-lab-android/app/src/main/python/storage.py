"""
storage.py — نظام التخزين الجديد المنظم
==========================================
كل عملة لها مجلد خاص بها + ID فريد.
البنية:
    data/
    └── BTCUSDT-a1b2c3d4/
        ├── BTCUSDT-a1b2c3d4-5M/
        │   ├── BTCUSDT-a1b2c3d4-5M.csv
        │   ├── BTCUSDT-a1b2c3d4-5M-IndicatorName.json
        │   └── ...
        ├── BTCUSDT-a1b2c3d4-1H/
        │   ├── BTCUSDT-a1b2c3d4-1H.csv
        │   └── ...
        └── BTCUSDT-a1b2c3d4-SIGNAL/
            ├── BTCUSDT-a1b2c3d4-5M-SIGNAL.json
            └── BTCUSDT-a1b2c3d4-1H-SIGNAL.json
"""
import os
import json
import uuid
import re

from config import DATA_DIR

TF_ALL   = ["5M", "15M", "1H", "4H", "1D"]
TF_NORM  = {"5m": "5M", "15m": "15M", "1h": "1H", "4h": "4H", "1d": "1D",
             "5M": "5M", "15M": "15M", "1H": "1H", "4H": "4H", "1D": "1D"}


# ─────────────────────────────────────────────────────────────────────────────
# ID helpers
# ─────────────────────────────────────────────────────────────────────────────

def _new_currency_id() -> str:
    """مثال: a1b2c3d4"""
    return uuid.uuid4().hex[:8]


def _safe_indicator_name(name: str) -> str:
    """تحويل اسم المؤشر لاسم ملف آمن (بدون مسافات أو رموز خاصة)."""
    name = re.sub(r'[^\w\-]', '_', name.strip())
    return name[:40]


# ─────────────────────────────────────────────────────────────────────────────
# مسارات المجلدات
# ─────────────────────────────────────────────────────────────────────────────

def currency_dir(symbol: str, cur_id: str) -> str:
    """المجلد الجذر للعملة: data/BTCUSDT-a1b2c3d4/"""
    return os.path.join(DATA_DIR, f"{symbol.upper()}-{cur_id}")


def tf_dir(symbol: str, cur_id: str, tf: str) -> str:
    """مجلد الفريم: data/BTCUSDT-a1b2c3d4/BTCUSDT-a1b2c3d4-5M/"""
    tf_upper = TF_NORM.get(tf.lower() if tf else "5m", tf.upper())
    base = f"{symbol.upper()}-{cur_id}"
    return os.path.join(currency_dir(symbol, cur_id), f"{base}-{tf_upper}")


def signal_dir(symbol: str, cur_id: str) -> str:
    """مجلد الإشارات: data/BTCUSDT-a1b2c3d4/BTCUSDT-a1b2c3d4-SIGNAL/"""
    base = f"{symbol.upper()}-{cur_id}"
    return os.path.join(currency_dir(symbol, cur_id), f"{base}-SIGNAL")


def csv_path(symbol: str, cur_id: str, tf: str) -> str:
    """مسار CSV الفريم: .../BTCUSDT-a1b2c3d4-5M/BTCUSDT-a1b2c3d4-5M.csv"""
    tf_upper = TF_NORM.get(tf.lower() if tf else "5m", tf.upper())
    base     = f"{symbol.upper()}-{cur_id}"
    return os.path.join(tf_dir(symbol, cur_id, tf), f"{base}-{tf_upper}.csv")


def indicator_json_path(symbol: str, cur_id: str, tf: str, ind_name: str) -> str:
    """مسار JSON المؤشر: .../BTCUSDT-a1b2c3d4-5M/BTCUSDT-a1b2c3d4-5M-RSI.json"""
    tf_upper  = TF_NORM.get(tf.lower() if tf else "5m", tf.upper())
    base      = f"{symbol.upper()}-{cur_id}"
    safe_name = _safe_indicator_name(ind_name)
    return os.path.join(tf_dir(symbol, cur_id, tf), f"{base}-{tf_upper}-{safe_name}.json")


def signal_json_path(symbol: str, cur_id: str, tf: str) -> str:
    """مسار JSON الإشارة: .../SIGNAL/BTCUSDT-a1b2c3d4-5M-SIGNAL.json"""
    tf_upper = TF_NORM.get(tf.lower() if tf else "5m", tf.upper())
    base     = f"{symbol.upper()}-{cur_id}"
    return os.path.join(signal_dir(symbol, cur_id), f"{base}-{tf_upper}-SIGNAL.json")


def ensure_dirs(symbol: str, cur_id: str, tf: str):
    """إنشاء جميع المجلدات اللازمة إن لم تكن موجودة."""
    os.makedirs(tf_dir(symbol, cur_id, tf), exist_ok=True)
    os.makedirs(signal_dir(symbol, cur_id), exist_ok=True)


# ─────────────────────────────────────────────────────────────────────────────
# قراءة/كتابة JSON المؤشر (active candles)
# ─────────────────────────────────────────────────────────────────────────────

def save_indicator_json(symbol: str, cur_id: str, tf: str,
                        ind_name: str, active_candles: list):
    """حفظ الشموع النشطة للمؤشر في ملف JSON."""
    path = indicator_json_path(symbol, cur_id, tf, ind_name)
    ensure_dirs(symbol, cur_id, tf)
    data = {
        "symbol":          symbol.upper(),
        "currency_id":     cur_id,
        "tf":              TF_NORM.get(tf.lower() if tf else "5m", tf.upper()),
        "indicator_name":  ind_name,
        "candle_count":    len(active_candles),
        "active_candles":  active_candles,
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    return path


def load_indicator_json(symbol: str, cur_id: str, tf: str,
                        ind_name: str) -> dict:
    """تحميل بيانات المؤشر المحفوظة. يُعيد {} إن لم يوجد."""
    path = indicator_json_path(symbol, cur_id, tf, ind_name)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def list_indicator_jsons(symbol: str, cur_id: str, tf: str) -> list:
    """قائمة بأسماء المؤشرات المحسوبة لفريم معين."""
    d = tf_dir(symbol, cur_id, tf)
    if not os.path.isdir(d):
        return []
    tf_upper = TF_NORM.get(tf.lower() if tf else "5m", tf.upper())
    base     = f"{symbol.upper()}-{cur_id}-{tf_upper}-"
    results  = []
    for fn in os.listdir(d):
        if fn.endswith(".json") and fn.startswith(base) and not fn.endswith("-SIGNAL.json"):
            ind_name = fn[len(base):-5]
            results.append(ind_name)
    return results


# ─────────────────────────────────────────────────────────────────────────────
# قراءة/كتابة JSON الإشارة (نتائج الاختبار)
# ─────────────────────────────────────────────────────────────────────────────

def save_signal_json(symbol: str, cur_id: str, tf: str,
                     signal_name: str, trades: list, stats: dict):
    """حفظ نتائج اختبار الإشارة."""
    path = signal_json_path(symbol, cur_id, tf)
    ensure_dirs(symbol, cur_id, tf)
    data = {
        "symbol":      symbol.upper(),
        "currency_id": cur_id,
        "tf":          TF_NORM.get(tf.lower() if tf else "5m", tf.upper()),
        "signal_name": signal_name,
        "stats":       stats,
        "trades":      trades,
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    return path


def load_signal_json(symbol: str, cur_id: str, tf: str) -> dict:
    """تحميل نتائج الاختبار المحفوظة."""
    path = signal_json_path(symbol, cur_id, tf)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def list_signal_jsons(symbol: str, cur_id: str) -> list:
    """قائمة بالفريمات التي تم اختبارها (لها SIGNAL.json)."""
    d = signal_dir(symbol, cur_id)
    if not os.path.isdir(d):
        return []
    results = []
    for fn in os.listdir(d):
        if fn.endswith("-SIGNAL.json"):
            # استخرج الفريم من الاسم: BTCUSDT-a1b2c3d4-5M-SIGNAL.json
            base = f"{symbol.upper()}-{cur_id}-"
            if fn.startswith(base):
                tf_part = fn[len(base):-len("-SIGNAL.json")]
                results.append(tf_part)
    return results


# ─────────────────────────────────────────────────────────────────────────────
# اكتشاف العملات من المجلدات
# ─────────────────────────────────────────────────────────────────────────────

def discover_currencies() -> list:
    """
    يقرأ مجلد DATA_DIR ويعيد قائمة بكل العملات.
    كل عملة: { symbol, currency_id, folder, tfs: {...} }
    """
    results = []
    if not os.path.isdir(DATA_DIR):
        return results

    for entry in os.listdir(DATA_DIR):
        full = os.path.join(DATA_DIR, entry)
        if not os.path.isdir(full):
            continue
        # اسم المجلد: BTCUSDT-a1b2c3d4
        parts = entry.split("-", 1)
        if len(parts) != 2:
            continue
        symbol, cur_id = parts[0], parts[1]
        if not symbol.isalpha() or len(cur_id) != 8:
            continue

        tfs_info = {}
        for tf in TF_ALL:
            p = csv_path(symbol, cur_id, tf)
            if os.path.exists(p):
                tfs_info[tf] = {"csv": p}

        results.append({
            "symbol":      symbol,
            "currency_id": cur_id,
            "folder":      full,
            "tfs":         tfs_info,
        })

    return results


def find_currency(symbol: str) -> dict:
    """
    يبحث عن عملة بالرمز ويعيد { symbol, currency_id } أو None.
    إذا وُجد أكثر من مجلد لنفس العملة، يأخذ الأول.
    """
    symbol = symbol.upper()
    if not os.path.isdir(DATA_DIR):
        return None
    for entry in os.listdir(DATA_DIR):
        full = os.path.join(DATA_DIR, entry)
        if not os.path.isdir(full):
            continue
        parts = entry.split("-", 1)
        if len(parts) != 2:
            continue
        sym, cur_id = parts[0], parts[1]
        if sym == symbol and len(cur_id) == 8:
            return {"symbol": symbol, "currency_id": cur_id, "folder": full}
    return None


def get_or_create_currency(symbol: str) -> dict:
    """
    يُعيد بيانات العملة إذا كانت موجودة، أو ينشئ مجلدها بـ ID جديد.
    يُعيد: { symbol, currency_id }
    """
    symbol = symbol.upper()
    existing = find_currency(symbol)
    if existing:
        return existing

    cur_id = _new_currency_id()
    folder = currency_dir(symbol, cur_id)
    os.makedirs(folder, exist_ok=True)
    return {"symbol": symbol, "currency_id": cur_id, "folder": folder}
