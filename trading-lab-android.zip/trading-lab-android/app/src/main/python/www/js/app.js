/* ══════════════════════════════════════════════════════════
   TRADING LAB — app.js
   ══════════════════════════════════════════════════════════ */

/* ─────────────── TF / Theme Constants ─────────────── */
const TF_ALL    = ['5m', '15m', '1h', '4h', '1d'];
const TF_COLORS = { '5m':'#3b82f6','15m':'#8b5cf6','1h':'#10b981','4h':'#f59e0b','1d':'#ef4444' };
const TF_RATIOS = { '5m':1, '15m':3, '1h':12, '4h':48, '1d':288 };
const WARMUP    = 0;

/* ─────────────── App state ─────────────── */
let _tab      = 'data';
let _indTab   = 'filters';

let _currencies   = [];
let _indicators   = { filters: [], signals: [] };
let _tests        = [];
let _analyses     = [];
let _audits       = [];

let _ts = { selSignal: null, selCurs: [], selTf: '5m', selRR: 2 };
let _as = { selTest: null, selSymbol: '', availableData: null, selTop10Tfs: [] };
let _anlPageTab = 0;
let _au = { selSignal: null, selCurs: [], selRR: 2, filters: [] };
let _top10RR = 2;
let _top10MinCoverage = 20;
let _anlSelected = [];
let _top10Detail = null;
let _trendAnalyses = [];
let _trendLoading = false;
let _trendState = { selSymbol: '', selTfs: [], minCandles: 500, minBullishPct: 55, maxComboSize: 3, sortBy: 'bullish_pct' };

/* ─────────── Helpers ─────────── */
function _safeArr(v) {
  if (Array.isArray(v)) return v;
  if (!v) return [];
  try { return JSON.parse(v); } catch(e) { return []; }
}
function _indName(indId) {
  const f = (_indicators.filters || []).find(x => x.id === indId);
  if (f) return f.name;
  const s = (_indicators.signals || []).find(x => x.id === indId);
  return s ? s.name : (indId || '');
}
function _filtersText(filtersJson) {
  const arr = _safeArr(filtersJson);
  if (!arr.length) return '';
  return arr.map(f => `${_indName(f.indicator_id || f.id || '')}@${f.tf || ''}`).join(' · ');
}

/* CurrencySheet state */
let _cs = {
  sym:        null,
  cur:        null,
  tfStates:   {},
  compStates: {},
  activeStrip: null,
};

let _dataPoller = null;

/* ═══════════════════════════════════════════════════════
   BOOT
   ═══════════════════════════════════════════════════════ */
window.addEventListener('DOMContentLoaded', () => {
  /* Wire up static buttons */
  document.getElementById('btn-run-test').onclick    = runTest;
  document.getElementById('btn-fetch-start').onclick = startFetch;
  document.getElementById('btn-import-go').onclick   = doImport;
  document.getElementById('btn-ind-upload').onclick  = uploadIndicator;
  document.getElementById('btn-run-anl').onclick     = runAnalysis;
  document.getElementById('btn-run-top10').onclick   = runTop10;
  document.getElementById('btn-run-audit').onclick   = runAudit;
  document.getElementById('btn-run-trend').onclick  = runTrend;

  switchTab('data');
  startDataPoller();
  loadIndicators();
});

/* ═══════════════════════════════════════════════════════
   TAB SWITCHING
   ═══════════════════════════════════════════════════════ */
function switchTab(tab) {
  _tab = tab;
  const isNavy = (tab === 'data' || tab === 'indicators');

  /* Headers */
  document.getElementById('header-navy').style.display  = isNavy ? 'flex' : 'none';
  document.getElementById('header-black').style.display = isNavy ? 'none' : 'flex';

  /* Navy header buttons */
  if (isNavy) {
    const lbl      = document.getElementById('hd-label');
    const btnAdd   = document.getElementById('btn-hd-add');
    const btnImport= document.getElementById('btn-hd-import');
    const btnTmpl  = document.getElementById('btn-hd-template');

    const iconEl = document.getElementById('hd-label-icon');
    if (tab === 'data') {
      lbl.textContent           = 'البيانات';
      if (iconEl) iconEl.textContent = '📊';
      btnImport.style.display   = 'flex';
      btnTmpl.style.display     = 'none';
      btnAdd.onclick   = () => openSheet('sheet-fetch');
      btnImport.onclick= () => openSheet('sheet-import');
    } else {
      lbl.textContent           = 'المؤشرات';
      if (iconEl) iconEl.textContent = '🔧';
      btnImport.style.display   = 'none';
      btnTmpl.style.display     = 'flex';
      btnTmpl.onclick  = () => openTemplateSheet();
      btnAdd.onclick   = () => openSheet('sheet-indicator');
    }
  }

  /* Black header */
  if (!isNavy) {
    const titles = { test:'الاختبار 🖊️', analysis:'التحليل 📈', audit:'التدقيق 🛡️' };
    document.getElementById('hb-title').innerHTML = titles[tab] || '';
    document.getElementById('btn-hb-add').onclick = () => openAddSheet(tab);
  }

  /* Indicator tabs bar */
  document.getElementById('ind-tabs-bar').style.display = (tab === 'indicators') ? 'flex' : 'none';

  /* Nav tab colors */
  ['data','indicators','test','analysis','audit'].forEach(t => {
    const btn = document.getElementById('ntab-' + t);
    const act = (t === tab);
    btn.style.color = act ? '#22d3a5' : '#2a3040';
    btn.querySelector('.nav-tab-label').style.fontWeight = act ? '700' : '500';
  });

  /* امسح المحتوى القديم فوراً ثم حمّل البيانات الجديدة */
  const el = document.getElementById('page-content');
  if (tab === 'test') {
    loadTests();
  } else if (tab === 'analysis') {
    /* إظهار حالة فارغة فورية ريثما تُحمَّل البيانات */
    _analyses = [];
    el.innerHTML = `<div class="empty-state">
      <div class="empty-icon">📈</div>
      <div class="empty-text">جارٍ التحميل...</div>
    </div>`;
    loadAnalyses();
  } else if (tab === 'audit') {
    _audits = [];
    el.innerHTML = `<div class="empty-state">
      <div class="empty-icon">🛡️</div>
      <div class="empty-text">جارٍ التحميل...</div>
    </div>`;
    loadAudits();
  } else {
    ({ data: renderData, indicators: renderIndicators })[tab]?.();
  }
}

/* ═══════════════════════════════════════════════════════
   DATA PAGE
   ═══════════════════════════════════════════════════════ */
function startDataPoller() {
  loadCurrencies();
  _dataPoller = setInterval(() => {
    if (_tab === 'data' || _cs.sym) loadCurrencies();
  }, 4000);
}

async function loadCurrencies() {
  try {
    const r = await fetch('/api/data/currencies');
    const d = await r.json();
    _currencies = Array.isArray(d) ? d : (d.currencies || []);
    if (_tab === 'data') renderData();
    /* Refresh open CurrencySheet */
    if (_cs.sym) {
      const found = _currencies.find(c => c.symbol === _cs.sym);
      if (found) { _cs.cur = found; refreshCsRows(); }
    }
  } catch(e) {}
}

function renderData() {
  const el = document.getElementById('page-content');
  if (!_currencies.length) {
    el.innerHTML = `<div class="empty-state">
      <div class="empty-icon">📊</div>
      <div class="empty-text">لا توجد بيانات بعد</div>
      <div class="empty-hint">اضغط + لجلب 5m من Binance<br>أو 📁 لاستيراد CSV</div>
    </div>`;
    return;
  }
  el.innerHTML = _currencies.map(buildDataCard).join('');
}

function buildDataCard(cur) {
  const sym  = cur.symbol;
  const cnt  = cur.candles ? cur.candles.toLocaleString() : '0';
  const from = fmtDate(cur.first_ts);
  const to   = fmtDate(cur.last_ts);

  /* Fetching state */
  if (cur.fetching) {
    const pct = Math.round((cur.fetch_pct || 0) * 100);
    return `<div class="data-card-fetching">
      <div class="data-card-top">
        <div>
          <div class="data-card-symbol">${sym}</div>
          <div class="data-card-date">جاري الجلب... ${pct}%</div>
        </div>
        <div class="data-card-count">
          <span class="data-card-count-num">${cnt}</span> شمعة
        </div>
      </div>
      <div class="prog-wrap"><div class="prog-fill" style="width:${pct}%"></div></div>
      <div style="display:flex;gap:8px">
        <button class="btn-data-stop"
          onclick="event.stopPropagation();stopFetch('${sym}')">⏹ إيقاف</button>
      </div>
    </div>`;
  }

  /* TF chips — 5m base + any computed TFs that have candles */
  const tfList = [];
  if (cur.candles > 0) tfList.push('5m');
  if (cur.tfs) {
    ['15m', '1h', '4h', '1d'].forEach(tf => {
      if (cur.tfs[tf] && (cur.tfs[tf].candles || 0) > 0) tfList.push(tf);
    });
  }
  const chips = tfList.map(tf =>
    `<span class="tf-chip tf-${tf}">${tf}</span>`
  ).join('') || '<span style="font-size:11px;color:#4a5568">—</span>';

  /* شريط تقدم الفلاتر — دوائر SVG صغيرة */
  const filterBar = TF_ALL.map(tf => {
    const tfD     = cur.tfs && cur.tfs[tf];
    const hasData = tfD && (tfD.candles || 0) > 0;
    const col     = TF_COLORS[tf] || '#3b82f6';
    const R = 10, C = +(2 * Math.PI * R).toFixed(1); // 62.8
    if (!hasData) {
      return `<svg width="28" height="28" viewBox="0 0 28 28" style="flex-shrink:0">
        <circle cx="14" cy="14" r="${R}" fill="none" stroke="#1e2130" stroke-width="2.5"/>
        <text x="14" y="18" text-anchor="middle" fill="#374151"
          font-size="6" font-weight="700" font-family="sans-serif">${tf}</text>
      </svg>`;
    }
    const tested  = tfD.filters_tested || 0;
    const total   = tfD.filters_total  || 0;
    const pct     = total > 0 ? Math.round(tested / total * 100) : 0;
    const isDone  = total > 0 && tested >= total;
    const ringCol = isDone ? '#22c55e' : tested > 0 ? '#f59e0b' : col;
    const arcSvg  = pct > 0
      ? `<circle cx="14" cy="14" r="${R}" fill="none" stroke="${ringCol}" stroke-width="2.5"
           stroke-dasharray="${C}" stroke-dashoffset="${+(C*(1-pct/100)).toFixed(1)}"
           stroke-linecap="round" transform="rotate(-90 14 14)"/>`
      : '';
    return `<svg width="28" height="28" viewBox="0 0 28 28" style="flex-shrink:0">
      <circle cx="14" cy="14" r="${R}" fill="none" stroke="#2a2d3a" stroke-width="2.5"/>
      ${arcSvg}
      <text x="14" y="18" text-anchor="middle" fill="${isDone ? '#4ade80' : col}"
        font-size="6" font-weight="700" font-family="sans-serif">${tf}</text>
    </svg>`;
  }).join('');

  return `<div class="data-card" onclick="openCurrencySheet('${sym}')">
    <div class="data-card-top">
      <div>
        <div class="data-card-symbol">${sym}</div>
        <div class="data-card-date">${from} — ${to}</div>
      </div>
      <div class="data-card-count">
        <span class="data-card-count-num">${cnt}</span> شمعة
      </div>
    </div>
    <div class="data-card-tfs">${chips}</div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin:6px 0 4px;padding:6px 2px 2px;border-top:1px solid #1e2130">
      <span style="font-size:9px;color:#4a5568">فلاتر</span>
      <div style="display:flex;gap:6px">${filterBar}</div>
    </div>
    <div class="data-card-btns">
      <button class="btn-data-update"
        onclick="event.stopPropagation();quickUpdate('${sym}')">تحديث</button>
      <button class="btn-data-export"
        onclick="event.stopPropagation();exportCur('${sym}')">تصدير CSV</button>
      <button class="btn-data-delete"
        onclick="event.stopPropagation();deleteCur('${sym}')">حذف</button>
    </div>
  </div>`;
}

function quickUpdate(sym) {
  fetch(`/api/data/currencies/${sym}/update`, { method: 'POST' })
    .then(() => { showToast('⬆️ يتم التحديث...'); loadCurrencies(); })
    .catch(() => showToast('❌ خطأ في التحديث'));
}

function exportCur(sym) {
  window.location.href = `/api/data/currencies/${sym}/export`;
}

function exportTestJson(testId) {
  window.location.href = `/api/test/${testId}/export`;
}

function exportAnalysisJson(anlId) {
  window.location.href = `/api/analysis/${anlId}/export`;
}

function deleteCur(sym) {
  if (!confirm(`حذف ${sym}؟`)) return;
  fetch(`/api/data/currencies/${sym}`, { method: 'DELETE' })
    .then(r => r.json())
    .then(d => {
      if (d.ok) { showToast('🗑️ تم الحذف'); loadCurrencies(); }
      else showToast('❌ ' + (d.error || 'خطأ'));
    });
}

function stopFetch(sym) {
  fetch(`/api/data/fetch/${sym}/stop`, { method: 'POST' })
    .then(() => { showToast('⏹ توقف الجلب'); loadCurrencies(); });
}

/* ═══════════════════════════════════════════════════════
   CURRENCY SHEET
   ═══════════════════════════════════════════════════════ */
function openCurrencySheet(sym) {
  const cur = _currencies.find(c => c.symbol === sym);
  if (!cur) return;
  _cs = { sym, cur, tfStates: {}, compStates: {}, activeStrip: null };

  /* Header */
  document.getElementById('cs-symbol').textContent = sym;
  const base5m = cur.candles ? cur.candles.toLocaleString() : '0';
  document.getElementById('cs-base-info').innerHTML =
    `فريم أساسي: <span style="color:#3b82f6;font-weight:600">5m</span>
     · <span style="color:#60a5fa">${base5m} شمعة</span>`;

  /* Seed tfStates from real backend data: 'done' if cached, else 'idle' */
  const tfs = cur.tfs || {};
  TF_ALL.forEach(tf => {
    if (tf === '5m') return;
    if ((tfs[tf] && tfs[tf].candles > 0)) _cs.tfStates[tf] = 'done';
  });

  refreshCsRows();
  refreshCsStrip();
  document.getElementById('cs-overlay').classList.remove('hidden');
}

function closeCurrencySheet() {
  document.getElementById('cs-overlay').classList.add('hidden');
  _cs = { sym: null, cur: null, tfStates: {}, compStates: {}, activeStrip: null };
}

function refreshCsRows() {
  const cur = _cs.cur;
  if (!cur) return;
  document.getElementById('cs-tf-rows').innerHTML =
    TF_ALL.map(tf => buildCsTfRow(tf, cur)).join('');
}

function buildCsTfRow(tf, cur) {
  const col     = TF_COLORS[tf];
  const state   = _cs.tfStates[tf] || 'idle';
  const isBase  = (tf === '5m');
  const tfData  = (cur.tfs && cur.tfs[tf]) || { candles: 0 };
  const hasData = tfData.candles > 0;
  const avail   = isBase ? (cur.candles > 0) : hasData;

  /* Row colours */
  const rowBg   = avail ? '#12151f' : '#0d0f18';
  const rowBord = avail ? `${col}33` : '#2a2d3a';

  /* Chip */
  const chipBg  = avail ? col+'22' : '#2a2d3a';
  const chipCol = avail ? col      : '#4a5568';
  const chipBrd = avail ? col+'55' : '#3a3d4a';
  const baseTag = isBase ? `<div style="font-size:8px;color:${col};margin-top:1px">أساسي</div>` : '';

  /* Info */
  let infoHtml = '';
  if (avail) {
    const cnt  = (isBase ? cur.candles : tfData.candles).toLocaleString();
    const fts  = isBase ? cur.first_ts : tfData.first_ts;
    const lts  = isBase ? cur.last_ts  : tfData.last_ts;
    const from = fmtDate(fts);
    const to   = fmtDate(lts);
    infoHtml = `<div style="font-size:13px;color:#e2e8f0;font-weight:600">${cnt}
        <span style="color:#64748b;font-weight:400">شمعة</span></div>
      <div style="font-size:11px;color:#64748b;margin-top:1px">${from} — ${to}</div>`;
  } else if (state === 'fetching') {
    infoHtml = `<div style="font-size:12px;color:#f59e0b">⏳ جاري الجلب...</div>`;
  } else {
    const autoCount = cur.candles
      ? Math.round(cur.candles / TF_RATIOS[tf]) : null;
    const hint = autoCount
      ? `<div style="font-size:10px;color:#475569;margin-top:2px">سيُجلب تلقائياً: <span style="color:${col}">${autoCount.toLocaleString()} شمعة</span></div>` : '';
    infoHtml = `<div style="font-size:12px;color:#4a5568">لا توجد بيانات</div>${hint}`;
  }

  /* Button */
  let btn = '';
  if (state === 'fetching') {
    btn = `<button class="btn-cs-stop" onclick="csTfStop('${tf}')">إيقاف</button>`;
  } else if (avail) {
    btn = `<button class="btn-cs-update" onclick="csTfUpdate('${tf}')">تحديث</button>`;
  } else {
    btn = `<button class="btn-cs-fetch" onclick="csTfFetch('${tf}')">جلب تلقائي</button>`;
  }

  return `<div style="background:${rowBg};border-radius:12px;padding:10px 14px;
    border:1px solid ${rowBord};display:flex;align-items:center;gap:10px">
    <div style="background:${chipBg};color:${chipCol};border:1px solid ${chipBrd};
      border-radius:8px;padding:4px 10px;font-size:13px;font-weight:700;
      min-width:42px;text-align:center;flex-shrink:0">
      ${tf}${baseTag}
    </div>
    <div style="flex:1">${infoHtml}</div>
    ${btn}
  </div>`;
}

/* ─── مساعد: دائرة SVG للشريط الكبير (52px) ─── */
function _makeTfRingSvg(tf, avail, isRun, isDoneFull, isErr, pct, computed, filtersN) {
  const col = TF_COLORS[tf] || '#3b82f6';
  const R   = 20;                        // نصف القطر — أصغر قليلاً ليترك هامشاً للـ stroke
  const C   = 2 * Math.PI * R;          // المحيط الدقيق (بدون تقريب) ≈ 125.664
  const SW  = 3.5;                       // سُمك الخط

  const trackCol = avail ? '#2a2d3a' : '#1e2130';
  const ringCol  = isDoneFull ? '#22c55e' : isErr ? '#ef4444' : col;
  const tfCol    = avail ? col : '#374151';
  const subCol   = isDoneFull ? '#4ade80' : isErr ? '#ef4444' : isRun ? col : '#64748b';

  const subTxt = isDoneFull ? `${computed}/${filtersN}`
               : isErr      ? '✗'
               : isRun      ? `${pct}%`
               : (pct > 0)  ? `${pct}%`
               : avail      ? '—' : '—';

  let arcSvg = '';
  if (avail && isRun) {
    const arcLen = C * 0.28;
    const gap    = C - arcLen;
    arcSvg = `<circle class="ring-spin" cx="26" cy="26" r="${R}" fill="none"
      stroke="${col}" stroke-width="${SW}"
      stroke-dasharray="${arcLen} ${gap}"
      stroke-linecap="round"/>`;
  } else if (avail && pct > 0) {
    const offset = C * (1 - pct / 100);
    arcSvg = `<circle cx="26" cy="26" r="${R}" fill="none"
      stroke="${ringCol}" stroke-width="${SW}"
      stroke-dasharray="${C} ${C}"
      stroke-dashoffset="${offset}"
      stroke-linecap="round" transform="rotate(-90 26 26)"
      style="transition:stroke-dashoffset .5s ease"/>`;
  }

  /* viewBox يبدأ من -4 ليعطي هامش SW/2 + مسافة إضافية للـ stroke حول الدائرة */
  return `<svg width="52" height="52" viewBox="-4 -4 60 60">
    <circle cx="26" cy="26" r="${R}" fill="none" stroke="${trackCol}" stroke-width="${SW}"/>
    ${arcSvg}
    <text x="26" y="23" text-anchor="middle" dominant-baseline="middle" fill="${tfCol}"
      font-size="11" font-weight="700" font-family="sans-serif">${tf}</text>
    <text x="26" y="34" text-anchor="middle" dominant-baseline="middle" fill="${subCol}"
      font-size="8" font-family="sans-serif">${subTxt}</text>
  </svg>`;
}

function refreshCsStrip() {
  const cur = _cs.cur;
  document.getElementById('cs-strip-frames').innerHTML = TF_ALL.map(tf => {
    const avail  = tf === '5m' ? (cur && cur.candles > 0) : (_cs.tfStates[tf] === 'done');
    const cState = _cs.compStates[tf] || 'idle';
    const isRun  = cState === 'running';
    const isErr  = cState === 'error';

    const tfData    = (cur && cur.tfs && cur.tfs[tf]) || {};
    const srvTested = tfData.filters_tested || 0;
    const srvTotal  = tfData.filters_total  || _indicators.filters.length;
    const filtersN  = _indicators.filters.length || srvTotal || 0;

    // التقدم الحقيقي من السيرفر (polling)
    const livePct   = (_cs.filterProgress && _cs.filterProgress[tf]) || 0;
    const isDoneFull = (cState === 'done') || (srvTested > 0 && srvTested >= filtersN && filtersN > 0 && !isRun);
    const computed   = isDoneFull ? (cState === 'done' ? filtersN : srvTested) : srvTested;
    const pct        = isRun
      ? livePct
      : (filtersN > 0 ? Math.round((computed / filtersN) * 100) : 0);

    const svg = _makeTfRingSvg(tf, avail, isRun, isDoneFull, isErr, pct, computed, filtersN);

    if (!avail) return `<div class="cs-frame-btn dimmed">${svg}</div>`;

    return `<button class="cs-frame-btn" onclick="csCompute('${tf}')">${svg}</button>`;
  }).join('');
}

async function csTfFetch(tf) {
  if (!_cs.sym) return;
  if (tf === '5m') return; /* 5m is fetched from Binance via main + button */

  _cs.tfStates[tf] = 'fetching';
  refreshCsRows();
  showToast('🔄 جاري حساب ' + tf + '...');

  try {
    const r = await fetch(
      `/api/data/currencies/${_cs.sym}/tf/${tf}/compute`,
      { method: 'POST' }
    );
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'فشل');

    /* Update local cur.tfs with real numbers */
    _cs.cur.tfs = _cs.cur.tfs || {};
    _cs.cur.tfs[tf] = {
      candles:  d.candles,
      first_ts: d.first_ts,
      last_ts:  d.last_ts,
    };
    _cs.tfStates[tf] = 'done';
    refreshCsRows();
    refreshCsStrip();
    showToast('✅ تم إعداد ' + tf + ' (' + d.candles.toLocaleString() + ' شمعة)');
    loadCurrencies();
  } catch (e) {
    _cs.tfStates[tf] = 'idle';
    refreshCsRows();
    showToast('❌ ' + (e.message || 'خطأ'));
  }
}

async function csTfStop(tf) {
  if (tf === '5m' && _cs.sym) {
    await fetch(`/api/data/fetch/${_cs.sym}/stop`, { method: 'POST' });
    showToast('⏹ توقف جلب ' + _cs.sym);
    loadCurrencies();
    return;
  }
  /* Resampling is synchronous on the server — stopping is just UI revert */
  _cs.tfStates[tf] = 'idle';
  refreshCsRows();
  showToast('⏹ توقف ' + tf);
}

async function csTfUpdate(tf) {
  if (!_cs.sym) return;

  /* 5m → continue Binance fetch from last_ts */
  if (tf === '5m') {
    quickUpdate(_cs.sym);
    return;
  }

  /* Non-5m → re-resample from current 5m data */
  _cs.tfStates[tf] = 'fetching';
  refreshCsRows();
  showToast('⬆️ تحديث ' + tf + '...');

  try {
    const r = await fetch(
      `/api/data/currencies/${_cs.sym}/tf/${tf}/compute`,
      { method: 'POST' }
    );
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'فشل');

    _cs.cur.tfs = _cs.cur.tfs || {};
    _cs.cur.tfs[tf] = {
      candles:  d.candles,
      first_ts: d.first_ts,
      last_ts:  d.last_ts,
    };
    _cs.tfStates[tf] = 'done';
    refreshCsRows();
    showToast('✅ تم تحديث ' + tf);
    loadCurrencies();
  } catch (e) {
    _cs.tfStates[tf] = 'done'; /* keep showing prior data */
    refreshCsRows();
    showToast('❌ ' + (e.message || 'خطأ'));
  }
}

/* Polling interval handle للتقدم الحقيقي */
let _filterPollTimer = null;

function _stopFilterPoll() {
  if (_filterPollTimer) { clearInterval(_filterPollTimer); _filterPollTimer = null; }
}

async function csCompute(tf) {
  if (!_cs.sym) return;
  if (!_indicators.filters.length) {
    showToast('⚠️ لا توجد مؤشرات فلاتر — ارفع مؤشراً أولاً');
    return;
  }

  const avail = tf === '5m' ? (_cs.cur && _cs.cur.candles > 0) : (_cs.tfStates[tf] === 'done');
  if (!avail) {
    showToast('⚠️ حمّل بيانات ' + tf + ' أولاً');
    return;
  }

  _cs.activeStrip    = tf;
  _cs.compStates[tf] = 'running';
  if (!_cs.filterProgress) _cs.filterProgress = {};
  _cs.filterProgress[tf] = 0;
  refreshCsStrip();
  showToast('🔄 حساب الفلاتر على ' + tf + '...');

  // ١. أرسل طلب البدء (يرجع فوراً)
  try {
    const r = await fetch(
      `/api/data/currencies/${_cs.sym}/filters/${tf}/compute`,
      { method: 'POST' }
    );
    const d = await r.json();
    if (!r.ok || !d.ok) throw new Error(d.error || 'فشل البدء');
  } catch (e) {
    _cs.compStates[tf] = 'error';
    refreshCsStrip();
    showToast('❌ ' + (e.message || 'خطأ في البدء'));
    return;
  }

  // ٢. ابدأ polling كل 1.5 ثانية حتى ينتهي الحساب
  const sym = _cs.sym;
  _stopFilterPoll();
  _filterPollTimer = setInterval(async () => {
    try {
      const r2 = await fetch(`/api/data/currencies/${sym}/filters/${tf}/status`);
      if (!r2.ok) return;
      const s = await r2.json();

      // تحديث progress bar
      if (_cs.filterProgress) _cs.filterProgress[tf] = s.pct || 0;
      if (_cs.sym === sym) refreshCsStrip();

      if (s.status === 'done') {
        _stopFilterPoll();
        _cs.compStates[tf] = (s.filters_done > 0) ? 'done' : 'error';
        if (_cs.filterProgress) _cs.filterProgress[tf] = 100;
        if (_cs.cur) {
          _cs.cur.tfs = _cs.cur.tfs || {};
          _cs.cur.tfs[tf] = _cs.cur.tfs[tf] || {};
          _cs.cur.tfs[tf].filters_tested = s.filters_done || 0;
          _cs.cur.tfs[tf].filters_total  = s.total_filters || 0;
        }
        refreshCsStrip();
        loadCurrencies();
        const errs   = s.errors || [];
        const errTxt = errs.length ? ` (${errs.length} تحذير)` : '';
        const done2  = s.filters_done || 0;
        const total  = s.total_filters || 0;
        if (done2 === 0 && total > 0) {
          showToast(`⚠️ ${tf}: 0/${total} — ${errs[0]?.error || 'لم يُنفَّذ أي فلتر'}`);
        } else {
          showToast(`✅ ${tf}: ${done2}/${total} فلتر تم حسابه${errTxt}`);
        }
      } else if (s.status === 'error') {
        _stopFilterPoll();
        _cs.compStates[tf] = 'error';
        refreshCsStrip();
        showToast('❌ خطأ في الحساب: ' + (s.error || ''));
      }
    } catch (_) {}
  }, 1500);
}

/* اختصار: اذهب لصفحة البيانات وافتح شاشة الفلاتر للعملة مباشرة */
function goComputeFiltersFor(sym) {
  closeSheet('sheet-analysis');
  switchTab('data');
  /* انتظر تحميل الكروت ثم افتح شاشة العملة */
  setTimeout(() => {
    const cur = _currencies.find(c => c.symbol === sym);
    if (cur) {
      openCurrencySheet(sym);
      showToast('💡 اضغط على فريم زمني في الشريط السفلي لحساب فلاتره');
    } else {
      showToast('⚠️ لم يُعثر على العملة ' + sym + ' — أضفها أولاً');
    }
  }, 350);
}

/* ═══════════════════════════════════════════════════════
   INDICATORS PAGE
   ═══════════════════════════════════════════════════════ */
const FILTER_TEMPLATE = `# ═══════════════════════════════════════════════════════════
# قالب مؤشر فلتر — Trading Lab
# ═══════════════════════════════════════════════════════════
INDICATOR_NAME    = "اسم الفلتر"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "filter"
PARAMETERS        = {"period": 20}

import numpy as np

def generate_mask(df, params=None):
    """
    df     : list[dict]  {time, open, high, low, close, volume}
    params : dict | None

    يُعيد  : list — نفس طول df — كل عنصر:
      None  → warmup (قبل أول قيمة صالحة)
      dict  → {"active": bool, "اسم_القيمة": float, ...}

    الـ dict يؤدي غرضين في آنٍ واحد:
      • "active" (True/False) → تُستخدم في صفحة البيانات لفلترة الإشارات
      • باقي الأرقام → تظهر قيمتها في شاشة التحقق لايف لكل شمعة
    """
    p      = params or PARAMETERS
    period = int(p.get("period", 20))
    n      = len(df)
    result = [None] * n

    closes = np.array([r["close"] for r in df], dtype=float)

    for i in range(period - 1, n):
        # ─── احسب قيمة مؤشرك هنا ─────────────────────────────
        val = closes[i - period + 1 : i + 1].mean()   # مثال: SMA

        result[i] = {
            "active": bool(closes[i] > val),  # ← شرطك: True = مفعّل / False = موقف
            "sma":    round(float(val), 4),   # ← قيمة المؤشر (غيّر الاسم لما تريد)
        }

    return result`;

const SIGNAL_TEMPLATE = `# ═══════════════════════════════════════════════════════════
# قالب مؤشر إشارة — Trading Lab
# ═══════════════════════════════════════════════════════════
INDICATOR_NAME    = "اسم الإشارة"
INDICATOR_VERSION = "1.0.0"
INDICATOR_TYPE    = "signal"
PARAMETERS        = {"period": 14}

import numpy as np

def generate_signals(df, params=None):
    """
    df     : list[dict]  {time, open, high, low, close, volume}
    params : dict | None

    يُعيد  : list[dict] — كل dict يمثل نقطة دخول واحدة:
      {
        "time":   df[i]["time"],   # وقت الشمعة بالمللي-ثانية  ← مطلوب
        "price":  float,           # سعر الدخول                ← اختياري
        "reason": "نص",            # يظهر في بطاقة التحقق لايف ← اختياري
        "قيمتك":  float,           # أي قيمة رقمية إضافية       ← اختياري
      }

    الـ dict يؤدي غرضين في آنٍ واحد:
      • "time"  → تُستخدم في صفحة البيانات لاختبار الأداء
      • باقي الحقول → تظهر في شاشة التحقق لايف لكل إشارة
    """
    p      = params or PARAMETERS
    period = int(p.get("period", 14))
    n      = len(df)

    closes  = np.array([r["close"] for r in df], dtype=float)
    signals = []

    for i in range(period, n):
        # ─── منطق الإشارة هنا ─────────────────────────────────
        prev = closes[i - period : i].mean()
        curr = closes[i]

        if curr > prev * 1.001:   # ← شرطك هنا
            signals.append({
                "time":   df[i]["time"],
                "price":  float(curr),
                "reason": f"breakout {round(curr, 1)}",
            })

    return signals`;

async function loadIndicators() {
  try {
    const r = await fetch('/api/indicators/');
    const d = await r.json();
    const arr = Array.isArray(d) ? d : (d.indicators || []);
    // Normalize: backend column is `params_json` (auto-parsed by row_to_dict)
    arr.forEach(i => { i.params = i.params || i.params_json || {}; });
    _indicators.filters = arr.filter(i => i.type === 'filter');
    _indicators.signals = arr.filter(i => i.type === 'signal');
    if (_tab === 'indicators') renderIndicatorsList();
  } catch(e) {}
}

/**
 * Entry point used by the bottom-nav tab switcher: fetch fresh data, then
 * render. This is the only path that triggers a network call so that
 * `setIndTab` (in-page tab toggle) and other sub-actions can call the pure
 * `renderIndicatorsList` without re-fetching.
 */
function renderIndicators() {
  loadIndicators();           // async — will call renderIndicatorsList() when done
  renderIndicatorsList();     // immediate paint with whatever's in cache
}

function renderIndicatorsList() {
  const list = _indTab === 'filters' ? _indicators.filters : _indicators.signals;

  const fEl = document.getElementById('ic-filters');
  const sEl = document.getElementById('ic-signals');
  if (fEl) fEl.textContent = _indicators.filters.length;
  if (sEl) sEl.textContent = _indicators.signals.length;

  ['filters','signals'].forEach(t => {
    const btn = document.getElementById('itab-'+t);
    const cnt = document.getElementById('ic-'+t);
    if (!btn) return;
    const act = (t === _indTab);
    btn.classList.toggle('active', act);
    if (cnt) cnt.classList.toggle('active', act);
  });

  const el = document.getElementById('page-content');

  const infoBanner = _indTab === 'filters'
    ? `<div class="ind-info-banner">🔍 مؤشرات الفلاتر تحدد حالة <strong style="color:#e8edf3">نشط / غير نشط</strong> لكل شمعة — تُستخدم في قسم التحليل لتصفية إشارات الدخول</div>`
    : `<div class="ind-info-banner">📍 مؤشرات الإشارة تعطي <strong style="color:#e8edf3">نقطة دخول صريحة</strong> — تُستخدم في قسم الاختبار لقياس الأداء</div>`;

  if (!list.length) {
    el.innerHTML = infoBanner + `<div class="empty-state">
      <div class="empty-icon">${_indTab === 'filters' ? '🔍' : '📍'}</div>
      <div class="empty-text">لا يوجد ${_indTab === 'filters' ? 'فلاتر' : 'إشارات'} بعد</div>
      <div class="empty-hint">اضغط + لرفع مؤشر جديد</div>
    </div>`;
    return;
  }

  el.innerHTML = infoBanner + list.map(ind => {
    const isFilter = ind.type === 'filter';
    const iconClass = isFilter ? 'filter-type' : 'signal-type';
    const icon      = isFilter ? '🔍' : '📍';
    const params    = Object.entries(ind.params || {}).map(([k,v]) => `${k}=${v}`).join(' · ');
    return `<div class="ind-card">
      <div class="ind-card-row">
        <div class="ind-icon-circle ${iconClass}">${icon}</div>
        <div class="ind-card-content">
          <div class="ind-name-row">
            <span class="ind-name">${escapeHtml(ind.name)}</span>
            <span class="ind-builtin-badge">مخصص</span>
          </div>
          <div class="ind-sub">v${escapeHtml(ind.version || '1.0.0')}${params ? ' · ' + escapeHtml(params) : ''}</div>
        </div>
      </div>
      <div class="ind-card-btns">
        <button class="btn-ind-verify" onclick="verifyIndicator('${ind.id}')">
          <span>🔍</span><span>تحقق لايف</span>
        </button>
        <button class="btn-ind-copy" onclick="copyTemplate('${ind.type}')">
          <span>📋</span><span>نسخ قالب</span>
        </button>
        <button class="btn-ind-delete" onclick="deleteIndicator('${ind.id}','${escapeHtml(ind.name)}')">حذف</button>
      </div>
    </div>`;
  }).join('');
}

function setIndTab(tab) {
  _indTab = tab;
  renderIndicatorsList();   // no fetch — just re-paint with current cache
}

function openTemplateSheet() {
  const isFilter = _indTab === 'filters';
  document.getElementById('template-sh-title').textContent =
    `📋 قالب ${isFilter ? 'الفلتر' : 'الإشارة'} — المنطق الجديد`;
  document.getElementById('template-code').textContent =
    isFilter ? FILTER_TEMPLATE : SIGNAL_TEMPLATE;
  openSheet('sheet-template');
}

function copyTemplate(type) {
  const code = type === 'filter' ? FILTER_TEMPLATE : SIGNAL_TEMPLATE;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(code)
      .then(() => showToast('✅ تم نسخ القالب'))
      .catch(() => _fallbackCopy(code));
  } else {
    _fallbackCopy(code);
  }
}

function _fallbackCopy(text) {
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity  = '0';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showToast('✅ تم نسخ القالب');
  } catch(e) {
    showToast('❌ تعذّر النسخ');
  }
}

async function deleteIndicator(id, name) {
  if (!confirm(`حذف ${name}؟`)) return;
  try {
    const r = await fetch(`/api/indicators/${encodeURIComponent(id)}`, { method: 'DELETE' });
    const d = await r.json();
    if (d.ok) { showToast('🗑️ تم الحذف'); loadIndicators(); }
    else showToast('❌ ' + (d.error || 'خطأ'));
  } catch(e) { showToast('❌ خطأ'); }
}

/* ═══════════════════════════════════════════════════════
   LIVE VERIFY SHEET
   ═══════════════════════════════════════════════════════ */
let _verifyState = null;   // { id, symbol, tf, pollTimer }

async function verifyIndicator(id) {
  const ind = [..._indicators.filters, ..._indicators.signals].find(i => i.id === id);
  if (!ind) { showToast('❌ المؤشر غير موجود'); return; }

  // Stop any previous polling
  if (_verifyState && _verifyState.pollTimer) {
    clearTimeout(_verifyState.pollTimer);
  }
  // التحقق دائماً على BTCUSDT فريم 5 دقائق من Binance
  _verifyState = { id, ind, symbol: 'BTCUSDT', tf: '5m', pollTimer: null };

  document.getElementById('verify-sh-content').innerHTML =
    `<div class="vs-loading">🔍 جاري التحقق...</div>`;
  openSheet('sheet-verify');

  await fetchAndRenderVerify();
}

async function fetchAndRenderVerify() {
  if (!_verifyState) return;
  const { id, symbol, tf } = _verifyState;
  try {
    const r = await fetch(`/api/indicators/${encodeURIComponent(id)}/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ symbol, tf }),
    });
    const d = await r.json();
    if (!d.ok) {
      renderVerifyError(d.error || 'فشل التحقق');
      return;
    }
    // Persist actual symbol/tf used so polling stays consistent
    _verifyState.symbol = d.symbol;
    _verifyState.tf     = d.tf;
    renderVerifySheet(d);
    schedulePollVerify(d.tf);
  } catch (e) {
    renderVerifyError('خطأ شبكة');
  }
}

function schedulePollVerify(tf) {
  if (!_verifyState) return;
  // Poll roughly TF/10 (min 15s, max 90s for short TFs)
  const tfSecs = { '5m': 300, '15m': 900, '1h': 3600, '4h': 14400, '1d': 86400 };
  const sec    = tfSecs[tf] || 300;
  const delay  = Math.max(15, Math.min(90, Math.round(sec / 10))) * 1000;
  if (_verifyState.pollTimer) clearTimeout(_verifyState.pollTimer);
  _verifyState.pollTimer = setTimeout(fetchAndRenderVerify, delay);
}

function closeVerifySheet() {
  if (_verifyState && _verifyState.pollTimer) {
    clearTimeout(_verifyState.pollTimer);
  }
  _verifyState = null;
  closeSheet('sheet-verify');
}

function renderVerifyError(msg) {
  document.getElementById('verify-sh-content').innerHTML = `
    <div style="display:flex;justify-content:flex-end;padding:0 18px 6px">
      <button class="btn-sh-close-navy" onclick="closeVerifySheet()">✕</button>
    </div>
    <div class="vs-error">❌ ${escapeHtml(msg)}</div>
  `;
}

function renderVerifySheet(d) {
  const isFilter = d.type === 'filter';
  const paramsStr = Object.entries(d.params || {}).map(([k, v]) => `${k}=${v}`).join(' · ');
  const head = `
    <div class="vs-header">
      <div class="vs-h-left">
        <div class="vs-h-title">
          <span class="vs-h-title-text">🔍 تحقق لايف</span>
          <span class="${isFilter ? 'vs-badge-filter' : 'vs-badge-signal'}">${isFilter ? 'فلتر' : 'إشارة'}</span>
        </div>
        <div class="vs-h-meta">${escapeHtml(d.indicator_name || '')} · v${escapeHtml(d.version || '')}${paramsStr ? ' · ' + escapeHtml(paramsStr) : ''}</div>
        <div class="vs-h-tags">
          <span class="vs-tag-symbol">${escapeHtml(d.symbol)}</span>
          <span class="vs-tag-tf">${escapeHtml(d.tf)}</span>
          <span class="vs-tag-live">لايف</span>
        </div>
      </div>
      <button class="btn-sh-close-navy" onclick="closeVerifySheet()">✕</button>
    </div>
  `;

  const body = isFilter ? renderFilterBody(d) : renderSignalBody(d);
  document.getElementById('verify-sh-content').innerHTML = head + body;
}

function renderFilterBody(d) {
  const s = d.stats || {};
  const stats = [
    { v: s.active_count   ?? 0, l: 'مفعّل',     c: '#4ade80' },
    { v: s.inactive_count ?? 0, l: 'غير مفعّل', c: '#f87171' },
    { v: s.last_value != null ? fmtNum(s.last_value) : '—',
      l: s.last_value_label ? `آخر ${s.last_value_label}` : 'آخر قيمة',
      c: '#60a5fa' },
  ];
  const statsHtml = `<div class="vs-stats">${stats.map(x =>
    `<div class="vs-stat"><div class="vs-stat-val" style="color:${x.c}">${escapeHtml(String(x.v))}</div><div class="vs-stat-lbl">${escapeHtml(x.l)}</div></div>`
  ).join('')}</div>`;

  const candles = d.last_candles || [];
  const rowsHtml = candles.length
    ? `<div class="vs-rows">${candles.map(c => renderFilterCandleCard(c)).join('')}</div>`
    : `<div class="vs-loading">لا توجد شموع للعرض</div>`;

  return statsHtml +
    `<div class="vs-section-title">آخر ${candles.length} شموع ↓</div>` +
    rowsHtml +
    `<div class="vs-footer"><div class="vs-footer-text">💡 قارن القيم مع TradingView على نفس الشموع للتحقق من دقة المؤشر</div></div>`;
}

function renderFilterCandleCard(c) {
  let cls = 'vs-card-warmup';
  let badge = `<span class="vs-status-warm">⊘ إحماء</span>`;
  if (c.active === true)  { cls = 'vs-card-active';   badge = `<span class="vs-status-on">✓ مفعّل</span>`; }
  if (c.active === false) { cls = 'vs-card-inactive'; badge = `<span class="vs-status-off">✗ موقف</span>`; }

  const extras = c.extras || {};
  const numExtras = Object.entries(extras).filter(([, v]) => typeof v === 'number');

  /* صف قيمة المؤشر — يظهر في المنتصف بشكل بارز */
  let indValueRow = '';
  if (numExtras.length) {
    indValueRow = `<div class="vs-ind-value-row">${
      numExtras.slice(0, 3).map(([k, v]) =>
        `<span class="vs-ind-key">${escapeHtml(k)}</span>` +
        `<span class="vs-ind-val">${fmtNum(v)}</span>`
      ).join('<span class="vs-ind-sep">·</span>')
    }</div>`;
  } else if (c.active !== null && c.active !== undefined) {
    /* مؤشر قديم يعيد True/False فقط — تلميح للمبرمج */
    indValueRow = `<div class="vs-ind-hint">💡 أعد dict لعرض القيمة: {"active": bool, "قيمتك": float}</div>`;
  }

  return `<div class="vs-card ${cls}">
    <div class="vs-card-top">
      <div class="vs-card-time">${escapeHtml(c.time)}</div>
      <div class="vs-card-right">${badge}</div>
    </div>
    ${indValueRow}
    ${renderOhlcv(c)}
  </div>`;
}

function renderSignalBody(d) {
  const s = d.stats || {};
  const avg = s.avg_gap_candles != null ? `~${s.avg_gap_candles} شمعة` : '—';
  const stats = [
    { v: s.last_signal_label || '—', l: 'آخر إشارة',      c: '#4ade80' },
    { v: s.signals_30d ?? 0,         l: 'إشارات (30 يوم)', c: '#60a5fa' },
    { v: avg,                        l: 'متوسط الفترة',    c: '#a78bfa' },
  ];
  const statsHtml = `<div class="vs-stats">${stats.map(x =>
    `<div class="vs-stat"><div class="vs-stat-val" style="color:${x.c}">${escapeHtml(String(x.v))}</div><div class="vs-stat-lbl">${escapeHtml(x.l)}</div></div>`
  ).join('')}</div>`;

  const sigs = d.last_signals || [];
  const rowsHtml = sigs.length
    ? `<div class="vs-rows">${sigs.map(c => renderSignalCard(c)).join('')}</div>`
    : `<div class="vs-no-signals">
        <div style="font-size:22px;margin-bottom:6px">📭</div>
        <div style="font-size:13px;color:#64748b">لا توجد إشارات في آخر ${(s.total||0).toLocaleString()} شمعة</div>
        <div style="font-size:11px;color:#374151;margin-top:4px">جرّب بيانات BTCUSDT أو تأكد من منطق generate_signals</div>
       </div>`;

  return statsHtml +
    `<div class="vs-section-title">آخر ${sigs.length} شموع ظهرت عليها إشارة دخول ↓</div>` +
    rowsHtml +
    `<div class="vs-footer vs-footer-signal"><div class="vs-footer-text">💡 تحقق من التاريخ والوقت على TradingView للتأكد من صحة الإشارة</div></div>`;
}

function renderSignalCard(c) {
  const extras = c.extras || {};
  // Color palette per pill index
  const palette = [
    { bg: '#3b82f633', fg: '#3b82f6', val: '#93c5fd' },
    { bg: '#a78bfa33', fg: '#a78bfa', val: '#c4b5fd' },
    { bg: '#22c55e33', fg: '#4ade80', val: '#86efac' },
    { bg: '#f59e0b33', fg: '#f59e0b', val: '#fcd34d' },
  ];
  const pills = Object.entries(extras)
    .filter(([, v]) => typeof v === 'number')
    .slice(0, 4)
    .map(([k, v], i) => {
      const p = palette[i] || palette[0];
      return `<div class="vs-extra-pill" style="border-color:${p.bg}">
        <div class="vs-extra-pill-key" style="color:${p.fg}">${escapeHtml(k)}</div>
        <div class="vs-extra-pill-val" style="color:${p.val}">${fmtNum(v)}</div>
      </div>`;
    }).join('');

  const extrasHtml = pills ? `<div class="vs-extras-grid">${pills}</div>` : '';

  return `<div class="vs-card vs-card-signal">
    <div class="vs-card-top">
      <div class="vs-card-time">${escapeHtml(c.time)}</div>
      <span class="vs-status-signal">📍 دخول</span>
    </div>
    ${extrasHtml}
    ${renderOhlcv(c)}
  </div>`;
}

function renderOhlcv(c) {
  const cells = [
    { l: 'O', v: fmtNum(c.open) },
    { l: 'H', v: fmtNum(c.high) },
    { l: 'L', v: fmtNum(c.low) },
    { l: 'C', v: fmtNum(c.close) },
    { l: 'V', v: fmtNum(c.volume) },
  ];
  return `<div class="vs-ohlcv">${cells.map(x =>
    `<div class="vs-ohlcv-cell"><div class="vs-ohlcv-lbl">${x.l}</div><div class="vs-ohlcv-val">${x.v}</div></div>`
  ).join('')}</div>`;
}

function fmtNum(v) {
  if (v == null) return '—';
  if (typeof v !== 'number') return String(v);
  const a = Math.abs(v);
  if (a === 0) return '0';
  let p;
  if (a >= 1000) {
    p = 2;
  } else if (a >= 1) {
    p = 4;
  } else {
    const leadingZeros = Math.max(0, -Math.floor(Math.log10(a)));
    p = Math.min(leadingZeros + 5, 20);
  }
  return v.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: p });
}

/* ═══════════════════════════════════════════════════════
   TEST PAGE
   ═══════════════════════════════════════════════════════ */
let _testPoller = null;
async function loadTests() {
  try {
    const r = await fetch('/api/test/');
    const d = await r.json();
    _tests = d.tests || [];
    if (_tab === 'test') renderTest();
    // Auto-poll while any test is running
    const hasRunning = _tests.some(t => t.status === 'running');
    if (hasRunning && !_testPoller) {
      _testPoller = setInterval(() => { if (_tab === 'test') loadTests(); else { clearInterval(_testPoller); _testPoller = null; } }, 2000);
    } else if (!hasRunning && _testPoller) {
      clearInterval(_testPoller); _testPoller = null;
    }
  } catch(e) {}
}

function renderTest() {
  const el = document.getElementById('page-content');
  const running = _tests.filter(t => t.status === 'running');
  const done    = _tests.filter(t => t.status !== 'running');
  let html = '';

  running.forEach(t => {
    const pct = Math.round((t.progress || 0) * 100);
    const sym = (t.symbols || [t.symbol] || ['—']).join(', ');
    html += `<div class="tst-card">
      <div class="tst-card-top">
        <button class="btn-trash" onclick="event.stopPropagation();stopTest('${t.id}')">⏹</button>
        <div class="tst-card-title-area">
          <span class="tst-id-badge">${t.id}</span>
          <span class="tst-signal-name">${escapeHtml(t.signal_name||'—')}</span>
        </div>
      </div>
      <div class="tst-card-meta">
        <span class="tst-tf-chip" style="background:${TF_COLORS[t.tf]||'#3b82f6'}22;color:${TF_COLORS[t.tf]||'#3b82f6'};border-color:${TF_COLORS[t.tf]||'#3b82f6'}55">${t.tf||'5m'}</span>
        <span class="tst-meta-text">جارٍ ${pct}% · ${escapeHtml(sym)}</span>
      </div>
      <div class="prog-wrap" style="margin-top:8px"><div class="prog-fill" style="width:${pct}%;background:#22c55e"></div></div>
    </div>`;
  });

  if (!done.length && !running.length) {
    html += `<div class="empty-state">
      <div class="empty-icon">✏️</div>
      <div class="empty-text">لا توجد اختبارات بعد</div>
      <div class="empty-hint">اضغط + لبدء اختبار إشارة</div>
    </div>`;
  }

  done.forEach(t => {
    const wr  = t.win_rate != null ? Math.round(t.win_rate) : 0;
    const sym = (t.symbols || [t.symbol] || ['—']).join(', ');
    const wrColor = wr >= 50 ? '#22c55e' : '#ef4444';
    const dateStr = fmtDateTime(t.finished_at || t.created_at);
    html += `<div class="tst-card" onclick="openTestDetail('${t.id}')">
      <div class="tst-card-top">
        <button class="btn-trash" onclick="event.stopPropagation();deleteTest('${t.id}')">🗑️</button>
        <div class="tst-card-title-area">
          <span class="tst-id-badge">${t.id}</span>
          <span class="tst-signal-name">${escapeHtml(t.signal_name||'—')}</span>
        </div>
      </div>
      <div class="tst-card-meta">
        <span class="tst-tf-chip" style="background:${TF_COLORS[t.tf]||'#3b82f6'}22;color:${TF_COLORS[t.tf]||'#3b82f6'};border-color:${TF_COLORS[t.tf]||'#3b82f6'}55">${t.tf||'5m'}</span>
        <span class="tst-meta-text">RR ${t.rr||2} · ${escapeHtml(sym)} · ${dateStr}</span>
      </div>
      <div class="tst-stats-row">
        <div class="tst-stat"><div class="tst-stat-lbl">WR</div><div class="tst-stat-val" style="color:${wrColor}">${wr}%</div></div>
        <div class="tst-stat"><div class="tst-stat-lbl">رابح</div><div class="tst-stat-val c-green">${t.wins||0}</div></div>
        <div class="tst-stat"><div class="tst-stat-lbl">خاسر</div><div class="tst-stat-val c-red">${t.losses||0}</div></div>
      </div>
    </div>`;
  });

  el.innerHTML = html;
}

function openAddSheet(tab) {
  if (tab === 'test')     { prepTestSheet();     openSheet('sheet-test'); }
  if (tab === 'analysis') {
    if (_anlPageTab === 1) { prepTrendSheet(); openSheet('sheet-trend'); }
    else { prepAnalysisSheet(); openSheet('sheet-analysis'); }
  }
  if (tab === 'audit')    { prepAuditSheet();    openSheet('sheet-audit'); }
}

function prepTestSheet() {
  _ts = { selSignal: null, selCurs: [], selTf: '5m', selRR: 2 };

  document.getElementById('ts-signals').innerHTML = _indicators.signals.length
    ? _indicators.signals.map(s =>
        `<button class="signal-pill" onclick="selectSignal('${s.name}')">${s.name}</button>`
      ).join('')
    : '<span style="font-size:12px;color:#555">لا توجد إشارات</span>';

  document.getElementById('ts-currencies').innerHTML = _currencies
    .map(c => `<div class="cur-check-row" id="crc-${c.symbol}" onclick="toggleTsCurrency('${c.symbol}')">
      <div class="check-box" id="chk-${c.symbol}"></div>
      <span style="color:#e2e8f0;font-size:14px">${c.symbol}</span>
    </div>`).join('') || '<span style="font-size:12px;color:#555">لا توجد عملات</span>';

  document.querySelectorAll('#ts-tf-row .tf-btn').forEach(b => {
    const t = b.dataset.tf;
    b.className = 'tf-btn' + (t === '5m' ? ' sel-5m' : '');
  });
  document.querySelectorAll('#ts-rr-row .rr-btn').forEach(b => {
    b.classList.toggle('active', +b.dataset.rr === 2);
  });
}

function selectSignal(name) {
  _ts.selSignal = name;
  document.querySelectorAll('#ts-signals .signal-pill').forEach(p => {
    p.classList.toggle('active', p.textContent === name);
  });
}

function toggleTsCurrency(sym) {
  const idx = _ts.selCurs.indexOf(sym);
  if (idx >= 0) { if (_ts.selCurs.length > 1) _ts.selCurs.splice(idx, 1); }
  else _ts.selCurs.push(sym);
  _currencies.forEach(c => {
    const row = document.getElementById('crc-'+c.symbol);
    const chk = document.getElementById('chk-'+c.symbol);
    if (!row || !chk) return;
    const sel = _ts.selCurs.includes(c.symbol);
    row.classList.toggle('selected', sel);
    chk.classList.toggle('checked', sel);
    chk.innerHTML = sel ? '<span class="check-mark">✓</span>' : '';
  });
  _updateTfChips();
}

function _updateTfChips() {
  const allTfs = ['5m', '15m', '1h', '4h', '1d'];
  const selCurs = _ts.selCurs || [];

  // Build intersection of available TFs across all selected currencies
  let available = new Set(allTfs);
  if (selCurs.length > 0) {
    selCurs.forEach(sym => {
      const cur = _currencies.find(c => c.symbol === sym);
      if (cur && cur.tfs) {
        const curTfs = new Set(
          Object.entries(cur.tfs)
            .filter(([, v]) => v && (v.candles || 0) > 0)
            .map(([tf]) => tf)
        );
        for (const tf of [...available]) {
          if (!curTfs.has(tf)) available.delete(tf);
        }
      }
    });
  }

  document.querySelectorAll('#ts-tf-row .tf-btn').forEach(b => {
    const tf = b.dataset.tf;
    const avail = available.has(tf);
    b.style.display = avail ? '' : 'none';
    if (!avail && _ts.selTf === tf) {
      _ts.selTf = available.has('5m') ? '5m' : [...available][0] || '5m';
    }
  });

  // Sync active style after hiding
  document.querySelectorAll('#ts-tf-row .tf-btn').forEach(b => {
    const tf = b.dataset.tf;
    b.className = 'tf-btn' + (tf === _ts.selTf ? ` sel-${tf}` : '');
  });
}

function selectTf(tf) {
  _ts.selTf = tf;
  document.querySelectorAll('#ts-tf-row .tf-btn').forEach(b => {
    const t = b.dataset.tf;
    b.className = 'tf-btn' + (t === tf ? ` sel-${t}` : '');
  });
}

function selectRR(rr) {
  _ts.selRR = rr;
  document.querySelectorAll('#ts-rr-row .rr-btn').forEach(b => {
    b.classList.toggle('active', +b.dataset.rr === rr);
  });
}

async function runTest() {
  if (!_ts.selSignal)      { showToast('اختر إشارة أولاً'); return; }
  if (!_ts.selCurs.length) { showToast('اختر عملة واحدة على الأقل'); return; }
  try {
    const r = await fetch('/api/test/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ signal_name: _ts.selSignal, symbols: _ts.selCurs,
                             tf: _ts.selTf, rr: _ts.selRR }),
    });
    const d = await r.json();
    if (d.ok || d.id) { closeSheet('sheet-test'); showToast('🚀 بدأ الاختبار'); switchTab('test'); setTimeout(loadTests, 800); }
    else showToast('❌ ' + (d.error || 'خطأ'));
  } catch(e) { showToast('❌ خطأ'); }
}

async function stopTest(id) {
  await fetch(`/api/test/${id}/stop`, { method: 'POST' });
  showToast('⏹ توقف');
  loadTests();
}

async function deleteTest(id) {
  if (!confirm('حذف هذا الاختبار؟')) return;
  await fetch(`/api/test/${id}`, { method: 'DELETE' });
  loadTests();
}

async function openTestDetail(id) {
  try {
    const r = await fetch(`/api/test/${id}`);
    const d = await r.json();
    if (d.id) showDetailPage('test', d);
    else showToast('❌ لم يُعثر على الاختبار');
  } catch(e) { showToast('❌ خطأ'); }
}

function useInAnalysis(testId) {
  closeDetailPage();
  switchTab('analysis');
  setTimeout(() => {
    prepAnalysisSheet();
    selectAnlTest(testId);
    openSheet('sheet-analysis');
  }, 200);
}

function useInAudit(anlData) {
  closeDetailPage();
  switchTab('audit');
  setTimeout(() => {
    prepAuditSheet();
    /* Pre-select signal */
    if (anlData.signal_name) selAuditSignal(anlData.signal_name);
    /* Pre-select symbol as currency */
    if (anlData.symbol) toggleAuditCur(anlData.symbol.toUpperCase());
    /* Pre-fill filters from analysis */
    const filters = anlData.filters || [];
    if (Array.isArray(filters) && filters.length) {
      const list = document.getElementById('audit-filters-list');
      list.innerHTML = '';
      filters.forEach(f => {
        const indId = f.indicator_id || f.id || '';
        const tf    = f.tf || '5m';
        const ind   = _indicators.filters.find(i => i.id === indId);
        const nm    = ind ? ind.name : indId;
        if (!nm) return;
        const id2 = Date.now() + Math.random();
        list.insertAdjacentHTML('beforeend',
          `<div style="display:flex;gap:6px;margin-bottom:6px;align-items:center" id="af-${id2}">
            <span style="flex:1;padding:8px 10px;background:#12151f;border:1px solid #2a2d3a;
                   border-radius:8px;font-size:13px;color:#e2e8f0">
              ${escapeHtml(nm)} <span style="color:#60a5fa;font-size:11px">[${tf}]</span>
            </span>
            <button onclick="document.getElementById('af-${id2}').remove()"
              style="background:#2d1a1a;border:1px solid #4d2d2d;border-radius:8px;
                     color:#f87171;padding:0 10px;cursor:pointer;height:36px">✕</button>
          </div>`);
        /* store as data for audit submission */
        list.lastElementChild.dataset.indId = indId;
        list.lastElementChild.dataset.tf    = tf;
      });
    }
    openSheet('sheet-audit');
    /* فحص الجاهزية بعد التعبئة التلقائية */
    setTimeout(_scheduleReadinessCheck, 300);
  }, 250);
}

function auditTop10Combo(idx) {
  if (!_top10Detail) return;
  const results = _safeArr(_top10Detail.result_json);
  const res = results[idx];
  if (!res) return;
  const anlData = {
    signal_name: _top10Detail.signal_name || '',
    symbol:      _top10Detail.symbol || '',
    filters:     _safeArr(res.filters),
  };
  useInAudit(anlData);
}

/* ═══════════════════════════════════════════════════════
   ANALYSIS PAGE
   ═══════════════════════════════════════════════════════ */
let _anlPoller = null;

async function loadAnalyses() {
  try {
    const [r1, r2] = await Promise.all([
      fetch('/api/analysis/'),
      fetch('/api/analysis/trend'),
    ]);
    const d1 = await r1.json();
    const d2 = await r2.json();
    _analyses     = Array.isArray(d1) ? d1 : (d1.analyses || []);
    _trendAnalyses = Array.isArray(d2) ? d2 : [];
    if (_tab === 'analysis') renderAnalysis();

    /* بولر تلقائي إذا كان هناك Top-10 جارٍ أو Trend جارٍ */
    const hasRunning = _analyses.some(a => a.status === 'running' || a.status === 'paused')
                    || _trendAnalyses.some(a => a.status === 'running');
    if (hasRunning && !_anlPoller) {
      _anlPoller = setInterval(() => {
        if (_tab === 'analysis') loadAnalyses();
        else { clearInterval(_anlPoller); _anlPoller = null; }
      }, 2000);
    } else if (!hasRunning && _anlPoller) {
      clearInterval(_anlPoller); _anlPoller = null;
    }
  } catch(e) {}
}

function renderAnalysis() {
  const el = document.getElementById('page-content');

  // Tab switcher (always shown at top)
  const tabSwitcher = `<div style="display:flex;gap:0;margin-bottom:14px;background:#0d1016;border-radius:12px;padding:3px;border:1px solid #181d27">
    <button onclick="switchAnlPageTab(0)" style="flex:1;padding:9px 0;border:none;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;transition:all 0.2s;background:${_anlPageTab===0?'#22d3a5':'transparent'};color:${_anlPageTab===0?'#0d1016':'#4a5568'}">📊 التحليلات</button>
    <button onclick="switchAnlPageTab(1)" style="flex:1;padding:9px 0;border:none;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;transition:all 0.2s;background:${_anlPageTab===1?'#f59e0b':'transparent'};color:${_anlPageTab===1?'#0d1016':'#4a5568'}">⚡ أفضل اتجاهات</button>
  </div>`;

  if (_anlPageTab === 1) {
    el.innerHTML = tabSwitcher;
    renderTrend();
    return;
  }

  if (!_analyses.length) {
    el.innerHTML = tabSwitcher + `<div class="empty-state">
      <div class="empty-icon">📈</div>
      <div class="empty-text">لا توجد تحليلات بعد</div>
      <div class="empty-hint">اضغط + لبدء تحليل بفلاتر<br>أو ⚡ Top 10 من اختبار</div>
    </div>`;
    return;
  }
  const running = _analyses.filter(a => a.status === 'running' || a.status === 'paused');
  const done    = _analyses.filter(a => a.status !== 'running' && a.status !== 'paused');
  let html = '';
  running.forEach(a => {
    const pct      = Math.round((a.progress || 0) * 100);
    const isPaused = a.status === 'paused';
    const lbl      = a.is_top10
      ? `⚡ Top 10 (${a.combos_tested||0} تركيبة) — ${isPaused ? '⏸ موقوف' : pct+'%'}`
      : `جارٍ التحليل ${pct}%`;
    const delFn    = a.is_top10 ? `deleteTop10('${a.id}')` : `deleteAnalysis('${a.id}')`;
    const barColor = isPaused ? '#f59e0b' : '#22c55e';

    let actionBtns = '';
    if (a.is_top10) {
      if (isPaused) {
        actionBtns = `<button onclick="event.stopPropagation();resumeTop10('${a.id}')"
          style="background:#0d3330;border:1px solid #22d3a5;border-radius:8px;color:#22d3a5;
                 font-size:12px;padding:5px 12px;cursor:pointer">▶️ استئناف</button>`;
      } else {
        actionBtns = `<button onclick="event.stopPropagation();pauseTop10('${a.id}')"
          style="background:#1a1a2a;border:1px solid #f59e0b55;border-radius:8px;color:#f59e0b;
                 font-size:12px;padding:5px 12px;cursor:pointer">⏸ إيقاف مؤقت</button>`;
      }
    }

    html += `<div class="tst-card">
      <div class="tst-card-top">
        <button class="btn-trash" onclick="event.stopPropagation();${delFn}">⏹</button>
        <div class="tst-card-title-area">
          <span class="anl-id-badge">${escapeHtml(a.id||'')}</span>
          <span class="tst-signal-name">${escapeHtml(a.signal_name||'—')}</span>
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-top:4px">
        <div class="tst-card-meta"><span class="tst-meta-text">${lbl}</span></div>
        ${actionBtns}
      </div>
      <div class="prog-wrap" style="margin-top:8px"><div class="prog-fill" style="width:${pct}%;background:${barColor}"></div></div>
    </div>`;
  });
  done.forEach(a => {
    if (a.is_top10) {
      /* ══ كارت Top 10 ══ */
      const combos  = a.combos_tested || 0;
      const sym     = escapeHtml(a.symbol || '—');
      const dateStr = fmtDateTime(a.finished_at || a.created_at);
      const testId  = escapeHtml(a.test_id || '');
      html += `<div class="tst-card">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
          <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
            <span style="background:#1a1a3a;color:#818cf8;border:1px solid #4338ca55;border-radius:6px;padding:3px 8px;font-size:11px;font-weight:700">⚡ نتيجة Top 10</span>
            <span style="background:#12182a;color:#60a5fa;border:1px solid #3b82f644;border-radius:6px;padding:3px 8px;font-size:10px">${escapeHtml(a.id||'')}</span>
          </div>
          <div style="display:flex;gap:6px;align-items:center">
            <button onclick="openTop10Detail('${a.id}')"
              style="background:linear-gradient(135deg,#0d3330,#0a2922);border:1px solid #22d3a5;border-radius:10px;
                     color:#22d3a5;font-size:13px;font-weight:700;padding:7px 18px;cursor:pointer">عرض</button>
            <button class="btn-trash" onclick="deleteTop10('${a.id}')">🗑️</button>
          </div>
        </div>
        <div style="font-size:15px;font-weight:700;color:#e2e8f0;margin-bottom:4px">${escapeHtml(a.signal_name||'—')}</div>
        <div style="font-size:11px;color:#64748b;margin-bottom:10px">${sym}${testId?' · '+testId:''} · ${combos} تركيبة · ${dateStr}</div>
      </div>`;
      return;
    }
    /* ══ كارت التحليل اليدوي ══ */
    const wrRaw   = a.win_rate != null ? a.win_rate : (a.wr_after != null ? a.wr_after : 0);
    const wrVal   = typeof wrRaw === 'number' ? wrRaw : 0;
    const wr      = wrVal.toFixed(1);
    const wrColor = wrVal >= 50 ? '#22c55e' : '#ef4444';
    const sym     = escapeHtml(a.symbol || '—');
    const dateStr = fmtDateTime(a.finished_at || a.created_at);
    const trades  = a.trades_after || 0;
    const wins    = a.wins || 0;
    const testId  = escapeHtml(a.test_id || '');
    const fltText = _filtersText(a.filters_json);
    html += `<div class="tst-card" onclick="openAnlDetail('${a.id}')">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px">
        <span style="font-size:15px;font-weight:700;color:#e2e8f0">${escapeHtml(a.signal_name||'—')}</span>
        <div style="display:flex;gap:6px;align-items:center">
          <span class="anl-id-badge">${escapeHtml(a.id||'')}</span>
          <button class="btn-trash" onclick="event.stopPropagation();deleteAnalysis('${a.id}')">🗑️</button>
        </div>
      </div>
      <div style="font-size:11px;color:#64748b;margin-bottom:4px">${sym}${testId?' · '+testId:''} · ${dateStr}</div>
      ${fltText ? `<div style="font-size:11px;color:#22d3a5;margin-bottom:8px;font-family:monospace">${escapeHtml(fltText)}</div>` : ''}
      <div class="tst-stats-row">
        <div class="tst-stat"><div class="tst-stat-lbl">رابحة</div><div class="tst-stat-val c-green">${wins}</div></div>
        <div class="tst-stat"><div class="tst-stat-lbl">صفقات</div><div class="tst-stat-val c-white">${trades}</div></div>
        <div class="tst-stat"><div class="tst-stat-lbl">WR</div><div class="tst-stat-val" style="color:${wrColor}">${wr}%</div></div>
      </div>
    </div>`;
  });
  el.innerHTML = tabSwitcher + html;
}

function switchAnlPageTab(tab) {
  _anlPageTab = tab;
  renderAnalysis();
}

/* ═══════════════════════════════════════════════════════
   TREND ANALYSIS — Tab 2
   ═══════════════════════════════════════════════════════ */

async function loadTrendAnalyses() {
  try {
    const r = await fetch('/api/analysis/trend');
    const d = await r.json();
    _trendAnalyses = Array.isArray(d) ? d : [];
    if (_tab === 'analysis' && _anlPageTab === 1) renderAnalysis();
  } catch(e) {}
}

function renderTrend() {
  const container = document.getElementById('page-content');

  if (!_trendAnalyses.length) {
    container.insertAdjacentHTML('beforeend',
      `<div id="trend-results-area" style="display:flex;flex-direction:column;gap:12px">
        <div class="empty-state" style="padding:32px 16px">
          <div class="empty-icon">⚡</div>
          <div class="empty-text">لا توجد تحليلات اتجاه بعد</div>
          <div class="empty-hint">اضغط + لاختيار رمز وإعدادات<br>ثم احسب أفضل 10 اتجاهات</div>
        </div>
      </div>`
    );
    return;
  }

  const running = _trendAnalyses.filter(a => a.status === 'running');
  const done    = _trendAnalyses.filter(a => a.status !== 'running');

  let html = '';

  // ── بطاقات الحساب الجارية ──────────────────────────────────────────────────
  running.forEach(a => {
    const sym = escapeHtml(a.symbol || '—');
    html += `<div class="tst-card" style="border-color:#f59e0b44">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
          <span style="background:#1a1a2e;color:#f59e0b;border:1px solid #f59e0b44;border-radius:6px;padding:3px 8px;font-size:11px;font-weight:700">⚡ اتجاه</span>
          <span style="background:#12182a;color:#60a5fa;border:1px solid #3b82f644;border-radius:6px;padding:3px 8px;font-size:10px">${escapeHtml(a.id||'')}</span>
        </div>
        <div style="display:flex;gap:6px">
          <button onclick="event.stopPropagation();stopTrend('${a.id}')"
            style="background:linear-gradient(135deg,#2d1200,#1a0a00);border:1px solid #f59e0b;border-radius:10px;
                   color:#f59e0b;font-size:12px;font-weight:700;padding:6px 14px;cursor:pointer">
            ⏹ إيقاف</button>
        </div>
      </div>
      <div style="font-size:16px;font-weight:700;color:#e2e8f0;margin-bottom:10px">${sym}</div>
      <div style="font-size:11px;color:#f59e0b;margin-bottom:6px">⚡ جارٍ الحساب...</div>
      <div style="background:#1a1a2e;border-radius:8px;height:6px;overflow:hidden">
        <div style="height:100%;background:linear-gradient(90deg,#f59e0b,#fbbf24);
                    border-radius:8px;width:40%;animation:pulse-bar 1.2s ease-in-out infinite"></div>
      </div>
      <div style="font-size:11px;color:#4a5568;margin-top:6px">أطر: ${escapeHtml(_safeArr(a.allowed_tfs).join(', ')||'الكل')} · حد: ${a.min_candles||500} شمعة · تركيبة ≤${a.max_combo_size||3}</div>
    </div>`;
  });

  // ── البطاقات المنتهية ─────────────────────────────────────────────────────
  html += done.map(a => {
    const cnt     = a.result_count || 0;
    const sym     = escapeHtml(a.symbol || '—');
    const dateStr = fmtDateTime(a.created_at);
    const tfsArr  = _safeArr(a.allowed_tfs);
    const tfsLbl  = tfsArr.length ? tfsArr.join(', ') : 'الكل';
    const pctLbl  = (a.min_bullish_pct || 50) + '% ↑';
    const isStopped = a.status === 'stopped' || a.status === 'error';
    const badge = isStopped
      ? `<span style="background:#2d1200;color:#f59e0b;border:1px solid #f59e0b44;border-radius:6px;padding:3px 7px;font-size:10px">⏹ موقوف</span>`
      : '';
    return `<div class="tst-card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
        <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
          <span style="background:#1a1a2e;color:#f59e0b;border:1px solid #f59e0b44;border-radius:6px;padding:3px 8px;font-size:11px;font-weight:700">⚡ اتجاه</span>
          <span style="background:#12182a;color:#60a5fa;border:1px solid #3b82f644;border-radius:6px;padding:3px 8px;font-size:10px">${escapeHtml(a.id||'')}</span>
          ${badge}
        </div>
        <div style="display:flex;gap:6px;align-items:center">
          ${!isStopped ? `<button onclick="openTrendDetail('${a.id}')"
            style="background:linear-gradient(135deg,#0d3330,#0a2922);border:1px solid #22d3a5;border-radius:10px;
                   color:#22d3a5;font-size:13px;font-weight:700;padding:7px 18px;cursor:pointer">عرض</button>` : ''}
          <button class="btn-trash" onclick="deleteTrendAnalysis('${a.id}')">🗑️</button>
        </div>
      </div>
      <div style="font-size:16px;font-weight:700;color:#e2e8f0;margin-bottom:4px">${sym}</div>
      <div style="font-size:11px;color:#64748b;margin-bottom:8px">${cnt} نتيجة · ${pctLbl} · ${dateStr}</div>
      <div style="font-size:11px;color:#4a5568">أطر: ${escapeHtml(tfsLbl)} · حد أدنى: ${a.min_candles||500} شمعة · تركيبة ≤${a.max_combo_size||3}</div>
    </div>`;
  }).join('');

  container.insertAdjacentHTML('beforeend',
    `<div id="trend-results-area" style="display:flex;flex-direction:column;gap:12px">${html}</div>`
  );
}

async function openTrendDetail(id) {
  try {
    const r = await fetch(`/api/analysis/trend/${id}`);
    const d = await r.json();
    showTrendDetailPage(d);
  } catch(e) { showToast('❌ خطأ'); }
}

function showTrendDetailPage(d) {
  const dp = document.getElementById('detail-page');
  dp.style.display = 'flex';
  document.getElementById('detail-title').innerHTML = `
    <div style="font-size:12px;color:#f59e0b;letter-spacing:1px">⚡ Trading Lab</div>
    <div style="font-size:20px;font-weight:700;color:#fff">⚡ أفضل اتجاهات</div>`;

  const results = _safeArr(d.result_json);
  const bestPct = results.length ? (results[0].bullish_pct || 0) : null;
  const tfsArr  = _safeArr(d.allowed_tfs);
  const tfsLbl  = tfsArr.length ? tfsArr.join(', ') : 'الكل';

  let html = `<div class="tst-card" style="cursor:default">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
      <div>
        <div style="font-size:17px;font-weight:700;color:#fff;margin-bottom:3px">${escapeHtml(d.symbol||'—')}</div>
        <div style="font-size:12px;color:#64748b">أطر: ${escapeHtml(tfsLbl)} · حد: ${d.min_candles||500} شمعة · ↑≥${d.min_bullish_pct||50}%</div>
      </div>
      <span style="background:#1a1a2e;color:#f59e0b;border:1px solid #f59e0b44;border-radius:6px;padding:3px 8px;font-size:11px">${escapeHtml(d.id||'')}</span>
    </div>
    <div class="stat-grid2">
      <div class="stat-box"><div class="stat-label">نتائج مؤهلة</div><div class="stat-v22 c-white">${d.result_count||0}</div></div>
      <div class="stat-box"><div class="stat-label">أفضل نسبة ↑</div>
        <div class="stat-v22" style="color:${bestPct>=60?'#22c55e':bestPct>=55?'#f59e0b':'#60a5fa'}">${bestPct!=null?bestPct.toFixed(1)+'%':'—'}</div>
      </div>
    </div>
  </div>`;

  if (!results.length) {
    html += `<div style="text-align:center;padding:32px 16px;color:#64748b;font-size:13px">
      <div style="font-size:28px;margin-bottom:10px">🔍</div>
      <div style="font-weight:600;margin-bottom:4px">لا توجد تركيبات مؤهلة</div>
      <div style="font-size:12px">جرّب تقليل الحد الأدنى للشموع أو نسبة الصعود</div>
    </div>`;
  } else {
    html += results.map((res, idx) => {
      const pct  = typeof res.bullish_pct === 'number' ? res.bullish_pct : 0;
      const col  = pct >= 60 ? '#22c55e' : pct >= 55 ? '#f59e0b' : '#60a5fa';
      const filt = _safeArr(res.filters).map(f =>
        `<span style="background:#1e2130;border:1px solid #2a2d3a;border-radius:6px;
               padding:3px 9px;font-size:11px;color:#94a3b8;font-family:monospace">
          ${escapeHtml(f.name || _indName(f.indicator_id||''))}
          <span style="color:#22d3a5">@${f.tf||''}</span>
        </span>`
      ).join('');
      return `<div class="tst-card" style="cursor:default">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <span style="font-size:15px;color:#818cf8;font-weight:700">#${idx+1}</span>
          <span style="font-size:22px;font-weight:800;color:${col}">${pct.toFixed(1)}%</span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px">${filt}</div>
        <div class="stat-grid2">
          <div class="stat-box"><div class="stat-label">اتفاق</div><div class="stat-v18 c-white">${res.agreements||0}</div></div>
          <div class="stat-box"><div class="stat-label">صاعدة</div><div class="stat-v18" style="color:${col}">${res.bullish||0}</div></div>
        </div>
      </div>`;
    }).join('');
  }

  document.getElementById('detail-body').innerHTML = html;
  _setDetailNav();
}

async function deleteTrendAnalysis(id) {
  if (!confirm('حذف هذا التحليل؟')) return;
  await fetch(`/api/analysis/trend/${id}`, { method: 'DELETE' });
  loadAnalyses();
}

function prepTrendSheet() {
  const symList = document.getElementById('trend-sym-list');
  if (!symList) return;
  if (!_currencies.length) {
    symList.innerHTML = '<div style="padding:14px;font-size:12px;color:#555;text-align:center">لا توجد عملات</div>';
  } else {
    symList.innerHTML = _currencies.map(c =>
      `<div onclick="selectTrendSymbol('${c.symbol}')" id="trend-sym-${c.symbol}"
        style="padding:10px 14px;cursor:pointer;border-bottom:1px solid #181d27;
               display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:14px;color:#e2e8f0;font-weight:600">${c.symbol}</span>
        <span style="font-size:11px;color:#4a5568">${c.candles||0} شمعة</span>
      </div>`
    ).join('');
  }
  if (_trendState.selSymbol) {
    const el = document.getElementById('trend-sym-' + _trendState.selSymbol);
    if (el) { el.style.background = '#0d3330'; el.style.borderLeft = '3px solid #22d3a5'; }
  }
  if (_trendState.selSymbol && _trendState.selTfs.length) {
    updateTrendTfRow(_trendState.selTfs);
  } else {
    document.getElementById('trend-tf-row').innerHTML =
      '<span style="font-size:11px;color:#555">اختر رمزاً أولاً</span>';
  }
  document.querySelectorAll('#trend-min-candles-row .rr-btn').forEach(b =>
    b.classList.toggle('active', +b.dataset.mc === _trendState.minCandles));
  document.querySelectorAll('#trend-min-pct-row .rr-btn').forEach(b =>
    b.classList.toggle('active', +b.dataset.pct === _trendState.minBullishPct));
  document.querySelectorAll('#trend-combo-row .rr-btn').forEach(b =>
    b.classList.toggle('active', +b.dataset.cs === _trendState.maxComboSize));
  document.querySelectorAll('#trend-sort-row .rr-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.sb === _trendState.sortBy));
}

async function selectTrendSymbol(sym) {
  _trendState.selSymbol = sym;
  document.querySelectorAll('#trend-sym-list > div').forEach(el => {
    el.style.background = '';
    el.style.borderLeft = '';
  });
  const el = document.getElementById('trend-sym-' + sym);
  if (el) { el.style.background = '#0d3330'; el.style.borderLeft = '3px solid #22d3a5'; }

  document.getElementById('trend-tf-row').innerHTML =
    '<span style="font-size:11px;color:#64748b">⏳ جارٍ التحميل...</span>';
  try {
    const r = await fetch(`/api/analysis/available_data?symbol=${encodeURIComponent(sym)}`);
    const d = await r.json();
    const tfs = d.all_tfs || [];
    _trendState.selTfs = [...tfs];
    updateTrendTfRow(tfs);
  } catch(e) {
    document.getElementById('trend-tf-row').innerHTML =
      '<span style="font-size:11px;color:#ef4444">❌ خطأ في التحميل</span>';
  }
}

function updateTrendTfRow(tfs) {
  const row = document.getElementById('trend-tf-row');
  if (!tfs.length) {
    row.innerHTML = '<span style="font-size:11px;color:#555">لا توجد بيانات لهذا الرمز</span>';
    return;
  }
  row.innerHTML = tfs.map(tf => {
    const col    = TF_COLORS[tf] || '#22d3a5';
    const active = _trendState.selTfs.includes(tf);
    return `<button class="anl-tf-chip" id="trendtf-${tf}"
      style="border-color:${active?col:col+'55'};color:${active?col:'#64748b'};background:${active?col+'22':'transparent'};font-weight:${active?'700':'400'}"
      onclick="toggleTrendTf('${tf}')">${tf}</button>`;
  }).join('');
}

function toggleTrendTf(tf) {
  const col = TF_COLORS[tf] || '#22d3a5';
  const btn = document.getElementById('trendtf-' + tf);
  const idx = _trendState.selTfs.indexOf(tf);
  if (idx >= 0) {
    _trendState.selTfs.splice(idx, 1);
    if (btn) { btn.style.color='#64748b'; btn.style.background='transparent'; btn.style.borderColor=col+'55'; btn.style.fontWeight='400'; }
  } else {
    _trendState.selTfs.push(tf);
    if (btn) { btn.style.color=col; btn.style.background=col+'22'; btn.style.borderColor=col; btn.style.fontWeight='700'; }
  }
}

function selTrendMinCandles(v) {
  _trendState.minCandles = v;
  document.querySelectorAll('#trend-min-candles-row .rr-btn').forEach(b =>
    b.classList.toggle('active', +b.dataset.mc === v));
}
function selTrendMinPct(v) {
  _trendState.minBullishPct = v;
  document.querySelectorAll('#trend-min-pct-row .rr-btn').forEach(b =>
    b.classList.toggle('active', +b.dataset.pct === v));
}
function selTrendCombo(v) {
  _trendState.maxComboSize = v;
  document.querySelectorAll('#trend-combo-row .rr-btn').forEach(b =>
    b.classList.toggle('active', +b.dataset.cs === v));
}
function selTrendSort(v) {
  _trendState.sortBy = v;
  document.querySelectorAll('#trend-sort-row .rr-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.sb === v));
}

async function runTrend() {
  const sym = _trendState.selSymbol;
  if (!sym) { showToast('اختر رمزاً أولاً'); return; }

  closeSheet('sheet-trend');
  _anlPageTab = 1;

  if (_tab === 'analysis') renderAnalysis();
  else switchTab('analysis');

  try {
    const r = await fetch('/api/analysis/trend', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        symbol:          sym,
        allowed_tfs:     _trendState.selTfs,
        min_candles:     _trendState.minCandles,
        min_bullish_pct: _trendState.minBullishPct,
        max_combo_size:  _trendState.maxComboSize,
        sort_by:         _trendState.sortBy,
      }),
    });
    const d = await r.json();
    if (d.error) { showToast('❌ ' + d.error); return; }
    showToast('⚡ بدأ حساب الاتجاهات في الخلفية');
    /* حمّل القائمة فوراً لتظهر البطاقة الجارية */
    await loadAnalyses();
  } catch(e) {
    showToast('❌ خطأ في الاتصال');
  }
}

async function stopTrend(id) {
  await fetch(`/api/analysis/trend/${id}/stop`, { method: 'POST' });
  showToast('⏹ تم إيقاف الحساب');
  loadAnalyses();
}


function prepAnalysisSheet() {
  _as = { selTest: null, selSymbol: '', availableData: null, selTop10Tfs: [] };
  _anlSelected = [];

  document.getElementById('anl-tests-list').innerHTML = _tests.filter(t => t.status !== 'running')
    .map(t => `<div onclick="selectAnlTest('${t.id}')" id="anlt-${t.id}"
      style="padding:10px 14px;cursor:pointer;border-bottom:1px solid #2a2d3a;
             display:flex;justify-content:space-between;align-items:center">
      <div style="text-align:right">
        <div style="font-size:14px;color:#e2e8f0;font-weight:600">${escapeHtml(t.signal_name||'—')}</div>
        <div style="font-size:11px;color:#64748b;margin-top:2px">${escapeHtml((t.symbol||(Array.isArray(t.symbols)?t.symbols[0]:'')||''))} · ${t.tf||''}</div>
      </div>
      <span class="tst-id-badge" style="font-size:10px">${escapeHtml(t.id||'')}</span>
    </div>`).join('') || '<div style="padding:14px;font-size:12px;color:#555;text-align:center">لا توجد اختبارات</div>';

  document.getElementById('anl-inds-list').innerHTML = '<div style="font-size:12px;color:#555;text-align:center;padding:16px">اختر اختباراً أولاً لرؤية الفلاتر المتاحة</div>';
  document.getElementById('anl-data-badge').style.display = 'none';
  document.getElementById('top10-tf-row').innerHTML = '<span style="font-size:11px;color:#555">اختر اختباراً أولاً</span>';
}

async function selectAnlTest(id) {
  _as.selTest = String(id);
  _anlSelected = [];

  document.querySelectorAll('#anl-tests-list > div').forEach(el => {
    el.style.background = '';
    el.style.borderLeft = '';
  });
  const selEl = document.getElementById('anlt-'+id);
  if (selEl) {
    selEl.style.background = '#0d3330';
    selEl.style.borderLeft = '3px solid #22d3a5';
  }

  // Find the selected test to get its symbol
  const test = _tests.find(t => String(t.id) === String(id));
  if (!test) return;

  /* symbols_json هو نص JSON خام، استخدم test.symbols (محللة من الـ backend)
     أو فسّر symbols_json يدوياً كخطوة احتياطية */
  let symArr = [];
  if (Array.isArray(test.symbols) && test.symbols.length)  symArr = test.symbols;
  else if (typeof test.symbols_json === 'string') {
    try { symArr = JSON.parse(test.symbols_json); } catch(e) {}
  }
  const symbol = (test.symbol || symArr[0] || '').toUpperCase().trim();
  _as.selSymbol = symbol;

  if (!symbol) {
    document.getElementById('anl-data-badge').style.display = 'none';
    document.getElementById('anl-inds-list').innerHTML =
      '<div style="font-size:12px;color:#ef4444;text-align:center;padding:16px">⚠️ لا يوجد رمز مرتبط بهذا الاختبار</div>';
    return;
  }

  // Show loading state for indicators
  document.getElementById('anl-inds-list').innerHTML =
    '<div style="text-align:center;padding:16px;color:#64748b;font-size:13px">⏳ جارٍ تحميل البيانات...</div>';
  document.getElementById('anl-data-badge').style.display = 'none';

  try {
    const r = await fetch(`/api/analysis/available_data?symbol=${encodeURIComponent(symbol)}`);
    const d = await r.json();
    _as.availableData = d;

    // Show data availability badge
    const badge = document.getElementById('anl-data-badge');
    const info  = document.getElementById('anl-data-info');
    const indCount = (d.indicators||[]).length;
    const tfList  = (d.all_tfs||[]).join(', ') || '—';
    info.textContent = `${indCount} فلاتر · الفريمات: ${tfList}`;
    badge.style.display = 'block';

    // Render indicator cards with only available TFs
    renderAnlIndsFromSaved(d);
    updateTop10TfRow(d.all_tfs || []);
  } catch(e) {
    document.getElementById('anl-inds-list').innerHTML =
      '<span style="font-size:12px;color:#ef4444;padding:12px;display:block;text-align:center">❌ خطأ في تحميل البيانات</span>';
  }
}

function renderAnlIndsFromSaved(data) {
  const inds = data.indicators || [];
  if (!inds.length) {
    const sym = _as.selSymbol || '';
    document.getElementById('anl-inds-list').innerHTML =
      `<div style="background:#151825;border-radius:12px;border:1px solid #2a2d3a;padding:20px 16px;text-align:center">
        <div style="font-size:22px;margin-bottom:8px">🔧</div>
        <div style="font-size:13px;color:#94a3b8;font-weight:600;margin-bottom:4px">
          لم تُحسب الفلاتر بعد لـ ${escapeHtml(sym)||'هذه العملة'}
        </div>
        <div style="font-size:11px;color:#4a5568;margin-bottom:14px;line-height:1.5">
          يجب حساب الفلاتر أولاً في صفحة البيانات<br>
          اضغط الزر أدناه وسيفتح الشاشة مباشرةً
        </div>
        <button onclick="goComputeFiltersFor('${escapeHtml(sym)}')"
          style="background:linear-gradient(135deg,#1a3a2a,#0d2a1a);
                 border:1px solid #22c55e55;border-radius:10px;
                 color:#4ade80;font-size:13px;font-weight:600;
                 padding:10px 20px;cursor:pointer;width:100%">
          ⚡ احسب الفلاتر الآن
        </button>
      </div>`;
    return;
  }
  document.getElementById('anl-inds-list').innerHTML = inds.map(ind => {
    const safeId = (ind.indicator_id||'').replace(/'/g, "\'");
    const tfsHtml = (ind.tfs||[]).map(tf => {
      const col = TF_COLORS[tf] || '#22d3a5';
      return `<button class="anl-tf-chip" id="anlchk-${escapeHtml(ind.indicator_id)}-${tf}"
        data-ind="${escapeHtml(ind.indicator_id)}" data-tf="${tf}"
        style="border-color:${col}55;color:#64748b"
        onclick="toggleAnlInd('${safeId}','${tf}')">${tf}</button>`;
    }).join('') || '<span style="font-size:11px;color:#555">لا توجد فريمات</span>';
    return `<div class="anl-ind-card" id="anlcard-${escapeHtml(ind.indicator_id)}">
      <div class="anl-ind-card-header">
        <div class="anl-ind-card-name">${escapeHtml(ind.name)}</div>
        <span class="anl-card-check" id="anlcheck-${escapeHtml(ind.indicator_id)}">✓</span>
      </div>
      <div class="anl-ind-tfs">${tfsHtml}</div>
    </div>`;
  }).join('');
}

function updateTop10TfRow(tfs) {
  const row = document.getElementById('top10-tf-row');
  if (!row) return;
  _as.selTop10Tfs = [...tfs];
  if (!tfs.length) {
    row.innerHTML = '<span style="font-size:11px;color:#555">لا توجد فريمات متاحة</span>';
    return;
  }
  row.innerHTML = tfs.map(tf => {
    const col = TF_COLORS[tf] || '#22d3a5';
    return `<button class="anl-tf-chip" id="t10tf-${tf}"
      style="border-color:${col};color:${col};background:${col}22;font-weight:700"
      onclick="toggleTop10Tf('${tf}')">${tf}</button>`;
  }).join('');
}

function toggleTop10Tf(tf) {
  if (!_as.selTop10Tfs) _as.selTop10Tfs = [];
  const col = TF_COLORS[tf] || '#22d3a5';
  const btn = document.getElementById('t10tf-'+tf);
  const idx = _as.selTop10Tfs.indexOf(tf);
  if (idx >= 0) {
    _as.selTop10Tfs.splice(idx, 1);
    if (btn) { btn.style.color='#64748b'; btn.style.background='transparent'; btn.style.borderColor=col+'55'; btn.style.fontWeight='400'; }
  } else {
    _as.selTop10Tfs.push(tf);
    if (btn) { btn.style.color=col; btn.style.background=col+'22'; btn.style.borderColor=col; btn.style.fontWeight='700'; }
  }
}

function toggleTop10() {
  const body  = document.getElementById('top10-body');
  const arrow = document.getElementById('top10-arrow');
  const open  = body.style.display !== 'none';
  body.style.display  = open ? 'none' : 'flex';
  arrow.textContent   = open ? '▼' : '▲';
}

function selTop10RR(rr) {
  _top10RR = rr;
  document.querySelectorAll('#top10-rr-row .rr-btn').forEach(b => {
    b.classList.toggle('active', +b.dataset.rr === rr);
  });
}

function toggleAnlInd(indicator_id, tf) {
  const key = `${indicator_id}__${tf}`;
  const i   = _anlSelected.indexOf(key);
  const btn = document.getElementById(`anlchk-${indicator_id}-${tf}`);
  const col = TF_COLORS[tf] || '#22d3a5';
  if (i >= 0) {
    /* إلغاء التحديد */
    _anlSelected.splice(i, 1);
    if (btn) {
      btn.style.background  = 'transparent';
      btn.style.color       = '#64748b';
      btn.style.borderColor = col + '55';
      btn.style.fontWeight  = '400';
      btn.style.boxShadow   = 'none';
      btn.innerHTML = tf;
    }
  } else {
    /* تحديد مع علامة صح */
    _anlSelected.push(key);
    if (btn) {
      btn.style.background  = col + '33';
      btn.style.color       = col;
      btn.style.borderColor = col;
      btn.style.fontWeight  = '700';
      btn.style.boxShadow   = `0 0 6px ${col}55`;
      btn.innerHTML = `✓ ${tf}`;
    }
  }

  /* تحديث علامة الكارد: تظهر إذا كان أي فريم محدداً */
  const anySelected = _anlSelected.some(k => k.startsWith(`${indicator_id}__`));
  const card     = document.getElementById(`anlcard-${indicator_id}`);
  const checkEl  = document.getElementById(`anlcheck-${indicator_id}`);
  if (card)    card.classList.toggle('has-selection', anySelected);
  if (checkEl) checkEl.style.display = anySelected ? 'inline-flex' : 'none';
}

async function runAnalysis() {
  if (!_as.selTest)  { showToast('اختر اختباراً أولاً'); return; }
  if (!_anlSelected.length) { showToast('اختر فلتراً واحداً على الأقل'); return; }
  const filters = _anlSelected.map(k => {
    const [indicator_id, tf] = k.split('__');
    return { indicator_id, tf };
  });
  try {
    const r = await fetch('/api/analysis/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ test_id: _as.selTest, filters }),
    });
    const d = await r.json();
    if (d.id) { closeSheet('sheet-analysis'); showToast('📊 بدأ التحليل'); switchTab('analysis'); }
    else showToast('❌ ' + (d.error || 'خطأ'));
  } catch(e) { showToast('❌ خطأ'); }
}

async function runTop10() {
  if (!_as.selTest) { showToast('اختر اختباراً أولاً'); return; }
  const indicator_ids = (_as.availableData?.indicators || []).map(i => i.indicator_id);
  if (!indicator_ids.length) { showToast('لا توجد فلاتر متاحة'); return; }
  const tfs              = _as.selTop10Tfs || [];
  const min_trades       = +document.getElementById('top10-min').value;
  const min_coverage_pct = +document.getElementById('top10-cov').value;
  try {
    const r = await fetch('/api/analysis/top10', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ test_id: _as.selTest, indicator_ids, tfs, min_trades, min_coverage_pct }),
    });
    const d = await r.json();
    if (d.id) { closeSheet('sheet-analysis'); showToast('⚡ Top 10 بدأ (Hybrid)'); switchTab('analysis'); }
    else showToast('❌ ' + (d.error || 'خطأ'));
  } catch(e) { showToast('❌ خطأ'); }
}

async function pauseTop10(id) {
  try {
    await fetch(`/api/analysis/top10/${id}/pause`, { method: 'POST' });
    showToast('⏸ تم الإيقاف المؤقت — يُحفظ التقدم');
    setTimeout(loadAnalyses, 800);
  } catch(e) { showToast('❌ خطأ'); }
}

async function resumeTop10(id) {
  try {
    await fetch(`/api/analysis/top10/${id}/resume`, { method: 'POST' });
    showToast('▶️ استُؤنف البحث');
    setTimeout(loadAnalyses, 800);
  } catch(e) { showToast('❌ خطأ'); }
}

async function deleteTop10(id) {
  if (!confirm('حذف هذا البحث؟')) return;
  await fetch(`/api/analysis/top10/${id}`, { method: 'DELETE' });
  loadAnalyses();
}

async function openAnlDetail(id) {
  try {
    const r = await fetch(`/api/analysis/${id}`);
    const d = await r.json();
    showDetailPage('analysis', d);
  } catch(e) { showToast('❌ خطأ'); }
}

async function deleteAnalysis(id) {
  if (!confirm('حذف هذا التحليل؟')) return;
  await fetch(`/api/analysis/${id}`, { method: 'DELETE' });
  loadAnalyses();
}

async function openTop10Detail(id) {
  try {
    const r = await fetch(`/api/analysis/top10/${id}`);
    const d = await r.json();
    showTop10DetailPage(d);
  } catch(e) { showToast('❌ خطأ'); }
}

function showTop10DetailPage(d) {
  _top10Detail = d;
  const dp = document.getElementById('detail-page');
  dp.style.display = 'flex';
  document.getElementById('detail-title').innerHTML = `
    <div style="font-size:12px;color:#f59e0b;letter-spacing:1px">⚡ Trading Lab</div>
    <div style="font-size:20px;font-weight:700;color:#fff">⚡ Top 10 نتائج</div>`;

  /* result_json قد يكون array مباشرةً (بعد row_to_dict auto-parse) أو نصاً */
  const results = _safeArr(d.result_json);
  const bestWr  = results.length ? results[0].wr || 0 : null;

  let html = `<div class="tst-card" style="cursor:default">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
      <div>
        <div style="font-size:16px;font-weight:700;color:#fff;margin-bottom:3px">${escapeHtml(d.signal_name||'—')}</div>
        <div style="font-size:12px;color:#64748b">${escapeHtml(d.symbol||'—')}${d.test_id?' · '+escapeHtml(d.test_id):''}</div>
      </div>
      <span style="background:#1a1a3a;color:#818cf8;border:1px solid #4338ca55;border-radius:6px;padding:3px 8px;font-size:11px">${escapeHtml(d.id||'')}</span>
    </div>
    <div class="stat-grid2">
      <div class="stat-box"><div class="stat-label">تركيبات مؤهلة</div><div class="stat-v22 c-white">${d.combos_tested||0}</div></div>
      <div class="stat-box"><div class="stat-label">أفضل WR</div>
        <div class="stat-v22" style="color:${bestWr>=50?'#22c55e':'#ef4444'}">${bestWr!=null?bestWr.toFixed(1)+'%':'—'}</div></div>
    </div>
  </div>`;

  if (!results.length) {
    html += `<div style="text-align:center;padding:32px 16px;color:#64748b;font-size:13px">
      <div style="font-size:28px;margin-bottom:10px">🔍</div>
      <div style="font-weight:600;margin-bottom:4px">لا توجد تركيبات مؤهلة</div>
      <div style="font-size:12px">جرّب تقليل الحد الأدنى للصفقات أو إضافة فلاتر أخرى</div>
    </div>`;
  } else {
    html += results.slice(0,10).map((res, idx) => {
      const wr  = typeof res.wr === 'number' ? res.wr : 0;
      const col = wr >= 50 ? '#22c55e' : '#ef4444';
      const filters = _safeArr(res.filters).map(f =>
        `<span style="background:#1e2130;border:1px solid #2a2d3a;border-radius:6px;
               padding:3px 9px;font-size:11px;color:#94a3b8;font-family:monospace">
          ${escapeHtml(_indName(f.indicator_id||f.id||''))}
          <span style="color:#22d3a5">@${f.tf||''}</span>
        </span>`).join('');
      return `<div class="tst-card" style="cursor:default">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <span style="font-size:15px;color:#818cf8;font-weight:700">#${idx+1}</span>
          <span style="font-size:20px;font-weight:700;color:${col}">${wr.toFixed(1)}%</span>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px">${filters}</div>
        <div class="stat-grid3">
          <div class="stat-box"><div class="stat-label">صفقات</div><div class="stat-v18 c-white">${res.trades||0}</div></div>
          <div class="stat-box"><div class="stat-label">رابحة</div><div class="stat-v18 c-green">${res.wins||0}</div></div>
          <div class="stat-box"><div class="stat-label">خاسرة</div><div class="stat-v18 c-red">${res.losses||0}</div></div>
        </div>
        <button onclick="auditTop10Combo(${idx})"
          style="width:100%;margin-top:10px;padding:11px;
                 background:linear-gradient(135deg,#0a2318,#071a10);
                 border:1px solid #22c55e55;border-radius:10px;
                 color:#22c55e;font-size:14px;font-weight:600;
                 cursor:pointer;display:flex;align-items:center;
                 justify-content:center;gap:6px">
          🛡️ تدقيق هذه التركيبة
        </button>
      </div>`;
    }).join('');
  }

  document.getElementById('detail-body').innerHTML = html;
  _setDetailNav();
}

/* ═══════════════════════════════════════════════════════
   AUDIT PAGE
   ═══════════════════════════════════════════════════════ */
async function loadAudits() {
  try {
    const r = await fetch('/api/audit/');
    const d = await r.json();
    _audits = Array.isArray(d) ? d : (d.audits || []);
    if (_tab === 'audit') renderAudit();
  } catch(e) {}
}

function renderAudit() {
  const el = document.getElementById('page-content');
  if (!_audits.length) {
    el.innerHTML = `<div class="empty-state">
      <div class="empty-icon">🛡️</div>
      <div class="empty-text">لا توجد تدقيقات بعد<br>اضغط + لبدء تدقيق</div>
    </div>`;
    return;
  }
  el.innerHTML = _audits.map(a => {
    const wr = Math.round(a.total_wr || 0);
    const passed = wr >= 50;
    const passColor = passed ? '#22c55e' : '#ef4444';
    let syms = [];
    try { syms = JSON.parse(a.currencies_json || '[]'); } catch(e) {}
    const sym = syms.join(', ') || '—';
    const dateStr = fmtDateTime(a.finished_at || a.created_at);
    return `<div class="tst-card" onclick="openAuditDetail('${a.id}')">
      <div class="tst-card-top">
        <button class="btn-trash" onclick="event.stopPropagation();deleteAudit('${a.id}')">🗑️</button>
        <div class="tst-card-title-area">
          <span class="tst-id-badge" style="color:${passColor};border-color:${passColor}44;background:${passColor}11">${passed ? '✅' : '❌'} ${escapeHtml(a.id||'')}</span>
          <span class="tst-signal-name">${escapeHtml(a.signal_id||'—')}</span>
        </div>
      </div>
      <div class="tst-card-meta">
        <span class="tst-meta-text">${escapeHtml(sym)} · ${dateStr}</span>
      </div>
      <div class="tst-stats-row">
        <div class="tst-stat"><div class="tst-stat-lbl">النتيجة</div><div class="tst-stat-val" style="color:${passColor}">${passed ? 'ناجح' : 'راسب'}</div></div>
        <div class="tst-stat"><div class="tst-stat-lbl">WR</div><div class="tst-stat-val c-green">${wr}%</div></div>
        <div class="tst-stat"><div class="tst-stat-lbl">صفقات</div><div class="tst-stat-val c-white">${a.total_trades||0}</div></div>
      </div>
    </div>`;
  }).join('');
}

function prepAuditSheet() {
  _au = { selSignal: null, selCurs: [], selRR: 2, filters: [], ready: null };
  document.getElementById('audit-signals').innerHTML = _indicators.signals
    .map(s => `<button class="signal-pill" onclick="selAuditSignal('${s.name}')">${s.name}</button>`).join('')
    || '<span style="font-size:12px;color:#555">لا توجد إشارات</span>';
  document.getElementById('audit-currencies').innerHTML = _currencies
    .map(c => `<div class="cur-check-row" id="auc-${c.symbol}" onclick="toggleAuditCur('${c.symbol}')">
      <div class="check-box" id="auch-${c.symbol}"></div>
      <span style="color:#e2e8f0;font-size:14px">${c.symbol}</span>
    </div>`).join('');
  document.querySelectorAll('#audit-rr-row .rr-btn').forEach(b =>
    b.classList.toggle('active', +b.dataset.rr === 2));
  document.getElementById('audit-filters-list').innerHTML = '';
  document.getElementById('audit-readiness').style.display = 'none';
  _updateAuditRunBtn();
}

function selAuditSignal(name) {
  _au.selSignal = name;
  document.querySelectorAll('#audit-signals .signal-pill').forEach(p =>
    p.classList.toggle('active', p.textContent === name));
  _scheduleReadinessCheck();
}

function selAuditRR(rr) {
  _au.selRR = rr;
  document.querySelectorAll('#audit-rr-row .rr-btn').forEach(b =>
    b.classList.toggle('active', +b.dataset.rr === rr));
}

function toggleAuditCur(sym) {
  const idx = _au.selCurs.indexOf(sym);
  if (idx >= 0) { if (_au.selCurs.length > 1) _au.selCurs.splice(idx, 1); }
  else _au.selCurs.push(sym);
  _currencies.forEach(c => {
    const row = document.getElementById('auc-'+c.symbol);
    const chk = document.getElementById('auch-'+c.symbol);
    if (!row || !chk) return;
    const sel = _au.selCurs.includes(c.symbol);
    row.classList.toggle('selected', sel);
    chk.classList.toggle('checked', sel);
    chk.innerHTML = sel ? '<span class="check-mark">✓</span>' : '';
  });
  _scheduleReadinessCheck();
}

function addAuditFilter() {
  const list = document.getElementById('audit-filters-list');
  const opts = _indicators.filters.map(f =>
    `<option value="${escapeHtml(f.id)}" data-name="${escapeHtml(f.name)}">${escapeHtml(f.name)}</option>`
  ).join('');
  if (!opts) { showToast('⚠️ لا توجد فلاتر — ارفع مؤشراً أولاً'); return; }
  const tfOpts = ['5m','15m','1h','4h','1d'].map(t =>
    `<option value="${t}">${t}</option>`).join('');
  const id = Date.now();
  list.insertAdjacentHTML('beforeend', `<div style="display:flex;gap:6px;margin-bottom:6px;align-items:center" id="af-${id}">
    <select class="form-select" style="flex:2" onchange="_setAuditFilterIndId(this,'${id}')">${opts}</select>
    <select class="form-select af-tf-sel" style="flex:1">${tfOpts}</select>
    <button onclick="document.getElementById('af-${id}').remove()"
      style="background:#2d1a1a;border:1px solid #4d2d2d;border-radius:8px;
             color:#f87171;padding:0 10px;cursor:pointer;height:36px">✕</button>
  </div>`);
  /* تعيين indicator_id كـ data attribute */
  const el = document.getElementById('af-'+id);
  const firstOpt = el.querySelector('select option');
  if (firstOpt) el.dataset.indId = firstOpt.value;
}

function _setAuditFilterIndId(sel, rowId) {
  const row = document.getElementById('af-'+rowId);
  if (row) row.dataset.indId = sel.value;
  _scheduleReadinessCheck();
}

function _collectAuditFilters() {
  return Array.from(document.querySelectorAll('#audit-filters-list > div')).map(el => {
    const indId = el.dataset.indId;
    const tf    = el.dataset.tf;
    if (indId) return { indicator_id: indId, tf: tf || '5m' };
    const sel   = el.querySelector('select');
    const selTf = el.querySelector('.af-tf-sel');
    if (sel) return { indicator_name: sel.value, tf: selTf ? selTf.value : '5m' };
    return null;
  }).filter(Boolean);
}

let _readinessTimer = null;
function _scheduleReadinessCheck() {
  _au.ready = null;
  _updateAuditRunBtn();
  clearTimeout(_readinessTimer);
  _readinessTimer = setTimeout(checkAuditReadiness, 600);
}

function _updateAuditRunBtn() {
  const btn = document.getElementById('btn-run-audit');
  if (!btn) return;
  const filters = _collectAuditFilters();
  const hasFilters = filters.length > 0;
  /* بدون فلاتر → لا حاجة لفحص الجاهزية → زر مفعّل دائماً */
  if (!hasFilters) {
    btn.disabled = false;
    btn.style.opacity = '1';
    btn.textContent = '🛡️ ابدأ التدقيق';
    return;
  }
  /* مع فلاتر → يتوقف على نتيجة الفحص */
  if (_au.ready === true) {
    btn.disabled = false;
    btn.style.opacity = '1';
    btn.textContent = '✅ ابدأ التدقيق';
  } else if (_au.ready === false) {
    btn.disabled = true;
    btn.style.opacity = '0.45';
    btn.textContent = '⚠️ البيانات غير مكتملة';
  } else {
    btn.disabled = true;
    btn.style.opacity = '0.6';
    btn.textContent = '🔍 جارٍ الفحص...';
  }
}

async function checkAuditReadiness() {
  const filters = _collectAuditFilters();
  if (!filters.length || !_au.selCurs.length) {
    document.getElementById('audit-readiness').style.display = 'none';
    _au.ready = null;
    _updateAuditRunBtn();
    return;
  }
  /* فلاتر بـ indicator_name فقط — نحوّلها إلى indicator_id */
  const resolvedFilters = filters.map(f => {
    if (f.indicator_id) return f;
    const ind = _indicators.filters.find(i => i.name === f.indicator_name);
    return ind ? { indicator_id: ind.id, tf: f.tf } : null;
  }).filter(Boolean);

  if (!resolvedFilters.length) {
    document.getElementById('audit-readiness').style.display = 'none';
    _au.ready = null; _updateAuditRunBtn(); return;
  }

  try {
    const r = await fetch('/api/audit/readiness', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currencies: _au.selCurs, filters: resolvedFilters }),
    });
    const d = await r.json();
    _au.ready = d.ready === true;
    _renderReadinessPanel(d.currencies || []);
    _updateAuditRunBtn();
  } catch(e) {
    _au.ready = null; _updateAuditRunBtn();
  }
}

function _renderReadinessPanel(currencies) {
  const panel = document.getElementById('audit-readiness');
  if (!currencies.length) { panel.style.display = 'none'; return; }

  const allOk  = currencies.every(c => c.ready);
  const border = allOk ? '#22d3a522' : '#f59e0b33';
  const title  = allOk ? '✅ جميع العملات جاهزة للتدقيق' : '⚠️ بيانات ناقصة — أكمل الخطوات أدناه';
  const color  = allOk ? '#4ade80' : '#f59e0b';

  const rows = currencies.map(c => {
    if (c.ready) {
      return `<div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid #0d1016">
        <span style="color:#4ade80;font-size:14px">✓</span>
        <span style="font-size:13px;font-weight:600;color:#e2e8f0">${escapeHtml(c.symbol)}</span>
        <span style="font-size:11px;color:#334155;margin-right:auto">جاهز</span>
      </div>`;
    }
    const tips = [];
    if (c.missing_tfs && c.missing_tfs.length)
      tips.push(`📊 بيانات ناقصة: ${c.missing_tfs.join(', ')} — اذهب لصفحة البيانات وجلب هذه الأطر`);
    if (c.missing_filters && c.missing_filters.length) {
      const mf = c.missing_filters.map(f => `${f.tf}`).join(', ');
      tips.push(`🔍 فلاتر غير محسوبة على الأطر: ${mf} — افتح بطاقة العملة واضغط على الفريم`);
    }
    return `<div style="padding:8px 0;border-bottom:1px solid #0d1016">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
        <span style="color:#f87171;font-size:14px">✗</span>
        <span style="font-size:13px;font-weight:600;color:#e2e8f0">${escapeHtml(c.symbol)}</span>
      </div>
      ${tips.map(t => `<div style="font-size:11px;color:#64748b;padding-right:22px;margin-top:3px">${escapeHtml(t)}</div>`).join('')}
    </div>`;
  }).join('');

  panel.style.display = 'block';
  panel.innerHTML = `
    <div style="background:#0a0e18;border:1px solid ${border};border-radius:12px;padding:12px 14px">
      <div style="font-size:12px;font-weight:700;color:${color};margin-bottom:10px">${title}</div>
      ${rows}
    </div>`;
}

async function runAudit() {
  if (!_au.selSignal)      { showToast('اختر إشارة أولاً'); return; }
  if (!_au.selCurs.length) { showToast('اختر عملة على الأقل'); return; }

  const filters = _collectAuditFilters();

  /* إذا وجدت فلاتر ولم تكتمل الجاهزية — نوقف */
  if (filters.length && _au.ready === false) {
    showToast('⚠️ أكمل البيانات الناقصة أولاً'); return;
  }

  try {
    const r = await fetch('/api/audit/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ signal_name: _au.selSignal, symbols: _au.selCurs,
                             rr: _au.selRR, filters }),
    });
    const d = await r.json();
    if (d.ok || d.id) { closeSheet('sheet-audit'); showToast('🛡️ بدأ التدقيق'); switchTab('audit'); }
    else showToast('❌ ' + (d.error || 'خطأ'));
  } catch(e) { showToast('❌ خطأ'); }
}

async function openAuditDetail(id) {
  try {
    const r = await fetch(`/api/audit/${id}`);
    const d = await r.json();
    showDetailPage('audit', d);
  } catch(e) { showToast('❌ خطأ'); }
}

async function deleteAudit(id) {
  if (!confirm('حذف هذا التدقيق؟')) return;
  await fetch(`/api/audit/${id}`, { method: 'DELETE' });
  loadAudits();
}

/* ═══════════════════════════════════════════════════════
   DETAIL PAGE (full-screen overlay)
   ═══════════════════════════════════════════════════════ */
function showDetailPage(type, data) {
  const dp = document.getElementById('detail-page');
  dp.style.display = 'flex';

  const titles = { test:'الاختبار ✏️', analysis:'التحليل 📈', audit:'التدقيق 🛡️' };
  document.getElementById('detail-title').innerHTML = `
    <div class="hd-title-area">
      <div class="hd-subtitle">⚡ Trading Lab</div>
      <div class="hd-main-title">${titles[type]||'التفاصيل'}</div>
    </div>`;

  let html = '';
  const d  = data;

  if (type === 'test') {
    const wr  = d.win_rate != null ? Math.round(d.win_rate) : 0;
    const wrColor = wr >= 50 ? '#22c55e' : '#ef4444';
    const sym = (d.symbols || (d.symbol ? [d.symbol] : ['—'])).join(', ');
    // Update the page title to show the test ID
    document.getElementById('detail-title').innerHTML = `
      <div class="hd-title-area">
        <div class="hd-subtitle">⚡ Trading Lab</div>
        <div class="hd-main-title">${escapeHtml(d.id||'—')} ✏️</div>
      </div>`;

    html = `<div class="tst-card" style="cursor:default">
      <div class="tst-card-top" style="margin-bottom:8px">
        <span class="tst-id-badge">${escapeHtml(d.id||'')}</span>
        <span class="tst-signal-name">${escapeHtml(d.signal_name||'—')}</span>
      </div>
      <div style="font-size:12px;color:#64748b;text-align:right;margin-bottom:12px">${escapeHtml(sym)} · RR ${d.rr||2} · ${d.tf||'5m'}</div>
      <div class="stat-grid3" style="margin-bottom:8px">
        <div class="stat-box"><div class="stat-label">نسبة الربح</div><div class="stat-v22" style="color:${wrColor}">${wr}%</div></div>
        <div class="stat-box"><div class="stat-label">صفقات</div><div class="stat-v22 c-white">${d.trades||0}</div></div>
        <div class="stat-box"><div class="stat-label">مفتوحة</div><div class="stat-v22 c-amber">${d.opens||0}</div></div>
      </div>
      <div class="stat-grid2">
        <div class="stat-box"><div class="stat-label">رابحة</div><div class="stat-v22 c-green">${d.wins||0}</div></div>
        <div class="stat-box"><div class="stat-label">خاسرة</div><div class="stat-v22 c-red">${d.losses||0}</div></div>
      </div>
    </div>
    <button class="btn-use-in-analysis" onclick="useInAnalysis('${escapeHtml(String(d.id||''))}')">🔗 استخدم في التحليل</button>`;

    const tlist = d.trades_list || [];
    if (tlist.length) {
      const first = tlist[0];
      const last  = tlist[tlist.length - 1];
      html += `<div class="trades-section-header">
        <span style="font-size:14px;font-weight:600;color:#e2e8f0">الصفقات (آخر ${Math.min(tlist.length,200)})</span>
        <div style="display:flex;gap:6px;align-items:center">
          <button class="btn-trash" style="border-color:#1e3a5f;color:#60a5fa" title="تصدير JSON"
            onclick="exportTestJson('${escapeHtml(String(d.id||''))}')">📥</button>
          <button class="btn-trash" onclick="deleteTest('${escapeHtml(String(d.id||''))}')">🗑️</button>
        </div>
      </div>
      <div class="trades-summary-card">
        <div class="trades-summary-col">
          <div class="tsc-label">📅 أول صفقة</div>
          <div class="tsc-date">${fmtDateTime(first.entry_ts)}</div>
          <div class="tsc-price">${fmtNum(first.entry_price)}</div>
        </div>
        <div class="trades-summary-divider"></div>
        <div class="trades-summary-col">
          <div class="tsc-label">🔔 آخر صفقة</div>
          <div class="tsc-date">${fmtDateTime(last.entry_ts)}</div>
          <div class="tsc-price">${fmtNum(last.entry_price)}</div>
        </div>
      </div>`;

      html += tlist.slice().reverse().slice(0,200).map(t => {
        const win  = t.result === 'win';
        const open = t.result === 'open';
        const pct  = t.pnl_pct != null ? (t.pnl_pct>0?'+':'') + t.pnl_pct.toFixed(1)+'%' : '—';
        const pctColor = win ? '#22c55e' : open ? '#fbbf24' : '#ef4444';
        const statusLabel = win ? 'WIN' : open ? 'OPEN' : 'LOSS';
        const statusCls   = win ? 'trade-badge-win' : open ? 'trade-badge-open' : 'trade-badge-loss';
        return `<div class="trade-row-v2">
          <div class="trade-row-top">
            <div style="font-size:11px;color:#64748b">${fmtDateTime(t.entry_ts)}</div>
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:14px;font-weight:700;color:${pctColor}">${pct}</span>
              <span class="${statusCls}">${statusLabel}</span>
            </div>
          </div>
          <div class="trade-row-bottom">
            <span style="font-size:12px;color:#94a3b8;font-weight:600">${fmtNum(t.entry_price)}</span>
            <div style="display:flex;gap:10px">
              <span class="trade-tp-badge">🎯 ${fmtNum(t.tp)}</span>
              <span class="trade-sl-badge">🔴 ${fmtNum(t.sl)}</span>
            </div>
          </div>
        </div>`;
      }).join('');
    }
  } else if (type === 'analysis') {
    const wrAfter  = typeof d.wr_after  === 'number' ? d.wr_after  : (d.win_rate || 0);
    const wrBefore = typeof d.wr_before === 'number' ? d.wr_before : 0;
    const improve  = +(wrAfter - wrBefore).toFixed(2);
    const improveCol = improve >= 0 ? '#22c55e' : '#ef4444';
    const wrAfterCol = wrAfter >= 50 ? '#22c55e' : '#ef4444';
    const sym = escapeHtml(d.symbol || '—');
    const fltText = _filtersText(d.filters_json);
    const filtersArr = _safeArr(d.filters_json);

    html = `<div class="tst-card" style="cursor:default">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
        <div>
          <div style="font-size:16px;font-weight:700;color:#fff;margin-bottom:3px">${escapeHtml(d.signal_name||'—')}</div>
          <div style="font-size:11px;color:#64748b">${sym}${d.test_id?' · '+escapeHtml(d.test_id||''):''}</div>
        </div>
        <span class="anl-id-badge">${escapeHtml(d.id||'')}</span>
      </div>
      ${fltText ? `<div style="font-size:12px;color:#22d3a5;font-family:monospace;margin-bottom:10px;cursor:pointer"
        onclick="showToast('${escapeHtml(fltText)}')">${escapeHtml(fltText)} 🔍</div>` : ''}
      <div class="stat-grid3" style="margin-bottom:8px">
        <div class="stat-box"><div class="stat-label">تحسن</div>
          <div class="stat-v18" style="color:${improveCol}">${improve>=0?'+':''}${improve}%</div></div>
        <div class="stat-box"><div class="stat-label">WR قبل</div>
          <div class="stat-v18 c-white">${wrBefore.toFixed(1)}%</div></div>
        <div class="stat-box"><div class="stat-label">WR جديد</div>
          <div class="stat-v22" style="color:${wrAfterCol}">${wrAfter.toFixed(1)}%</div></div>
      </div>
      <div class="stat-grid3">
        <div class="stat-box"><div class="stat-label">خاسرة</div><div class="stat-v18 c-red">${d.losses||0}</div></div>
        <div class="stat-box"><div class="stat-label">رابحة</div><div class="stat-v18 c-green">${d.wins||0}</div></div>
        <div class="stat-box"><div class="stat-label">صفقات</div><div class="stat-v18 c-white">${d.trades_after||0}</div></div>
      </div>
    </div>
    <button class="btn-use-in-analysis"
      onclick="useInAudit(${JSON.stringify({
        signal_name: d.signal_name||'',
        symbol: d.symbol||'',
        filters: filtersArr
      }).replace(/'/g,'\&#39;')})"
      style="background:linear-gradient(135deg,#1e3a5f,#1a3050);border-color:#3b82f6">
      🛡️ تدقيق على عملات أخرى
    </button>`;

    /* ── قائمة الصفقات بعد الفلتر (آخر 200) ── */
    const tlist = _safeArr(d.result_json);
    if (tlist.length) {
      const first = tlist[0];
      const last  = tlist[tlist.length - 1];
      html += `<div class="trades-section-header">
        <span style="font-size:13px;font-weight:600;color:#e2e8f0">🗂️ الصفقات بعد الفلتر (آخر ${Math.min(tlist.length,200)})</span>
        <div style="display:flex;gap:6px;align-items:center">
          <button class="btn-trash" style="border-color:#1e3a5f;color:#60a5fa" title="تصدير JSON"
            onclick="exportAnalysisJson('${escapeHtml(d.id||'')}')">📥</button>
          <button class="btn-trash" onclick="deleteAnalysis('${escapeHtml(d.id||'')}')">🗑️</button>
        </div>
      </div>
      <div class="trades-summary-card">
        <div class="trades-summary-col">
          <div class="tsc-label">📅 أول صفقة</div>
          <div class="tsc-date">${fmtDateTime(first.entry_ts)}</div>
          <div class="tsc-price">${fmtNum(first.entry_price)}</div>
        </div>
        <div class="trades-summary-divider"></div>
        <div class="trades-summary-col">
          <div class="tsc-label">🔔 آخر صفقة</div>
          <div class="tsc-date">${fmtDateTime(last.entry_ts)}</div>
          <div class="tsc-price">${fmtNum(last.entry_price)}</div>
        </div>
      </div>`;

      html += tlist.slice().reverse().slice(0,200).map(t => {
        const win  = t.result === 'win';
        const open = t.result === 'open';
        const pct  = t.pnl_pct != null ? (t.pnl_pct>0?'+':'') + Number(t.pnl_pct).toFixed(2)+'%' : '—';
        const pctColor = win ? '#22c55e' : open ? '#fbbf24' : '#ef4444';
        const statusLabel = win ? 'WIN' : open ? 'OPEN' : 'LOSS';
        const statusCls   = win ? 'trade-badge-win' : open ? 'trade-badge-open' : 'trade-badge-loss';
        return `<div class="trade-row-v2">
          <div class="trade-row-top">
            <div style="font-size:11px;color:#64748b">${fmtDateTime(t.entry_ts)}</div>
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:13px;font-weight:700;color:${pctColor}">${pct}</span>
              <span class="${statusCls}">${statusLabel}</span>
            </div>
          </div>
          <div class="trade-row-bottom">
            <span style="font-size:12px;color:#94a3b8;font-weight:600">${fmtNum(t.entry_price)}</span>
            <div style="display:flex;gap:10px">
              <span class="trade-tp-badge">🎯 ${fmtNum(t.tp)}</span>
              <span class="trade-sl-badge">🔴 ${fmtNum(t.sl)}</span>
            </div>
          </div>
        </div>`;
      }).join('');
    } else {
      html += `<div style="text-align:center;padding:20px;color:#64748b;font-size:12px">
        لا توجد صفقات محفوظة — أعِد تشغيل التحليل</div>`;
    }
  } else if (type === 'audit') {
    const auditWr   = Math.round(d.total_wr || 0);
    const auditPass = auditWr >= 50;
    const auditSyms    = _safeArr(d.currencies_json);
    const auditResults = _safeArr(d.result_json);
    html = `<div class="black-card">
      <div style="font-size:18px;font-weight:700;color:#fff;margin-bottom:4px">${escapeHtml(d.signal_id||'—')}</div>
      <div style="font-size:12px;color:#555">${auditSyms.join(', ')}</div>
      <div style="height:1px;background:#1a1a1a;margin:12px 0"></div>
      <div class="stat-grid3">
        <div class="stat-box"><div class="stat-label">النتيجة</div>
          <div class="stat-v16" style="color:${auditPass?'#4ade80':'#ef4444'}">${auditPass?'✅ ناجح':'❌ راسب'}</div></div>
        <div class="stat-box"><div class="stat-label">الصفقات</div><div class="stat-v22 c-white">${d.total_trades||0}</div></div>
        <div class="stat-box"><div class="stat-label">الفوز %</div>
          <div class="stat-v22 c-green">${auditWr}%</div></div>
      </div>
    </div>`;
    if (auditResults.length) {
      html += auditResults.map(res => {
        if (res.error) return `<div class="tst-card" style="border-color:#4d2d2d">
          <div style="font-size:14px;font-weight:700;color:#f87171">${escapeHtml(res.symbol||'')}</div>
          <div style="font-size:12px;color:#f87171;margin-top:4px">${escapeHtml(res.error)}</div></div>`;
        const rWr = Math.round(res.wr || 0);
        const rPass = rWr >= 50;
        return `<div class="black-card">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
            <div style="font-size:13px;color:${rPass?'#4ade80':'#ef4444'}">${rPass?'✅ ناجح':'❌ راسب'}</div>
            <div style="font-size:16px;font-weight:700;color:#fff">${escapeHtml(res.symbol||'')}</div>
          </div>
          <div class="stat-grid3">
            <div class="stat-box"><div class="stat-label">الصفقات</div><div class="stat-v18 c-white">${res.trades||0}</div></div>
            <div class="stat-box"><div class="stat-label">رابح</div><div class="stat-v18 c-green">${res.wins||0}</div></div>
            <div class="stat-box"><div class="stat-label">الفوز %</div>
              <div class="stat-v18 c-green">${rWr}%</div></div>
          </div>
        </div>`;
      }).join('');
    }
  }

  document.getElementById('detail-body').innerHTML = html;
  _setDetailNav();
}

function _setDetailNav() {
  const NAV    = ['data','indicators','test','analysis','audit'];
  const LABELS = { data:'البيانات', indicators:'المؤشرات', test:'اختبار', analysis:'تحليل', audit:'تدقيق' };
  const ICONS  = { data:'📊', indicators:'🔧', test:'✏️', analysis:'📈', audit:'🛡️' };
  document.getElementById('detail-nav').innerHTML = NAV.map(t => `
    <button class="nav-tab" onclick="closeDetailPage();switchTab('${t}')"
      style="color:${t===_tab?'#22d3a5':'#2a3040'}">
      <span class="nav-tab-icon">${ICONS[t]}</span>
      <span class="nav-tab-label" style="font-weight:${t===_tab?'700':'500'}">${LABELS[t]}</span>
    </button>`).join('');
}

function closeDetailPage() {
  document.getElementById('detail-page').style.display = 'none';
}

/* ═══════════════════════════════════════════════════════
   FETCH / IMPORT / INDICATOR UPLOAD
   ═══════════════════════════════════════════════════════ */
async function startFetch() {
  const sym = document.getElementById('fetch-symbol').value.trim().toUpperCase();
  if (!sym) { showToast('أدخل رمز العملة'); return; }
  try {
    const r = await fetch(`/api/data/currencies/${sym}/update`, { method: 'POST' });
    const d = await r.json();
    if (d.ok) {
      closeSheet('sheet-fetch');
      showToast('⬇️ يتم الجلب...');
      document.getElementById('fetch-symbol').value = '';
      loadCurrencies();
    } else showToast('❌ ' + (d.error || 'خطأ'));
  } catch(e) { showToast('❌ خطأ في الاتصال'); }
}

async function doImport() {
  const sym  = document.getElementById('import-symbol').value.trim().toUpperCase();
  const file = document.getElementById('import-file').files[0];
  if (!sym)  { showToast('أدخل رمز العملة'); return; }
  if (!file) { showToast('اختر ملف CSV'); return; }
  const fd = new FormData();
  fd.append('symbol', sym);
  fd.append('file', file);
  try {
    const r = await fetch('/api/data/import', { method: 'POST', body: fd });
    const d = await r.json();
    if (d.ok) {
      closeSheet('sheet-import');
      showToast(`✅ استُوردت ${d.candles.toLocaleString()} شمعة`);
      loadCurrencies();
    } else showToast('❌ ' + (d.error || 'خطأ'));
  } catch(e) { showToast('❌ خطأ'); }
}

async function uploadIndicator() {
  const file = document.getElementById('ind-file').files[0];
  if (!file) { showToast('اختر ملف .py'); return; }
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await fetch('/api/indicators/', { method: 'POST', body: fd });
    const d = await r.json();
    if (d.ok) {
      closeSheet('sheet-indicator');
      showToast('✅ رُفع المؤشر');
      loadIndicators();
    } else showToast('❌ ' + (d.error || 'خطأ'));
  } catch(e) { showToast('❌ خطأ'); }
}

/* ═══════════════════════════════════════════════════════
   SHEET MANAGEMENT
   ═══════════════════════════════════════════════════════ */
function openSheet(id) {
  document.getElementById('overlay').classList.add('active');
  document.getElementById(id).classList.add('open');
}

function closeSheet(id) {
  document.getElementById(id).classList.remove('open');
  if (!document.querySelectorAll('.sheet.open').length)
    document.getElementById('overlay').classList.remove('active');
}

function closeAllSheets() {
  document.querySelectorAll('.sheet.open').forEach(s => s.classList.remove('open'));
  document.getElementById('overlay').classList.remove('active');
}

/* ═══════════════════════════════════════════════════════
   TOAST
   ═══════════════════════════════════════════════════════ */
let _toastTimer = null;
function showToast(msg) {
  const el = document.getElementById('toast');
  // Use innerHTML so \n becomes <br> — but escape first for safety
  el.innerHTML = escapeHtml(String(msg)).replace(/\n/g, '<br>');
  el.classList.add('show');
  clearTimeout(_toastTimer);
  // Longer toast for multi-line messages
  const ms = String(msg).includes('\n') ? 5000 : 3000;
  _toastTimer = setTimeout(() => el.classList.remove('show'), ms);
}

function escapeHtml(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/* ═══════════════════════════════════════════════════════
   HELPERS
   ═══════════════════════════════════════════════════════ */
function fmtDate(ts) {
  if (!ts) return '—';
  return new Date(ts).toISOString().slice(0, 10);
}
function fmtDateTime(ts) {
  if (!ts) return '—';
  const d = new Date(ts);
  const mm = String(d.getUTCMonth()+1).padStart(2,'0');
  const dd = String(d.getUTCDate()).padStart(2,'0');
  const hh = String(d.getUTCHours()).padStart(2,'0');
  const mi = String(d.getUTCMinutes()).padStart(2,'0');
  return `${mm}-${dd} ${hh}:${mi}`;
}
function fmtPnl(v) {
  if (v == null) return '—';
  return (v >= 0 ? '+' : '') + Number(v).toFixed(1) + '%';
}
